import {NgModule, ErrorHandler, Injectable, Injector} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {RouterModule, RouteReuseStrategy} from '@angular/router';
import {IonicModule, IonicRouteStrategy, NavParams} from '@ionic/angular';
import {SplashScreen} from '@ionic-native/splash-screen/ngx';
import {StatusBar} from '@ionic-native/status-bar/ngx';
import {Facebook} from '@ionic-native/facebook/ngx';
import {GooglePlus} from '@ionic-native/google-plus/ngx';
import {Camera} from '@ionic-native/camera/ngx';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {JWT_OPTIONS, JwtModule} from '@auth0/angular-jwt';
import {HttpClientModule} from '@angular/common/http';
import {Globals} from './globals';
import {IonicStorageModule, Storage} from '@ionic/storage';
import {AgmCoreModule} from '@agm/core';
import {ServiceCardComponent} from './supplier/components/service-card/service-card.component';
import {DetailsPage} from './supplier/bookings/details/details.page';
import {DetailsPage as CustomerDetailsPage} from './customer/bookings/details/details.page';
import {DetailsPageModule} from './supplier/bookings/details/details.module';
import {DetailsPageModule as CustomersDetailsPageModule} from './customer/bookings/details/details.module';
import {AgreementsComponent} from './general/components/agreements/agreements.component';
import {Ng2FlatpickrModule} from 'ng2-flatpickr';
import {StarRatingModule} from 'angular-star-rating';
import {EditServicesPage} from './supplier/components/edit-services/edit-services.page';
import {EditServicesPageModule} from './supplier/components/edit-services/edit-services.module';
import {FontAwesomeModule} from '@fortawesome/angular-fontawesome';
import {EditAvailabilityPage} from './supplier/components/edit-availability/edit-availability.page';
import {EditAvailabilityPageModule} from './supplier/components/edit-availability/edit-availability.module';
import {EarningDetailsPage} from './supplier/components/earning-details/earning-details.page';
import {EarningsPageModule} from './supplier/account/earnings/earnings.module';
import {UpdateServiceDetailsPage} from './customer/bookings/update-service-details/update-service-details.page';
import {UpdateServiceDetailsPageModule} from './customer/bookings/update-service-details/update-service-details.module';
import {UpdateServiceLocationPage} from './customer/bookings/update-service-location/update-service-location.page';
import {UpdateServiceLocationPageModule} from './customer/bookings/update-service-location/update-service-location.module';
import {EarningDetailsPageModule} from './supplier/components/earning-details/earning-details.module';
import {PaymentDetailsPage} from './customer/bookings/payment-details/payment-details.page';
import {PaymentDetailsPageModule} from './customer/bookings/payment-details/payment-details.module';
import {ExpensesPageModule} from './supplier/bookings/expenses/expenses.module';
import {Network} from '@ionic-native/network/ngx';
import {OneSignal} from '@ionic-native/onesignal/ngx';
import {NetworkProvider} from './common/network-provider';
import {ReschedulePageModule} from './supplier/bookings/reschedule/reschedule.module';
import {ReschedulePageModule as CustomerReschedulePageModule} from './customer/bookings/reschedule/reschedule.module';
import {ExtendPageModule} from './customer/bookings/extend/extend.module';
import {PhotoPageModule} from './general/photo/photo.module';
import {FlagPageModule} from './customer/bookings/flag/flag.module';
import {Pro} from '@ionic/pro';

Pro.init('95e72e1f', {
  appVersion: '0.2.0'
});

@Injectable()
export class MyErrorHandler implements ErrorHandler {

  constructor(injector: Injector) {
    try {
    } catch (e) {
      // Unable to get the IonicErrorHandler provider, ensure
      // IonicErrorHandler has been added to the providers list below
    }
  }

  handleError(err: any): void {
    Pro.monitoring.handleNewError(err);
    // Remove this if you want to disable Ionic's auto exception handling
    // in development mode.
  }
}


export function jwtOptionsFactory(storage) {
  return {
    tokenGetter: () => {
      return storage.get('access_token');
    },
    whitelistedDomains: ['api.zengot', 'api.zengot.com', 'staging-api.zengot.com']
  };
}

@NgModule({
  declarations: [AppComponent, ServiceCardComponent, AgreementsComponent],
  entryComponents: [ServiceCardComponent, DetailsPage, AgreementsComponent, EarningDetailsPage, UpdateServiceLocationPage,
    CustomerDetailsPage, EditServicesPage, EditAvailabilityPage, UpdateServiceDetailsPage, PaymentDetailsPage],
  imports: [
    BrowserModule,
    IonicModule.forRoot({
      backButtonText: ''
    }),
    IonicStorageModule.forRoot(),
    AppRoutingModule,
    HttpClientModule,
    FlagPageModule,
    PhotoPageModule,
    ExtendPageModule,
    CustomerReschedulePageModule,
    ReschedulePageModule,
    ExpensesPageModule,
    PaymentDetailsPageModule,
    EarningDetailsPageModule,
    UpdateServiceLocationPageModule,
    UpdateServiceDetailsPageModule,
    EarningsPageModule,
    DetailsPageModule,
    EditServicesPageModule,
    EditAvailabilityPageModule,
    CustomersDetailsPageModule,
    JwtModule.forRoot({
      jwtOptionsProvider: {
        provide: JWT_OPTIONS,
        useFactory: jwtOptionsFactory,
        deps: [Storage]
      }
    }),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyBIzrwVkka_LJMF89tgjzJUe6VMDxpQ0gg',
      libraries: ['places']
    }),
    Ng2FlatpickrModule,
    StarRatingModule.forRoot(),
    FontAwesomeModule
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: RouteReuseStrategy, useClass: IonicRouteStrategy},
    Globals,
    Network,
    OneSignal,
    NetworkProvider,
    Facebook,
    GooglePlus,
    Camera,
    [{ provide: ErrorHandler, useClass: MyErrorHandler }]
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
