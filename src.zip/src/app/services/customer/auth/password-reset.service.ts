import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class PasswordResetService {

  constructor(private http: HttpClient, private globals: Globals) { }

  public resetPassword(email: string) {
    const url = this.globals.api_url + 'customer/account/send-recovery';
    const credentials = {
      email: email
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

}
