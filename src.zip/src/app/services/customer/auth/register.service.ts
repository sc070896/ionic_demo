import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private http: HttpClient, private globals: Globals) { }

  public register(first_name: string, last_name: string, email: string, password: string) {
    const url = this.globals.api_url + 'customer/register';
    const credentials = {
      first_name: first_name,
      last_name: last_name,
      email: email,
      password: password
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public resendEmailVerification(uuid) {
    const url = this.globals.api_url + 'customer/resend/verification-email/' + uuid;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }
}
