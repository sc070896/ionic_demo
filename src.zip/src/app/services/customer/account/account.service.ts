import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private http: HttpClient, private globals: Globals) {
  }

  /**
   * Get customer braintree vault
   * @param id customer id
   */
  public getBraintreeNonce(id) {
    const url = this.globals.api_url + 'customer/braintree/token/' + id;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public updatePersonal(id, data) {
    const url = this.globals.api_url + 'customer/account/update/personal/' + id;
    return this.http.post(
      url,
      data,
      {
        headers: this.globals.headers
      }
    );
  }

  public updateEmail(uuid, data) {
    const url = this.globals.api_url + 'customer/update/email/' + uuid;
    return this.http.post(
      url,
      data,
      {
        headers: this.globals.headers
      }
    );
  }

  public updatePassword(id, data) {
    const url = this.globals.api_url + 'customer/account/update/password/' + id;
    return this.http.post(
      url,
      data,
      {
        headers: this.globals.headers
      }
    );
  }

  public applyGiftCard(id, data) {
    const url = this.globals.api_url + 'customer/account/apply/gift-card/' + id;
    return this.http.post(
      url,
      data,
      {
        headers: this.globals.headers
      }
    );
  }

  public updateAvatar(id, data) {
    const url = this.globals.api_url + 'customer/account/update/avatar/' + id;
    return this.http.post(
      url,
      data,
      {
        headers: this.globals.headers
      }
    );
  }

  public getEmailPreferences(id) {
    const url = this.globals.api_url + 'customer/account/get/email-preferences/' + id;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public toggleEmailType(asm_group_id, status, id) {
    const url = this.globals.api_url + 'customer/account/update/email-preferences/' + id;
    const data = {
      asm_group_id: asm_group_id,
      status: status,
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public toggleSms(is_chat, id) {
    const url = this.globals.api_url + 'customer/account/update/sms/' + id;
    const data = {
      is_chat: is_chat,
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public deactivate(id) {
    const url = this.globals.api_url + 'admin/customers/deactivate/' + id;
    const data = {};
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public getNotifications(id, page) {
    const url = this.globals.api_url + 'admin/user/notifications?user_type=customer&user_id=' + id + '&page=' + page;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getMessageNotifications(id, page) {
    const url = this.globals.api_url + 'admin/user/message-notifications?user_type=customer&user_id=' + id + '&page=' + page;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getGiftCards(id, page) {
    const url = this.globals.api_url + 'admin/user/gift-cards?user_type=customer&user_id=' + id + '&page=' + page;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getGiftCardsToClaim(email, page) {
    const url = this.globals.api_url + 'admin/user/gift-cards?user_type=customer&page=' + page + '&email=' + email;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public sendGiftCard(data) {
    const url = this.globals.api_url + 'order/customer/purchase/gift-card';
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public claimGiftCard(data) {
    const url = this.globals.api_url + 'order/customer/claim/gift-card';
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public sendContactUs(data) {
    const url = this.globals.api_url + 'contact-us/send';
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public getReportTypes() {
    const url = this.globals.api_url + 'user_report_types';
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public submitIssue(data) {
    const url = this.globals.api_url + 'issues/submit';
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

}
