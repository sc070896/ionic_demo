import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class RescheduleService {
  constructor(private http: HttpClient, private globals: Globals) {
  }

  public acceptFlexibleReschedule(id) {
    const url = this.globals.api_url + 'customer/bookings/flexible-request/accept/' + id;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }

  public declineFlexibleReschedule(id) {
    const url = this.globals.api_url + 'customer/bookings/flexible-request/decline/' + id;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }

  public createTwoWayReschedule(id, data) {
    const url = this.globals.api_url + 'customer/bookings/reschedule-request/create/' + id;
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public cancelTwoWayReschedule(id) {
    const url = this.globals.api_url + 'customer/bookings/reschedule-request/cancel/' + id;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }

  public acceptTwoWayReschedule(id) {
    const url = this.globals.api_url + 'customer/bookings/reschedule-request/accept/' + id;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }

  public declineTwoWayReschedule(id) {
    const url = this.globals.api_url + 'customer/bookings/reschedule-request/decline/' + id;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }
  public createTwoWayRecurringReschedule(id, data) {
    const url = this.globals.api_url + 'customer/bookings/reschedule-recurring-request/create/' + id;
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public cancelTwoWayRecurringReschedule(id) {
    const url = this.globals.api_url + 'customer/bookings/reschedule-recurring-request/cancel/' + id;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }

  public acceptTwoWayRecurringReschedule(id) {
    const url = this.globals.api_url + 'customer/bookings/reschedule-recurring-request/accept/' + id;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }

  public declineTwoWayRecurringReschedule(id) {
    const url = this.globals.api_url + 'customer/bookings/reschedule-recurring-request/decline/' + id;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }
}
