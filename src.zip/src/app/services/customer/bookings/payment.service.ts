import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor(private http: HttpClient, private globals: Globals) {
  }

  public tip(uuid_booking, tip) {
    const url = this.globals.api_url + 'customer/submit/tip/' + uuid_booking;
    const credentials = {tip: tip};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public rate(uuid_booking, rating_criteria) {
    const url = this.globals.api_url + 'customer/rating/submit/' + uuid_booking;
    const credentials = {ratings: rating_criteria};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public review(uuid_booking, review_criteria, recommended) {
    const url = this.globals.api_url + 'customer/review/submit/' + uuid_booking;
    const credentials = {
      reviews: review_criteria,
      recommended: recommended
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public pay(uuid_booking) {
    const url = this.globals.api_url + 'customer/submit/payment/' + uuid_booking;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public getRatingCriteria() {
    const url = this.globals.api_url + 'customer/rating/criteria';
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getReviewCriteria() {
    const url = this.globals.api_url + 'customer/review/criteria';
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getCharges(uuid) {
    const url = this.globals.api_url + 'customer/get/charges/' + uuid;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }
}
