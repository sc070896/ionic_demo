import { TestBed } from '@angular/core/testing';

import { RescheduleService } from './reschedule.service';

describe('RescheduleService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RescheduleService = TestBed.get(RescheduleService);
    expect(service).toBeTruthy();
  });
});
