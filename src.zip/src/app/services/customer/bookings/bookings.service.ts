import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class BookingsService {

  constructor(private http: HttpClient, private globals: Globals) {
  }

  public getBookings(status, sort_by, keywords, requested_at, current_page) {
    const url = this.globals.api_url + 'customer/get/bookings?status=' + status + '&sort_by='
      + sort_by + '&keywords=' + keywords + '&requested_at=' + requested_at  + '&page=' + current_page + '&user_type=customer';
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public checkCancel(uuid_booking, uuid) {
    const url = this.globals.api_url + 'customer/bookings/cancel/check/' + uuid_booking + '/' + uuid;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public cancel(uuid_booking, uuid) {
    const url = this.globals.api_url + 'customer/bookings/cancel/confirm/' + uuid_booking + '/' + uuid;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public noShow(uuid_booking) {
    const url = this.globals.api_url + 'customer/bookings/no-show/' + uuid_booking;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public extend(bookings_id, hours, minutes) {
    const url = this.globals.api_url + 'customer/bookings/extend/' + bookings_id;
    const credentials = {
      hours: hours,
      minutes: minutes
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public updateServiceDetails(uuid, service_details) {
    const url = this.globals.api_url + 'customer/bookings/update/details/' + uuid;
    const data = {
      service_details: service_details
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public updateServiceLocation(id, data) {
    const url = this.globals.api_url + 'customer/bookings/update/location/' + id;
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }
  // id - booking_expense
  public acceptExpenses(id) {
    const url = this.globals.api_url + 'customer/bookings/expenses/accept/' + id;
    const data = {};
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  // id - booking_expense
  public declineExpenses(id) {
    const url = this.globals.api_url + 'customer/bookings/expenses/reject/' + id;
    const data = {};
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }
}
