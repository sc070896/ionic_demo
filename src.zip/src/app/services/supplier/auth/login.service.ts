import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  constructor(private http: HttpClient, private globals: Globals) {
  }

  public login(email: string, password: string) {
    const url = this.globals.api_url + 'supplier/mobile_login';
    const credentials = {
      email: email,
      password: password
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public logout() {
    const url = this.globals.api_url + 'supplier/mobile_logout';

    return this.http.post(
      url,
      {},
      {
        headers: this.globals.headers
      }
    );
  }

  public user() {
    const url = this.globals.api_url + 'supplier/user';
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

}
