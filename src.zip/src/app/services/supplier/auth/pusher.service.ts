import {Injectable} from '@angular/core';
import Pusher from 'pusher-js';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PusherService {
  public channel: any;
  public pusher: any;
  headers = new HttpHeaders({
    'Content-Type': 'application/json'
  });

  constructor(private storage: Storage, private globals: Globals, private http: HttpClient) {
    this.storage.get('login_type').then((typeRes) => {
      if (typeRes !== 'supplier') {
        return;
      }
      this.storage.get('access_token').then((loggedRes) => {
        this.pusher = new Pusher(this.globals.pusher_app_key, {
          cluster: this.globals.pusher_cluster,
          authTransport: 'ajax',
          authEndpoint: this.globals.api_url + 'supplier/broadcast/auth',
          auth: {
            headers: {
              'Authorization': 'Bearer ' + loggedRes
            }
          }
        });
        console.log(loggedRes);
        if (loggedRes !== null) {
          this.getUser().subscribe((res: any) => {
            console.log(res);
            this.channel = this.pusher.subscribe('private-App.Models.Suppliers.' + res.id);
          }, (err) => {
            console.log(err);
          });
        }
      });
    });

  }

  public getUser() {
    const url = this.globals.api_url + 'supplier/user';
    return this.http.get(
      url,
      {
        headers: this.headers
      }
    );
  }

  public init() {
    console.log(this.channel);
    return this.channel;
  }

  public getPusher() {
    return this.pusher;
  }

  public unsubscribe() {
    this.storage.get('user').then((res) => {
      if (this.pusher !== undefined) {
        this.pusher.unsubscribe('private-App.Models.Suppliers.' + res.id);
        this.pusher.disconnect();
        console.log(this.pusher);
        console.log('pusher disconnected');
      }
    });
  }
}
