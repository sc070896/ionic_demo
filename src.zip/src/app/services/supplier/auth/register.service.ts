import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private http: HttpClient, private globals: Globals) {
  }

  public account(first_name, last_name, email, confirm_email, password, confirm_password) {
    const url = this.globals.api_url + 'supplier/registration/account';
    const credentials = {
      first_name: first_name,
      last_name: last_name,
      email: email,
      confirm_email: confirm_email,
      password: password,
      confirm_password: confirm_password,
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public personal(uuid, avatar, address, apt_number, country, state, city, zip, latitude, longitude, phone, description) {
    const url = this.globals.api_url + 'supplier/registration/personal/' + uuid;
    const credentials = {
      avatar: avatar,
      address: address,
      apt_number: apt_number,
      country: country,
      state: state,
      city: city,
      zip: zip,
      latitude: latitude,
      longitude: longitude,
      phone: phone,
      description: description,
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public services(uuid, services) {
    const url = this.globals.api_url + 'supplier/registration/services/' + uuid;
    const credentials = {
      selected: services,
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public availability(uuid, days) {
    const url = this.globals.api_url + 'supplier/registration/hours/' + uuid;
    const credentials = {
      days: days,
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public areas(uuid, state, cities) {
    const url = this.globals.api_url + 'supplier/registration/work-areas/' + uuid;
    const credentials = {
      state: state,
      cities: cities
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public insurance(uuid, has_vehicle, has_insurance, license_file, insurance_file, license_expiry, insurance_expiry) {
    const url = this.globals.api_url + 'supplier/registration/insurance/' + uuid;
    let credentials = {};
    if (has_insurance) {
      credentials = {
        has_vehicle: has_vehicle,
        has_insurance: has_insurance,
        license: license_file,
        insurance: insurance_file,
        license_expiry: license_expiry,
        insurance_expiry: insurance_expiry
      };
    } else {
      credentials = {
        has_vehicle: has_vehicle,
        has_insurance: has_insurance
      };
    }
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public insuranceDocuments(uuid, has_vehicle, has_insurance, license_file,
                            insurance_file, license_expiry, insurance_expiry, license_uploaded, insurance_uploaded) {
    const url = this.globals.api_url + 'supplier/registration/insurance/' + uuid;
    let credentials = {};
    if (has_insurance) {
      credentials = {
        has_vehicle: has_vehicle,
        has_insurance: has_insurance,
        license: license_file,
        insurance: insurance_file,
        license_expiry: license_expiry,
        insurance_expiry: insurance_expiry,
        license_uploaded: license_uploaded,
        insurance_uploaded: insurance_uploaded
      };
    } else {
      credentials = {
        has_vehicle: has_vehicle,
        has_insurance: has_insurance
      };
    }
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public additional(uuid, references, languages, eligible, working_age, criminal_record) {
    const url = this.globals.api_url + 'supplier/registration/additional/' + uuid;
    const refs = [];
    references.forEach((r) => {
      refs.push({id: r});
    });
    const credentials = {
      references: refs,
      languages: languages,
      eligible: eligible,
      working_age: working_age,
      criminal_record: criminal_record,
      own_smartphone: 1,
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public applicationStatus(uuid) {
    const url = this.globals.api_url + 'supplier/registration/status/' + uuid;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public resendEmailVerification(uuid) {
    const url = this.globals.api_url + 'supplier/resend/verification-email/' + uuid;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }
}
