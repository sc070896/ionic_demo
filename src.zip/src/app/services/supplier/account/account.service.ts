import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private http: HttpClient, private globals: Globals) {
  }

  public instantServiceAreas(id, areas, states_id, able_immediate_services) {
    const url = this.globals.api_url + 'supplier/instant-service-areas/update/' + id;
    const credentials = {
      states_id: states_id,
      able_immediate_services: able_immediate_services,
      areas: areas
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public updatePersonal(id, data) {
    const url = this.globals.api_url + 'supplier/account/update/' + id;
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public updatePassword(id, current_password, new_password) {
    const url = this.globals.api_url + 'supplier/account/update/password/' + id;
    const data = {
      current_password: current_password,
      new_password: new_password
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public updateEmail(uuid, email) {
    const url = this.globals.api_url + 'supplier/update/email/' + uuid;
    const data = {
      email: email
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public sendPhoneVerification(id, phone) {
    const url = this.globals.api_url + 'supplier/phone/create/token/' + id;
    const data = {
      phone: phone
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public verifyPhoneVerification(id, phone, verification_token) {
    const url = this.globals.api_url + 'supplier/phone/verify/token/' + id;
    const data = {
      phone: phone,
      verification_token: verification_token,
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public updateDescription(id, description) {
    const url = this.globals.api_url + 'supplier/account/update/description/' + id;
    const data = {
      description: description
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public updateAvatar(id, avatar) {
    const url = this.globals.api_url + 'supplier/account/update/avatar/' + id;
    const data = {
      avatar: avatar
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public updateBanner(id, banner) {
    const url = this.globals.api_url + 'supplier/account/update/banner/' + id;
    const data = {
      banner: banner
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public getBanks() {
    const url = this.globals.api_url + 'banks';
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getBanking(id) {
    const url = this.globals.api_url + 'supplier/account/get/banking/' + id;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public updateBanking(id, data) {
    const url = this.globals.api_url + 'supplier/account/update/banking/' + id;
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public getEarnings(id, from, to, recent) {
    let url = this.globals.api_url + 'supplier/account/earnings/' + id + '?from=' + from + '&to=' + to;

    if (recent) {
      url = this.globals.api_url + 'supplier/account/earnings/' + id + '?from=' + from + '&to=' + to + '&recent=' + 1;
    }
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getAllEarnings(id) {
    const url = this.globals.api_url + 'supplier/account/all-earnings/' + id;

    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public deactivate(id) {
    const url = this.globals.api_url + 'admin/suppliers/deactivate/' + id;
    const data = {};
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public updateOrientation(id) {
    const url = this.globals.api_url + 'supplier/account/update/orientation/' + id;
    const data = {};
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public getEmailTypes(id) {
    const url = this.globals.api_url + 'supplier/account/get/email_types/' + id;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public toggleEmailType(asm_group_id, status, id) {
    const url = this.globals.api_url + 'supplier/account/update/email_types/' + id;
    const data = {
      asm_group_id: asm_group_id,
      status: status,
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public toggleSms(is_chat, id) {
    const url = this.globals.api_url + 'supplier/account/update/sms/' + id;
    const data = {
      is_chat: is_chat,
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public getNotifications(id, page) {
    const url = this.globals.api_url + 'admin/user/notifications?user_type=supplier&user_id=' + id + '&page=' + page;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getMessageNotifications(id, page) {
    const url = this.globals.api_url + 'admin/user/message-notifications?user_type=supplier&user_id=' + id + '&page=' + page;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getOrientation(id) {
    const url = this.globals.api_url + 'orientations/show/' + id;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }
}
