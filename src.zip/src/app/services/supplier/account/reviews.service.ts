import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class ReviewsService {

  constructor(private http: HttpClient, private globals: Globals) {
  }

  public getReviews(suppliers_id, page) {
    const url = this.globals.api_url + 'supplier/profile/reviews/public?suppliers_id=' + suppliers_id + '&page=' + page;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }
}
