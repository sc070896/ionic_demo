import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  constructor(private http: HttpClient, private globals: Globals) {
  }

  public getSupplierByUsername(username: string) {
    const url = this.globals.api_url + 'supplier/user/' + username;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getOverallRating(uuid) {
    const url = this.globals.api_url + 'supplier/overall-ratings/' + uuid;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }


  // Services

  /**
   * Load service details of for filling in data when editing
   * @param id supplierServices
   */
  public getService(id) {
    const url = this.globals.api_url + 'supplier/services/' + id;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  /**
   * Update service with an array of a single object that has category, services, exp, description, service elements
   * @param id
   * @param selected
   */
  public updateServices(id, selected) {
    const url = this.globals.api_url + 'supplier/services/' + id;
    const credentials = {selected: selected};
    return this.http.put(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  /**
   * Store services same as update
   * @param selected array
   */
  public storeServices(selected) {
    const url = this.globals.api_url + 'supplier/services';
    const credentials = {selected: selected};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  /**
   * Delete service
   * @param id service id
   */
  public deleteService(id) {
    const url = this.globals.api_url + 'supplier/services/' + id;
    return this.http.delete(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  // Work Availability
  public getAvailability(suppliers_id) {
    const url = this.globals.api_url + 'supplier/availability/' + suppliers_id;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public storeAvailability(suppliers_id, addDay, addStart, addEnd) {
    const url = this.globals.api_url + 'supplier/availability';
    const credentials = {
      suppliers_id: suppliers_id,
      day: addDay,
      start: addStart,
      end: addEnd
    };
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public updateAvailability(id, suppliers_id, day, start, end) {
    const url = this.globals.api_url + 'supplier/availability/' + id;
    const credentials = {
      suppliers_id: suppliers_id,
      day: day,
      start: start,
      end: end
    };
    return this.http.put(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public deleteAvailability(id) {
    const url = this.globals.api_url + 'supplier/availability/' + id;
    return this.http.delete(
      url,
      {
        headers: this.globals.headers
      }
    );
  }
}
