import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class BookingsService {
  constructor(private http: HttpClient, private globals: Globals) {
  }

  public getDirect(status, sort_by, keywords, requested_at, current_page) {
    const url = this.globals.api_url + 'supplier/get/bookings?status=' + status + '&sort_by='
      + sort_by + '&keywords=' + keywords + '&requested_at=' + requested_at  + '&page=' + current_page + '&user_type=supplier';
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getInstant(current_page) {
    const url = this.globals.api_url + 'supplier/get/bookings/instant?page=' + current_page;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public accept(uuid_booking, uuid_supplier) {
    const url = this.globals.api_url + 'supplier/bookings/accept/' + uuid_booking + '/' + uuid_supplier;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public decline(uuid_booking, uuid_supplier) {
    const url = this.globals.api_url + 'supplier/bookings/decline/' + uuid_booking + '/' + uuid_supplier;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public start(uuid_booking, uuid_supplier) {
    const url = this.globals.api_url + 'supplier/bookings/start/' + uuid_booking + '/' + uuid_supplier;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public end(uuid_booking, uuid_supplier) {
    const url = this.globals.api_url + 'supplier/bookings/end/' + uuid_booking + '/' + uuid_supplier;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public checkCancel(uuid_booking, uuid_supplier) {
    const url = this.globals.api_url + 'supplier/bookings/cancel/check/' + uuid_booking + '/' + uuid_supplier;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public cancel(uuid_booking, uuid_supplier) {
    const url = this.globals.api_url + 'supplier/bookings/cancel/confirm/' + uuid_booking + '/' + uuid_supplier;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public addExpenses(id, data) {
    const url = this.globals.api_url + 'supplier/bookings/expenses/submit/' + id;
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public removeExpenses(id) {
    const url = this.globals.api_url + 'supplier/bookings/expenses/remove/' + id;
    const data = {};
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }
}
