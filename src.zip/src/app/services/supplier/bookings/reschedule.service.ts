import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../../globals';

@Injectable({
  providedIn: 'root'
})
export class RescheduleService {
  constructor(private http: HttpClient, private globals: Globals) {
  }

  public sendFlexibleReschedule(id, data) {
    const url = this.globals.api_url + 'supplier/bookings/flexible/schedule/' + id;
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public cancelFlexibleReschedule(id) {
    const url = this.globals.api_url + 'supplier/bookings/flexible-request/cancel/' + id;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public createTwoWayReschedule(id, data, uuid) {
    const url = this.globals.api_url + 'supplier/bookings/reschedule-request/create/' + id + '/' + uuid;
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public cancelTwoWayReschedule(id, uuid) {
    const url = this.globals.api_url + 'supplier/bookings/reschedule-request/cancel/' + id + '/' + uuid;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }

  public acceptTwoWayReschedule(id, uuid) {
    const url = this.globals.api_url + 'supplier/bookings/reschedule-request/accept/' + id + '/' + uuid;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }

  public declineTwoWayReschedule(id, uuid) {
    const url = this.globals.api_url + 'supplier/bookings/reschedule-request/decline/' + id + '/' + uuid;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }

  public createTwoWayRecurringReschedule(id, data, uuid) {
    const url = this.globals.api_url + 'supplier/bookings/reschedule-recurring-request/create/' + id + '/' + uuid;
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public cancelTwoWayRecurringReschedule(id, uuid) {
    const url = this.globals.api_url + 'supplier/bookings/reschedule-recurring-request/cancel/' + id + '/' + uuid;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }

  public acceptTwoWayRecurringReschedule(id, uuid) {
    const url = this.globals.api_url + 'supplier/bookings/reschedule-recurring-request/accept/' + id + '/' + uuid;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }

  public declineTwoWayRecurringReschedule(id, uuid) {
    const url = this.globals.api_url + 'supplier/bookings/reschedule-recurring-request/decline/' + id + '/' + uuid;
    return this.http.post(
      url,
      JSON.stringify({}),
      {
        headers: this.globals.headers
      }
    );
  }
}
