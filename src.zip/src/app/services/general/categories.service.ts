import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../globals';

@Injectable({
  providedIn: 'root'
})
export class CategoriesService {

  constructor(private http: HttpClient, private globals: Globals) {
  }

  public getCategories() {
    const url = this.globals.api_url + 'categories/get/active';
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getExperiences() {
    const url = this.globals.api_url + 'experiences';
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  /**
   * @param searchable - 1 or 0
   * @param general - 1 or 0
   */
  public getSubcategories(searchable, general) {
    const url = this.globals.api_url + 'subcategories/get/services?searchable= ' + searchable + '&general=' + general;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }
  public getSingleSubcategory(id) {
    const url = this.globals.api_url + 'subcategories/show/' + id;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }
}
