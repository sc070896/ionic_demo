import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../globals';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http: HttpClient, private globals: Globals) {}

  public initialize(data) {
    const url = this.globals.api_url + 'order/initialize';
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public edit(data) {
    const url = this.globals.api_url + 'order/edit';
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public choose(data) {
    const url = this.globals.api_url + 'order/choose';
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public finalize(data) {
    const url = this.globals.api_url + 'order/finalize';
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public getTax(uuid) {
    const url = this.globals.api_url + 'order/tax/' + uuid;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public applyPromo(frequencies_id, subcategory_id, promo_code, customer_email, uses_reduced_discount) {
    const url = this.globals.api_url + 'order/promo';
    const data = {
      frequencies_id: frequencies_id,
      subcategories_id: subcategory_id,
      promo_code: promo_code,
      customer_email: customer_email,
      uses_reduced_discount: uses_reduced_discount
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public applyGiftCard(redeemable_code) {
    const url = this.globals.api_url + 'order/gift-card';
    const data = {
      redeemable_code: redeemable_code
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  public getFrequencies(type, minimum_hours: number, service_id) {
    if (type === 0) {
      const freqs = [
        {
          value: 1,
          frequency: 'Just Once - Minimum hours: ' + minimum_hours
        },
        {
          value: 2,
          frequency: 'Weekly (15% off)'
        },
        {
          value: 3,
          frequency: 'Bi-weekly (10% off)'
        },
        {
          value: 4,
          frequency: 'Monthly (5% off)'
        },
      ];
      return freqs;
    } else {
      if (service_id === 155) {
        const freqs = [
          {
            value: 2,
            frequency: 'Weekly (10% off)'
          },
          {
            value: 3,
            frequency: 'Bi-weekly (5% off)'
          },
          {
            value: 4,
            frequency: 'Monthly'
          },
        ];
        return freqs;
      } else {
        const freqs = [
          {
            value: 1,
            frequency: 'Just Once - Minimum hours: ' + minimum_hours
          },
          {
            value: 2,
            frequency: 'Weekly (10% off)'
          },
          {
            value: 3,
            frequency: 'Bi-weekly (5% off)'
          },
          {
            value: 4,
            frequency: 'Monthly'
          },
        ];
        return freqs;
      }
    }

  }

  // Get times according to business hours 8am - 8pm
  public getTimes() {
    const times = [];

    for (let i = 8; i <= 20; i++) {
      const hour = i.toString().padStart(2, '0');
      for (let j = 0; j < 2; j++) {
        if (j === 1) {
          if (i !== 20) {
            const hour24Value = hour + ':' + '30';
            const hour12Value = this.tConvert(hour24Value);
            times.push({
              value: hour24Value,
              time: hour12Value
            });
          }
        } else {
          const hour24Value = hour + ':' + '00';
          const hour12Value = this.tConvert(hour24Value);
          times.push({
            value: hour24Value,
            time: hour12Value
          });
        }
      }
    }

    return times;
  }

  // Get hours for duration of service
  public getHours(contracts_id, minimum_hours: number) {
    const hours = [];
    let max_hours = 12;
    if (contracts_id > 1) { // max 7 hours if contract involved
      max_hours = 7;
    }
    for (let i = 1; i < max_hours; i++) {
      if (i >= minimum_hours) { // equal or greater than minimum hours
        hours.push(i);
      }
    }

    return hours;
  }

  // Get minutes of duration - 15, 30, 45
  public getMinutes() {
    const minutes = [];

    for (let i = 0; i < 60; i += 15) {
      if (i !== 0) {
        minutes.push(i);
      }
    }

    return minutes;
  }

  public getSuppliers(page, sort_by, booking, name, min_price, max_price) {
    const url = this.globals.api_url + 'order/suppliers' + '?page=' + page + '&sub_category_id=' + booking.sub_category_id
      + '&uuid_booking=' + booking.uuid_booking + '&booked_hours=' + booking.hours
      + '&booked_minutes=' + booking.minutes + '&sortBy=' + sort_by
      + '&service_date=' + booking.service_date + '&requested_time=' + booking.requested_time + '&frequency=' + booking.frequency.id
      + '&name=' + name + '&min_price=' + min_price + '&max_price=' + max_price;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getReviews(id) {
    const url = this.globals.api_url + 'supplier/profile/reviews/public';
    const data = {
      suppliers_id: id
    };
    return this.http.post(
      url,
      JSON.stringify(data),
      {
        headers: this.globals.headers
      }
    );
  }

  private tConvert(time) {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
      time = time.slice(1);  // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    return time.join(''); // return adjusted time or original string
  }

}
