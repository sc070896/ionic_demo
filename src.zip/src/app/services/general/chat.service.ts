import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../globals';

@Injectable({
  providedIn: 'root'
})
export class ChatService {

  constructor(private http: HttpClient, private globals: Globals) {
  }

  // Token to authorize chat client
  public getToken(username) {
    const url = this.globals.api_url + 'twilio/token';
    const data = {identity: username, device: 'browser'};
    return this.http.post(
      url,
      data,
      {
        headers: this.globals.headers
      }
    );
  }

  // Credentials (username, names, images, channel_name) for chat and channel
  public messageSupplier(uuid) {
    const url = this.globals.api_url + 'customer/chat/' + uuid;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public messageCustomer(uuid) {
    const url = this.globals.api_url + 'supplier/chat/' + uuid;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public resetUnreadMessages(bookings_id, user_type) {
    const url = this.globals.api_url + 'twilio/reset/unread';
    const data = {
      bookings_id: bookings_id,
      user_type: user_type
    };
    return this.http.post(
      url,
      data,
      {
        headers: this.globals.headers
      }
    );
  }

  public increaseUnreadMessages(bookings_id, message, user_type) {
    const url = this.globals.api_url + 'twilio/increase/unread';
    const data = {
      bookings_id: bookings_id,
      message: message,
      user_type: user_type
    };
    return this.http.post(
      url,
      data,
      {
        headers: this.globals.headers
      }
    );
  }
}
