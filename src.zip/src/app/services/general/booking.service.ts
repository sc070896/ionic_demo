import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../globals';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor(private http: HttpClient, private globals: Globals) { }

  public getBookingByUuid(uuid) {
    const url = this.globals.api_url + 'order/get/booking/' + uuid;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

}
