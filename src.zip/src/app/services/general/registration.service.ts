import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Globals} from '../../globals';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {

  constructor(private http: HttpClient, private globals: Globals) {
  }

  public getStates() {
    const url = this.globals.api_url + 'states';
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getCocs(type) {
    const url = this.globals.api_url + 'admin/code_of_conducts?type=' + type;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getReferences() {
    const url = this.globals.api_url + 'references';
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getLanguages() {
    const url = this.globals.api_url + 'languages';
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getPage(slug: string) {
    const url = this.globals.api_url + 'page/get/slug/' + slug;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getLegal(slug: string) {
    const url = this.globals.api_url + 'legal_documentation/get/slug/' + slug;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getInterviews(date, page) {
    const url = this.globals.api_url + 'crm_calls_by_date?date=' + date + '&page=' + page;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public registerInterview(id, suppliers_id) {
    const url = this.globals.api_url + 'crm_calls/register/' + id + '/' + suppliers_id;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }
  public cancelInterview(id, suppliers_id) {
    const url = this.globals.api_url + 'crm_calls/cancel/' + id + '/' + suppliers_id;
    const credentials = {};
    return this.http.post(
      url,
      JSON.stringify(credentials),
      {
        headers: this.globals.headers
      }
    );
  }

  public getInterviewStatus(id) {
    const url = this.globals.api_url + 'supplier/crm_call/' + id;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }

  public getUserByUuid(uuid) {
    const url = this.globals.api_url + 'supplier/account/' + uuid;
    return this.http.get(
      url,
      {
        headers: this.globals.headers
      }
    );
  }
}
