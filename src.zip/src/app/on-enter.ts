export interface OnEnter {
  onEnter(): Promise<void>;
}