import {Component, OnInit, ViewChild} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Storage} from '@ionic/storage';
import {AlertController, NavController, Events, IonRefresher} from '@ionic/angular';
import {BookingService} from '../../../services/general/booking.service';
import {Globals} from '../../../globals';
import {LoginService} from '../../../services/customer/auth/login.service';
import {AccountService} from '../../../services/customer/account/account.service';
import * as dropin from 'braintree-web-drop-in';
import {PaymentService} from '../../../services/customer/bookings/payment.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.page.html',
  styleUrls: ['./payment.page.scss'],
})
export class PaymentPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public customer: any;
  public uuid: any;
  public booking: any;
  public loading = true;
  public bucket_url: string;
  public steps = 1;
  public tip: any = 0;
  public hide_tip = true;
  public rating_criteria = [];
  public review_criteria = [];
  public charges = [];
  public expenses_charges = [];
  public service_charge: any;
  public expense_charge: any;
  public total_charge: any;
  public recommended: boolean;
  public error = false;
  nonce = '';
  btoken = '';
  braintree_instance = null;
  device_data = null;
  valid_payment = false;

  constructor(private route: ActivatedRoute, private router: Router, private storage: Storage, private navController: NavController,
              public bookingService: BookingService, public globals: Globals, private alertController: AlertController,
              public loginService: LoginService, public accountService: AccountService, public paymentService: PaymentService,
              public events: Events) {
    this.bucket_url = this.globals.bucket_url;
  }

  // http://localhost:8100/customer/order/finalize/2fb13cad-d650-4d51-97da-8e5d9d06430e
  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.uuid = params['uuid'];
      this.init();
    });

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.init();
    });
  }

  public init() {
    // get booking details
    this.bookingService.getBookingByUuid(this.uuid).subscribe((result: any) => {
      console.log(result);
      this.booking = result;
      this.getCustomer();
      this.getRatingCriteria();
      this.getReviewCriteria();
      this.getCharges();
    }, (err) => {
      console.log(err);
      this.error = true;
    });
  }

  public getCharges() {
    this.paymentService.getCharges(this.uuid).subscribe((res: any) => {
        this.charges = res.charges;
        this.expenses_charges = res.expenses_charges;
        this.service_charge = res.service_charge;
        this.expense_charge = res.expense_charge;
        this.total_charge = parseFloat(this.service_charge) + parseFloat(this.expense_charge);
        this.total_charge = this.total_charge.toFixed(2);
        console.log(this.charges);
        console.log(this.expenses_charges);
      },
      (err) => {
        this.error = true;
      });
  }

  public getRatingCriteria() {
    this.paymentService.getRatingCriteria().subscribe((r: any) => {
        console.log(r);
        this.rating_criteria = r;
      },
      (err) => {
        this.error = true;
      });
  }

  public getReviewCriteria() {
    this.paymentService.getReviewCriteria().subscribe((r: any) => {
        this.review_criteria = r;
      },
      (err) => {
        this.error = true;
      });
  }

  public setRating(event, criteria) {
    const index = this.rating_criteria.findIndex(c => c.id === criteria);
    if (index > -1) {
      this.rating_criteria[index].rating = event.rating;
    }
  }

  public setReview(event, criteria) {
    const index = this.review_criteria.findIndex(c => c.id === criteria);
    console.log(event.target.value);
    if (index > -1) {
      this.review_criteria[index].answer = event.target.value;
    }
  }

  public getCustomer() {
    this.loginService.user().subscribe((r: any) => {
        console.log(r);
        this.customer = r;
        this.getCustomerPaymentInfo();
        this.storage.set('user', r).then((loginRes) => {});
        this.loading = false;
        this.refresher.complete();
      },
      (err) => {
        this.loading = false;
        this.refresher.complete();
      });
  }

  public getCustomerPaymentInfo() {
    this.accountService.getBraintreeNonce(this.customer.id).subscribe((r: any) => {
        this.btoken = r.customer_nonce;
        this.loadBraintree();
      },
      (err) => {
        console.log(err);
      });
  }

  public loadBraintree() {
    dropin.create({
      authorization: this.btoken,
      selector: '#dropin-container',
      paypal: {
        flow: 'vault'
      }
    }, (err, dropinInstance) => {
      if (err) {
        // Handle any errors that might've occurred when creating Drop-in
        console.log(err);
        // Message.showError(err);
        return;
      }
      this.braintree_instance = dropinInstance;
    });
  }

  // Update payment method
  public getBraintreeNonce() {
    return new Promise((resolve, reject) => {
      try {
        this.braintree_instance.requestPaymentMethod((err, payload) => {
          if (err) {
            console.log(err);
            this.globals.presentTopToast('Invalid payment method');
            this.valid_payment = false;
            reject(false);
          }
          // Send payload.nonce to your server
          this.nonce = payload.nonce;
          this.valid_payment = true;
          resolve(true);
        });
      } catch (err) {
        console.log(err);
        this.globals.presentTopToast('Failed to process payment');
        this.valid_payment = false;
        reject(false);
      }
    });
  }

  public selectTip(tip: any, event) {
    if (tip === 'other') {
      this.tip = 25.00;
      this.hide_tip = false;
    } else {
      this.hide_tip = true;
      this.tip = tip;
    }
    const btns = document.getElementsByClassName('tip-btn');
    [].forEach.call(btns, (el) => { // unfill all buttons
      el.fill = 'outline';
    });
    event.target.fill = 'solid';
  }

  public submitTip() {
    // If other tip is select can't be 0
    if (!this.hide_tip) {
      if (this.tip <= 0) {
        this.globals.presentTopToast('Tip must be greater than 0');
        return;
      }
    }
    this.globals.presentLoading('Loading...').then((loadingRes) => {
      this.paymentService.tip(this.uuid, this.tip)
        .subscribe((res: any) => {
          this.globals.loading.dismiss();
          this.forward();
        }, (err) => {
          const msg = err.error.error;
          this.globals.presentAlert(msg);
          this.globals.loading.dismiss();
        });
    });
  }

  public submitRating() {
    // Must rate overall rating
    const result = this.rating_criteria.find(c => c.id === 1);
    if (result !== undefined) {
      if (result['rating'] === undefined) {
        this.globals.presentTopToast('Please select an "Overall Experience" rating for your zenGiver');
        return;
      }
    }
    this.globals.presentLoading('Loading...').then((loadingRes) => {
      this.paymentService.rate(this.uuid, this.rating_criteria)
        .subscribe((res: any) => {
          this.globals.loading.dismiss();
          this.forward();
        }, (err) => {
          const msg = err.error.error;
          this.globals.presentAlert(msg);
          this.globals.loading.dismiss();
        });
    });
  }

  async submitReview() {
    const result = this.review_criteria.find(c => c.id === 1);
    console.log(result['answer'] === undefined);
    if (result['answer'] === undefined) {
      const alert = await this.alertController.create({
        header: 'Continue?',
        message: 'Are you sure you wish to skip reviewing your zenGiver?',
        buttons: [
          {
            text: 'No',
            role: 'cancel',
            cssClass: 'secondary'
          }, {
            text: 'Yes',
            handler: () => {
              this.forward();
            }
          }
        ]
      });

      await alert.present();
    } else {
      this.globals.presentLoading('Loading...').then((loadingRes) => {
        this.paymentService.review(this.uuid, this.review_criteria, this.recommended)
          .subscribe((res: any) => {
            this.globals.loading.dismiss();
            this.forward();
          }, (err) => {
            const msg = err.error.error;
            this.globals.presentAlert(msg);
            this.globals.loading.dismiss();
          });
      });
    }
  }

  public submitPayment() {
    this.getBraintreeNonce().then((braintreeRes) => {
      this.globals.presentLoading('Loading...').then((loadingRes) => {
        this.paymentService.pay(this.uuid)
          .subscribe((res: any) => {
            this.globals.loading.dismiss();
            this.forward();
          }, (err) => {
            const msg = err.error.error;
            this.globals.presentAlert(msg);
            this.globals.loading.dismiss();
          });
      });
    }).catch((err) => {
      console.log(err);
      this.globals.presentAlert(err);
    });
  }

  formatDate(d) {
    return this.globals.formatDate(d);
  }

  formatTime(d) {
    return this.globals.formatTime(d);
  }

  formatPercent(num: any) {
    return (parseFloat(num) * 100).toFixed(0);
  }

  formatCost(num: any) {
    return Math.abs(num).toFixed(2);
  }

  public initials(name: string) {
    return this.globals.initials(name);
  }

  public goToProfile(username) {
    this.navController.navigateForward('zengiver/profile/' + username);
  }

  public checkForward() {
    if (this.steps === 1) {
      this.submitTip();
    }

    if (this.steps === 2) {
      this.submitRating();
    }

    if (this.steps === 3) {
      this.submitReview();
    }

    if (this.steps === 4) {
      this.submitPayment();
    }
  }

  public forward() {
    this.steps++;
  }

  public back() {
    this.steps--;
  }

  public navigateBack() {
    this.navController.back();
  }

  public go(route: string) {
    this.navController.navigateRoot(route);
  }
}
