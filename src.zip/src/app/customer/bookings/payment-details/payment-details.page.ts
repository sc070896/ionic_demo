import {Component, OnInit} from '@angular/core';
import {ModalController, NavController} from '@ionic/angular';
import {Globals} from '../../../globals';

@Component({
  selector: 'app-payment-details',
  templateUrl: './payment-details.page.html',
  styleUrls: ['./payment-details.page.scss'],
})
export class PaymentDetailsPage implements OnInit {

  public b: any;
  public charges: any = [];
  public expense_charges: any = [];

  constructor(public navController: NavController, private modalController: ModalController, public globals: Globals) {
  }

  ngOnInit() {
    this.charges = this.b.service_charges;
    this.expense_charges = this.b.expense_charges;
  }

  formatCost(num: any) {
    return Math.abs(num).toFixed(2);
  }

  formatPercent(num: any) {
    return parseFloat(num).toFixed(0);
  }

  public back() {
    this.modalController.dismiss({});
  }

}
