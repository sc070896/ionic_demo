import {Component, NgZone, OnInit} from '@angular/core';
import {AlertController, ModalController, NavController} from '@ionic/angular';
import {Globals} from '../../../globals';
import {MapsAPILoader} from '@agm/core';
import {BookingsService} from '../../../services/customer/bookings/bookings.service';
import {PusherService} from '../../../services/customer/auth/pusher.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-update-service-details',
  templateUrl: './update-service-details.page.html',
  styleUrls: ['./update-service-details.page.scss'],
})
export class UpdateServiceDetailsPage implements OnInit {
  form: FormGroup;
  public b: any;

  constructor(public navController: NavController, private modalController: ModalController, public globals: Globals,
              private mapsAPILoader: MapsAPILoader, private ngZone: NgZone, public bookingsService: BookingsService,
              public pusherService: PusherService, public alertController: AlertController, private formBuilder: FormBuilder) {
    this.form = this.formBuilder.group({
      service_details: ['', Validators.compose([
        Validators.required
      ])]
    });
  }

  ngOnInit() {
    this.form.controls['service_details'].setValue(this.b.service_details);
  }

  public back() {
    this.modalController.dismiss({});
  }

  public update() {
    this.globals.presentLoading('Loading...').then((resLoading) => {
      this.bookingsService.updateServiceDetails(this.b.uuid_booking, this.form.controls['service_details'].value)
        .subscribe((res: any) => {
          console.log(res);
          this.b = res.booking;
          this.globals.presentAlert(res.success);
          this.globals.loading.dismiss();
          this.modalController.dismiss({
            b: this.b
          });
        }, (err) => {
          console.log(err);
          const msg = err.error.error;
          this.globals.presentAlert(msg);
          this.globals.loading.dismiss();
        });
    });
  }
}
