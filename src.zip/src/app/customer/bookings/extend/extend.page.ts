import {Component, OnInit} from '@angular/core';
import {Globals} from '../../../globals';
import {BookingsService} from '../../../services/customer/bookings/bookings.service';
import {PusherService} from '../../../services/customer/auth/pusher.service';
import {OrderService} from '../../../services/general/order.service';
import {AlertController, ModalController, NavController} from '@ionic/angular';

@Component({
  selector: 'app-extend',
  templateUrl: './extend.page.html',
  styleUrls: ['./extend.page.scss'],
})
export class ExtendPage implements OnInit {
  public b: any;
  public hours_options: any = [];
  public minutes_options: any = [];
  public hours: number;
  public minutes: number;

  constructor(public navController: NavController, private modalController: ModalController, public globals: Globals,
              public bookingsService: BookingsService, public pusherService: PusherService, public orderService: OrderService,
              public alertController: AlertController) {
  }

  ngOnInit() {
    this.hours_options = this.orderService.getHours(0, 1);
    this.minutes_options = this.orderService.getMinutes();
  }

  public back() {
    this.modalController.dismiss({
      b: this.b
    });
  }

  async update() {
    if (this.hours === undefined) {
      this.globals.presentAlert('Select the number of hours');
      return false;
    }
    if (this.minutes === undefined) {
      this.globals.presentAlert('Select the number of minutes');
      return false;
    }
    if (this.minutes === 1) { // work around a bug around having 0 as a value with ngModel
      this.minutes = 0;
    }
    const alert = await this.alertController.create({
      header: 'Extend Duration of Service?',
      message: 'By ' + this.hours + ' hours and ' + this.minutes + ' minutes',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.bookingsService.extend(this.b.id, this.hours, this.minutes)
                .subscribe((res: any) => {
                  this.b = res.booking;
                  this.globals.presentAlert(res.success);
                  this.globals.loading.dismiss();
                  this.modalController.dismiss({
                    b: this.b
                  });
                }, (err) => {
                  console.log(err);
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            });
          }
        }
      ]
    });
    await alert.present();
  }
}
