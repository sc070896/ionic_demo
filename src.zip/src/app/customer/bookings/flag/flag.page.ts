import {Component, OnInit} from '@angular/core';
import {Globals} from '../../../globals';
import {CategoriesService} from '../../../services/general/categories.service';
import {AccountService} from '../../../services/customer/account/account.service';
import {Storage} from '@ionic/storage';
import {AlertController, ModalController, NavController, Events} from '@ionic/angular';

@Component({
  selector: 'app-flag',
  templateUrl: './flag.page.html',
  styleUrls: ['./flag.page.scss'],
})
export class FlagPage implements OnInit {
  public report_types: any = [];
  public issue_type: any;
  public description: any = '';
  public loading = true;
  public suppliers_id: any;
  public customers_id: any;

  constructor(public navController: NavController, public globals: Globals, public categoriesService: CategoriesService,
              public modalController: ModalController, public accountService: AccountService,
              private storage: Storage, public alertController: AlertController, public events: Events) {
  }

  ngOnInit() {
    this.storage.get('user').then((res) => {
      console.log(res);
      this.customers_id = res.id;
    });
    this.getReportTypes();
  }

  getReportTypes() {
    this.accountService.getReportTypes().subscribe((result: any) => {
      this.report_types = result;
      this.loading = false;
    }, (err) => {
      console.log(err);
      this.loading = false;
    });
  }

  async submit() {
    if (this.issue_type === undefined) {
      this.globals.presentAlert('Please choose the type of issue');
      return;
    }

    if (this.description === '') {
      this.globals.presentAlert('Please describe your issue');
      return;
    }

    const data = {
      suppliers_id: this.suppliers_id,
      customers_id: this.customers_id,
      user_report_types_id: this.issue_type,
      description: this.description,
    };
    console.log(data);
    const alert = await this.alertController.create({
      header: 'Submit?',
      message: '',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.accountService.submitIssue(data)
                .subscribe((res: any) => {
                  this.issue_type = undefined;
                  this.description = '';
                  this.globals.presentTopToast(res.msg);
                  this.globals.loading.dismiss();
                  this.modalController.dismiss({});
                }, (err) => {
                  const msg = err.error.msg;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  public back() {
    this.modalController.dismiss({});
  }
}
