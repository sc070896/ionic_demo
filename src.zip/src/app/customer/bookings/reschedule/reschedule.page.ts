import {Component, OnInit} from '@angular/core';
import {Globals} from '../../../globals';
import {BookingsService} from '../../../services/customer/bookings/bookings.service';
import {PusherService} from '../../../services/customer/auth/pusher.service';
import {AlertController, ModalController, NavController} from '@ionic/angular';
import {FlatpickrOptions} from 'ng2-flatpickr';
import {OrderService} from '../../../services/general/order.service';
import {RescheduleService} from '../../../services/customer/bookings/reschedule.service';

@Component({
  selector: 'app-reschedule',
  templateUrl: './reschedule.page.html',
  styleUrls: ['./reschedule.page.scss'],
})
export class ReschedulePage implements OnInit {
  public type = 2;
  public user: any;
  public title = 'Schedule Service';
  public buttonMsg = 'Schedule';
  public phrase = 'When would you like this service to start?';
  public switchMsg = 'Reschedule the date & time of the next occurring service';
  public booking: any;
  public selected_date: any;
  public requested_time: any;
  public hours_options: any = [];
  public minutes_options: any = [];
  public hours: number;
  public minutes: number;
  public warningOpened = false;
  public times: any = [];
  public calendar_options: FlatpickrOptions = {
    defaultDate: 'today',
    inline: false,
    onChange: (selectedDates, dateStr, instance) => {
      this.selected_date = dateStr;
    },
    onReady: (selectedDates, dateStr, instance) => {
      this.selected_date = dateStr;
    },
    altInput: true,
    altFormat: 'F j, Y',
    dateFormat: 'Y-m-d',
    minDate: 'today',
    disableMobile: true,
    clickOpens: true,
  };

  constructor(public navController: NavController, private modalController: ModalController, public globals: Globals,
              public bookingsService: BookingsService, public pusherService: PusherService, public orderService: OrderService,
              public rescheduleService: RescheduleService, public alertController: AlertController) {
  }

  ngOnInit() {
    if (this.type === 1) {
      this.title = 'Schedule';
      this.buttonMsg = 'Schedule';
    } else if (this.type === 2) {
      this.title = 'Reschedule';
      this.buttonMsg = 'Reschedule';
    }
    this.times = this.orderService.getTimes();
    this.hours_options = this.orderService.getHours(0, this.booking.subcategory.minimum_hours);
    this.minutes_options = this.orderService.getMinutes();
  }

  public back() {
    this.modalController.dismiss({
      booking: this.booking
    });
  }

  async update() {
    if (!this.validateTimes(this.selected_date, this.requested_time)) {
      return;
    }

    if (this.type === 2) { // current reschedule
      if (this.minutes === 1) { // work around a bug around having 0 as a value with ngModel
        this.minutes = 0;
      }
      const data = {
        service_date: this.selected_date,
        requested_time: this.requested_time,
        hours: this.hours,
        mins: this.minutes
      };

      const alert = await this.alertController.create({
        header: 'Reschedule Service?',
        message: 'Send request to reschedule this service to '
          + this.globals.formatTimeLocal(this.selected_date + ' ' + this.requested_time),
        buttons: [
          {
            text: 'No',
            role: 'cancel',
            cssClass: 'secondary'
          }, {
            text: 'Yes',
            handler: () => {
              this.globals.presentLoading('Loading...').then((resLoading) => {
                this.rescheduleService.createTwoWayReschedule(this.booking.id, data)
                  .subscribe((res: any) => {
                    this.booking = res.booking;
                    this.globals.presentAlert(res.success);
                    this.globals.loading.dismiss();
                    this.modalController.dismiss({
                      booking: this.booking
                    });
                  }, (err) => {
                    console.log(err);
                    const msg = err.error.error;
                    this.globals.presentAlert(msg);
                    this.globals.loading.dismiss();
                  });
              });
            }
          }
        ]
      });
      await alert.present();
    }

    if (this.type === 3) { // recurring reschedule
      const data = {
        service_date: this.selected_date,
        requested_time: this.requested_time,
      };

      const alert = await this.alertController.create({
        header: 'Reschedule Next Service?',
        message: 'Send request to reschedule next service to '
          + this.globals.formatTimeLocal(this.selected_date + ' ' + this.requested_time),
        buttons: [
          {
            text: 'No',
            role: 'cancel',
            cssClass: 'secondary'
          }, {
            text: 'Yes',
            handler: () => {
              this.globals.presentLoading('Loading...').then((resLoading) => {
                this.rescheduleService.createTwoWayRecurringReschedule(this.booking.id, data)
                  .subscribe((res: any) => {
                    this.booking = res.booking;
                    this.globals.presentAlert(res.success);
                    this.globals.loading.dismiss();
                    this.modalController.dismiss({
                      booking: this.booking
                    });
                  }, (err) => {
                    console.log(err);
                    const msg = err.error.error;
                    this.globals.presentAlert(msg);
                    this.globals.loading.dismiss();
                  });
              });
            }
          }
        ]
      });
      await alert.present();
    }
  }

  public validateTimes(service_date, requested_time) {
    if (this.requested_time === undefined) {
      this.globals.presentAlert('Select the time');
      return false;
    }

    if (this.type === 2) {
      if (this.hours === undefined) {
        this.globals.presentAlert('Select the number of hours');
        return false;
      }
      if (this.minutes === undefined) {
        this.globals.presentAlert('Select the number of minutes');
        return false;
      }
    }

    const now = new Date();
    const nowDay = new Date();
    const hour = now.getHours();
    const selectedDate = new Date(service_date);
    const selectedDateTime = new Date(service_date + ' ' + requested_time);

    // Add a day
    selectedDate.setDate(selectedDate.getDate() + 1);
    nowDay.setDate(nowDay.getDate() + 1);

    if (selectedDateTime < now) { // date and time past
      // Message.showError('The requested time you have selected has already past');
      this.globals.presentAlert('The requested time you have selected has already past');
      return false;
    } else if (selectedDateTime < nowDay) { // within 24 hours
      if (!this.warningOpened) {
        this.openWarning();
      }
    }

    if (this.requested_time !== 'asap') {
      console.log(this.requested_time);
      if (now.setHours(0, 0, 0, 0) === selectedDate.setHours(0, 0, 0, 0)) {
        const nowHours = hour + ':00';
        if (this.globals.strtotime(this.requested_time) <= this.globals.strtotime(nowHours)) {
          this.globals.presentAlert('The requested time you have selected has already past');
          return false;
        }
      }
    }

    return true;
  }

  public openWarning() {
    this.warningOpened = true;
    this.globals.presentAlert(`Same day and next day services: let's give it a try! Just a heads up that in some cases
                        it may be difficult to have your order filled on such short notice. We encourage you to
                        book services more than 24-hours in advance where possible!`);
  }

  public switch() {
    if (this.type === 2) {
      this.type = 3;
      this.phrase = 'When would you like your next service to start?';
      this.switchMsg = 'Reschedule the date & time of current service';
    } else {
      this.type = 2;
      this.phrase = 'When would you like this service to start?';
      this.switchMsg = 'Reschedule the date & time of the next occurring service';
    }
  }
}
