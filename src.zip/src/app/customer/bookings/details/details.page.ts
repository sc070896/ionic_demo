import {Component, OnInit, ViewChild} from '@angular/core';
import {AlertController, ModalController, NavController, Events, IonRefresher} from '@ionic/angular';
import {Globals} from '../../../globals';
import {AgmMap} from '@agm/core';
import {BookingsService} from '../../../services/customer/bookings/bookings.service';
import {PusherService} from '../../../services/customer/auth/pusher.service';
import {UpdateServiceDetailsPage} from '../update-service-details/update-service-details.page';
import {UpdateServiceLocationPage} from '../update-service-location/update-service-location.page';
import {RescheduleService} from '../../../services/customer/bookings/reschedule.service';
import {BookingService} from '../../../services/general/booking.service';
import {ReschedulePage} from '../reschedule/reschedule.page';
import {ExtendPage} from '../extend/extend.page';

@Component({
  selector: 'app-details',
  templateUrl: './details.page.html',
  styleUrls: ['./details.page.scss'],
})
export class DetailsPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;
  @ViewChild('agmMap') agmMap: AgmMap;
  public b: any;
  loading: any;
  public user: any;
  // set google maps defaults
  public latitude: number;
  public longitude: number;
  public zoom: number;

  public channelBinded = false;
  public extend_hours = 1;
  public extend_minutes = 0;
  public service_details = '';

  constructor(public navController: NavController, private modalController: ModalController, public globals: Globals, public events: Events,
              public bookingsService: BookingsService,
              public pusherService: PusherService, public alertController: AlertController, public rescheduleService: RescheduleService,
              public bookingService: BookingService) {
  }

  async ngOnInit() {
    this.init();

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.getBooking();
    });
  }

  async init() {
    setTimeout(() => {
      this.latitude = this.b.customer_latitude;
      this.longitude = this.b.customer_longitude;
      this.zoom = 13;
      this.agmMap.triggerResize();
    }, 500);
    await this.handleNotifications();
  }

  public back() {
    this.modalController.dismiss({
      b: this.b
    });
  }

  async goChat(booking: any) {
    this.modalController.dismiss({
      b: this.b
    });
    this.navController.navigateForward('customer/bookings/chat/' + booking.uuid_booking);
  }

  public goToProfile(username) {
    this.modalController.dismiss({});
    this.navController.navigateForward('zengiver/profile/' + username);
  }

  public initials(name: string) {
    return this.globals.initials(name);
  }

  public formatHours(h: number) {
    return this.globals.formatHours(h);
  }

  public go(route: string) {
    this.modalController.dismiss({
      b: this.b
    });
    this.navController.navigateForward(route);
  }

  public checkCancel() {
    let cancel_message = '';
    this.globals.presentLoading('Loading...').then((resLoading) => {
      this.bookingsService.checkCancel(this.b.uuid_booking, this.b.customer.uuid_customer)
        .subscribe((res: any) => {
          console.log(res);
          cancel_message = res.message;
          this.globals.loading.dismiss();
          this.cancel(cancel_message);
        }, (err) => {
          const msg = err.error.error;
          this.globals.presentAlert(msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.loading.dismiss();
    });
  }

  async cancel(message) {
    const alert = await this.alertController.create({
      header: 'Cancel Service?',
      message: message,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.bookingsService.cancel(this.b.uuid_booking, this.b.customer.uuid_customer)
                .subscribe((res: any) => {
                  console.log(res);
                  this.b = res.booking;
                  if(parseInt(this.b.price) > 0){
                    this.b.price = (this.b.price / ( 1 + (this.b.supplier.membershipPlans[0].charge_percentage/100))).toFixed(2);
                  }
                  this.globals.presentAlert(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async noShow() {
    const alert = await this.alertController.create({
      header: 'No Show?',
      message: 'Did the zenGiver not show up to your service?',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.bookingsService.noShow(this.b.id)
                .subscribe((res: any) => {
                  this.b = res.booking;
                  this.globals.presentAlert(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async extendForm() {
    const modal = await this.modalController.create({
      component: ExtendPage,
      componentProps: <any>{b: this.b}
    });

    modal.onDidDismiss().then((res) => {
      if (Object.keys(res.data).length) {
        this.b = res.data.b;
      }
    });

    return await modal.present();
  }

  public extend() {
    this.globals.presentLoading('Loading...').then((resLoading) => {
      this.bookingsService.extend(this.b.id, this.extend_hours, this.extend_minutes)
        .subscribe((res: any) => {
          console.log(res);
          this.b = res.booking;
          this.globals.presentAlert(res.success);
          this.globals.loading.dismiss();
        }, (err) => {
          console.log(err);
          const msg = err.error.error;
          this.globals.presentAlert(msg);
          this.globals.loading.dismiss();
        });
    });
  }

  async acceptExpenses(id) {
    const alert = await this.alertController.create({
      header: 'Accept Expenses?',
      message: '',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.bookingsService.acceptExpenses(id)
                .subscribe((res: any) => {
                  this.b = res.booking;
                  this.globals.presentAlert(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async declineExpenses(id) {
    const alert = await this.alertController.create({
      header: 'Reject Expenses?',
      message: '',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.bookingsService.declineExpenses(id)
                .subscribe((res: any) => {
                  this.b = res.booking;
                  this.globals.presentAlert(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async updateServiceDetails() {
    const modal = await this.modalController.create({
      component: UpdateServiceDetailsPage,
      componentProps: <any>{b: this.b}
    });

    modal.onDidDismiss().then((res) => {
      if (Object.keys(res.data).length) {
        this.b = res.data.b;
      }
    });

    return await modal.present();
  }

  async updateServiceLocation() {
    const modal = await this.modalController.create({
      component: UpdateServiceLocationPage,
      componentProps: <any>{b: this.b}
    });

    modal.onDidDismiss().then((res) => {
      if (Object.keys(res.data).length) {
        this.b = res.data.b;
      }
    });

    return await modal.present();
  }

  public getBooking() {
    this.bookingService.getBookingByUuid(this.b.uuid_booking).subscribe((result: any) => {
      this.b = result;
      this.init();
      this.refresher.complete();
    }, (err) => {
      console.log(err);
    });
  }

  async handleNotifications() {
    let channel = this.pusherService.init();
    if (channel === undefined) {
      channel = this.pusherService.init();
    }
    setInterval(() => {
      if (channel === undefined) {
        channel = this.pusherService.init();
      } else {
        if (!this.channelBinded) {
          channel.bind('Illuminate\\Notifications\\Events\\BroadcastNotificationCreated', (event) => {
            if (event.booking_uuid === this.b.uuid_booking) {
              if (
                event.type === 'App\\Notifications\\Customer\\SupplierAcceptedBooking' ||
                event.type === 'App\\Notifications\\Customer\\SupplierDeclinedBooking' ||
                event.type === 'App\\Notifications\\Customer\\CancelNormalBooking' ||
                event.type === 'App\\Notifications\\Customer\\CancelFullBooking' ||
                event.type === 'App\\Notifications\\Customer\\CancelPartialBooking' ||
                event.type === 'App\\Notifications\\Customer\\SupplierCancelledBooking' ||
                event.type === 'App\\Notifications\\Customer\\SupplierStartedBooking' ||
                event.type === 'App\\Notifications\\Customer\\SupplierFinishedBooking' ||
                event.type === 'App\\Notifications\\Customer\\SupplierConsiderBooking' ||
                event.type === 'App\\Notifications\\Customer\\BookingExpired' ||
                event.type === 'App\\Notifications\\Customer\\SupplierNoShow'
              ) {
                this.b.status = event.status;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Rescheduled'
              ) {
                this.b.time = event.request_time;
                this.b.date = event.date;
                this.b.duration = event.duration;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierAcceptedReschedule'
              ) {
                this.b.time = event.request_time;
                this.b.date = event.date;
                this.b.duration = event.duration;
                this.b.reschedule_request = null;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierCreatedReschedule'
              ) {
                this.b.reschedule_request = event.reschedule_request;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierDeclinedReschedule' ||
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierCancelledReschedule'
              ) {
                this.b.reschedule_request = null;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierCreatedRecurringReschedule'
              ) {
                this.b.reschedule_recurring_request = event.reschedule_recurring_request;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierDeclinedRecurringReschedule' ||
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierAcceptedRecurringReschedule' ||
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierCancelledRecurringReschedule'
              ) {
                this.b.reschedule_recurring_request = null;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\NewChatMessage'
              ) {
                this.b.conversation.customer_unread_messages = event.messages_count;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Expenses\\SupplierSubmittedExpenses'
              ) {
                this.b.booking_expenses.data.push(event.expenses);
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Expenses\\SupplierRemovedExpenses'
              ) {
                const index = this.b.booking_expenses.data.findIndex(x => x.id === event.expenses.id);
                if (index > -1) {
                  this.b.booking_expenses.data.splice(index, 1);
                }
              }

              if (
                event.type === 'App\\Notifications\\Customer\\SupplierScheduledFlexible'
              ) {
                this.b.flexible_request = event.flexible_request;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\SupplierCancelledFlexible'
              ) {
                this.b.flexible_request = null;
              }

            }
            console.log(event);
          });
          this.channelBinded = true;
        }
      }
    }, 500);
  }

  public checkForFlexibleRequest() {
    return this.b.flexible === 1 && this.b.is_asap === 1 && this.b.flexible_request && Object.keys(this.b.flexible_request).length !== 0;
  }

  async acceptFlexbileRequest() {
    const alert = await this.alertController.create({
      header: 'Accept the date and time requested by your zenGiver?',
      message: this.b.flexible_request.formatted_service_date + ' - ' + this.b.flexible_request.formatted_service_time,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.acceptFlexibleReschedule(this.b.id)
                .subscribe((res: any) => {
                  this.b.flexible_request = null;
                  this.b = res.booking;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async declineFlexbileRequest() {
    const alert = await this.alertController.create({
      header: 'Decline the date and time requested by your zenGiver?',
      message: this.b.flexible_request.formatted_service_date + ' - ' + this.b.flexible_request.formatted_service_time,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.declineFlexibleReschedule(this.b.id)
                .subscribe((res: any) => {
                  this.b.flexible_request = null;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  // Two way reschedule
  public checkForTwoWayReschedule() {
    return this.b.reschedule_request && Object.keys(this.b.reschedule_request).length !== 0
      && this.b.reschedule_request.status !== 'accepted';
  }

  async openReschedule() {
    const modal = await this.modalController.create({
      component: ReschedulePage,
      componentProps: <any>{
        booking: this.b,
        type: 2,
        user: this.user,
      }
    });

    modal.onDidDismiss().then((res) => {
      this.b = res.data.booking;
    });

    return await modal.present();
  }

  async cancelTwoWayRequest() {
    const alert = await this.alertController.create({
      header: 'Cancel your current reschedule request?',
      message: 'You can send another request after cancelling',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.cancelTwoWayReschedule(this.b.id)
                .subscribe((res: any) => {
                  this.b.reschedule_request = null;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async acceptTwoWayRequest() {
    const alert = await this.alertController.create({
      header: 'Accept reschedule request?',
      message: this.b.reschedule_request.formatted_service_date + ' - ' + this.b.reschedule_request.formatted_service_time,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.acceptTwoWayReschedule(this.b.id)
                .subscribe((res: any) => {
                  this.b = res.booking;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async declineTwoWayRequest() {
    const alert = await this.alertController.create({
      header: 'Decline service being rescheduled?',
      message: this.b.reschedule_request.formatted_service_date + ' - ' + this.b.reschedule_request.formatted_service_time,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.declineTwoWayReschedule(this.b.id)
                .subscribe((res: any) => {
                  this.b = res.booking;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  // Two way recurring reschedule
  public checkForTwoWayRecurringReschedule() {
    return this.b.reschedule_recurring_request && Object.keys(this.b.reschedule_recurring_request).length !== 0
      && this.b.reschedule_recurring_request.status !== 'accepted';
  }

  async cancelTwoWayRecurringRequest() {
    const alert = await this.alertController.create({
      header: 'Cancel your current reschedule request?',
      message: 'You can send another request after cancelling',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.cancelTwoWayRecurringReschedule(this.b.id)
                .subscribe((res: any) => {
                  this.b.reschedule_recurring_request = null;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async acceptTwoWayRecurringRequest() {
    const alert = await this.alertController.create({
      header: 'Accept your next service to be rescheduled?',
      message: this.b.reschedule_recurring_request.formatted_service_date + ' - '
        + this.b.reschedule_recurring_request.formatted_service_time,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.acceptTwoWayRecurringReschedule(this.b.id)
                .subscribe((res: any) => {
                  this.b = res.booking;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async declineTwoWayRecurringRequest() {
    const alert = await this.alertController.create({
      header: 'Decline your next service being rescheduled?',
      message: this.b.reschedule_recurring_request.formatted_service_date + ' - '
        + this.b.reschedule_recurring_request.formatted_service_time,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.declineTwoWayRecurringReschedule(this.b.id)
                .subscribe((res: any) => {
                  this.b = res.booking;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }
}
