import {Component, ElementRef, NgZone, OnInit, ViewChild} from '@angular/core';
import {AlertController, ModalController, NavController} from '@ionic/angular';
import {Globals} from '../../../globals';
import {MapsAPILoader} from '@agm/core';
import {BookingsService} from '../../../services/customer/bookings/bookings.service';
import {PusherService} from '../../../services/customer/auth/pusher.service';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-update-service-location',
  templateUrl: './update-service-location.page.html',
  styleUrls: ['./update-service-location.page.scss'],
})
export class UpdateServiceLocationPage implements OnInit {
  @ViewChild('search', {read: ElementRef}) searchElementRef: ElementRef;

  personalForm: FormGroup;
  b: any;
  latitude: any;
  longitude: any;
  zoom: any;

  constructor(public navController: NavController, private modalController: ModalController, public globals: Globals,
              private mapsAPILoader: MapsAPILoader, private ngZone: NgZone, public bookingsService: BookingsService,
              public pusherService: PusherService, public alertController: AlertController, private formBuilder: FormBuilder) {
    this.personalForm = this.formBuilder.group({
      address: ['', Validators.compose([
        Validators.required
      ])],
      address_unit: [''],
      country: ['', Validators.compose([
        Validators.required
      ])],
      state: ['', Validators.compose([
        Validators.required
      ])],
      city: ['', Validators.compose([
        Validators.required
      ])],
      postal_code: [''],
      latitude: ['', Validators.compose([
        Validators.required
      ])],
      longitude: ['', Validators.compose([
        Validators.required
      ])],
    });
  }

  ngOnInit() {
    this.zoom = 4;
    this.latitude = this.b.customer_latitude;
    this.longitude = this.b.customer_longitude;
    this.loadMap();
    this.personalForm.controls['address'].setValue(this.b.customer_location);
    this.personalForm.controls['country'].setValue(this.b.country_code);
    this.personalForm.controls['state'].setValue(this.b.state);
    this.personalForm.controls['city'].setValue(this.b.city);
    this.personalForm.controls['latitude'].setValue(this.b.customer_latitude);
    this.personalForm.controls['longitude'].setValue(this.b.customer_longitude);
    this.personalForm.controls['address_unit'].setValue(this.b.address_unit);
  }

  public back() {
    this.modalController.dismiss({});
  }

  public update() {
    const data = {
      customer_location: this.personalForm.controls['address'].value,
      country_code: this.personalForm.controls['country'].value,
      state: this.personalForm.controls['state'].value,
      city: this.personalForm.controls['city'].value,
      customer_latitude: this.personalForm.controls['latitude'].value,
      customer_longitude: this.personalForm.controls['longitude'].value,
      address_unit: this.personalForm.controls['address_unit'].value,
    };
    this.globals.presentLoading('Loading...').then((resLoading) => {
      this.bookingsService.updateServiceLocation(this.b.id, data)
        .subscribe((res: any) => {
          console.log(res);
          this.b = res.booking;
          this.globals.presentAlert(res.msg);
          this.globals.loading.dismiss();
          this.modalController.dismiss({
            b: this.b
          });
        }, (err) => {
          console.log(err);
          const msg = err.error.msg;
          this.globals.presentAlert(msg);
          this.globals.loading.dismiss();
        });
    });
  }

  private loadMap() {
    // load Places Autocomplete
    this.mapsAPILoader.load().then(() => {
      console.log(google); // returns undefined, expected object here
      const autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: ['address']
      });
      autocomplete.addListener('place_changed', () => {
        this.ngZone.run(() => {
          // get the place result
          const place = autocomplete.getPlace();

          // verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          place.address_components.forEach((item) => {
            if (item.types.includes('country')) {
              this.personalForm.controls['country'].setValue(item.short_name);
            }
            if (item.types.includes('administrative_area_level_1')) {
              this.personalForm.controls['state'].setValue(item.short_name);
            }
            if (item.types.includes('locality')) {
              this.personalForm.controls['city'].setValue(item.short_name);
            }
          });
          // set latitude, longitude and zoom
          this.latitude = place.geometry.location.lat();
          this.longitude = place.geometry.location.lng();
          this.personalForm.controls['latitude'].setValue(place.geometry.location.lat());
          this.personalForm.controls['longitude'].setValue(place.geometry.location.lng());
          this.zoom = 12;
        });
      });
    });
  }
}
