import {Component, Input, OnInit} from '@angular/core';
import {BookingsService} from '../../../services/supplier/bookings/bookings.service';
import {LoadingController, ModalController, NavController, ToastController} from '@ionic/angular';
import {Globals} from '../../../globals';
import {PusherService} from '../../../services/customer/auth/pusher.service';
import {DetailsPage} from '../details/details.page';

@Component({
  selector: 'app-booking-card',
  templateUrl: './booking-card.component.html',
  styleUrls: ['./booking-card.component.scss']
})
export class BookingCardComponent implements OnInit {
  @Input() b: any;
  @Input() user: any;
  public channelBinded = false;
  public reschedule_request: any;
  public start_time: any;
  public start_date: any;
  public the_duration: any;
  public flexible_request: any;

  constructor(public bookingsService: BookingsService, public modalController: ModalController,
              private navController: NavController, public globals: Globals,
              public loadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public pusherService: PusherService) {
  }

  async ngOnInit() {
    await this.handleNotifications();
  }

  public goToProfile(username) {
    this.navController.navigateForward('zengiver/profile/' + username);
  }

  async goChat(booking: any) {
    this.navController.navigateForward('customer/bookings/chat/' + booking.uuid_booking);
  }

  async goDetails(booking: any) {
    const modal = await this.modalController.create({
      component: DetailsPage,
      componentProps: <any>{
        b: booking,
        user: this.user
      }
    });

    modal.onDidDismiss().then((res: any) => {
      this.b = res.data.b;
    });

    return await modal.present();
  }

  public initials(name: string) {
    return this.globals.initials(name);
  }

  public formatHours(h: number) {
    return this.globals.formatHours(h);
  }

  async handleNotifications() {
    let channel = this.pusherService.init();
    if (channel === undefined) {
      channel = this.pusherService.init();
    }
    setInterval(() => {
      if (channel === undefined) {
        channel = this.pusherService.init();
      } else {
        if (!this.channelBinded) {
          channel.bind('Illuminate\\Notifications\\Events\\BroadcastNotificationCreated', (event) => {
            if (event.booking_uuid === this.b.uuid_booking) {
              if (
                event.type === 'App\\Notifications\\Customer\\SupplierAcceptedBooking' ||
                event.type === 'App\\Notifications\\Customer\\SupplierDeclinedBooking' ||
                event.type === 'App\\Notifications\\Customer\\CancelNormalBooking' ||
                event.type === 'App\\Notifications\\Customer\\CancelFullBooking' ||
                event.type === 'App\\Notifications\\Customer\\CancelPartialBooking' ||
                event.type === 'App\\Notifications\\Customer\\SupplierCancelledBooking' ||
                event.type === 'App\\Notifications\\Customer\\SupplierStartedBooking' ||
                event.type === 'App\\Notifications\\Customer\\SupplierFinishedBooking' ||
                event.type === 'App\\Notifications\\Customer\\SupplierConsiderBooking' ||
                event.type === 'App\\Notifications\\Customer\\BookingExpired' ||
                event.type === 'App\\Notifications\\Customer\\SupplierNoShow'
              ) {
                this.b.status = event.status;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Rescheduled'
              ) {
                this.b.time = event.request_time;
                this.b.date = event.date;
                this.b.duration = event.duration;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierAcceptedReschedule'
              ) {
                this.b.time = event.request_time;
                this.b.date = event.date;
                this.b.duration = event.duration;
                this.b.reschedule_request = null;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierCreatedReschedule'
              ) {
                this.b.reschedule_request = event.reschedule_request;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierDeclinedReschedule' ||
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierCancelledReschedule'
              ) {
                this.b.reschedule_request = null;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierCreatedRecurringReschedule'
              ) {
                this.b.reschedule_recurring_request = event.reschedule_recurring_request;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierDeclinedRecurringReschedule' ||
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierAcceptedRecurringReschedule' ||
                event.type === 'App\\Notifications\\Customer\\Reschedules\\SupplierCancelledRecurringReschedule'
              ) {
                this.b.reschedule_recurring_request = null;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\NewChatMessage'
              ) {
                this.b.conversation.customer_unread_messages = event.messages_count;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Expenses\\SupplierSubmittedExpenses'
              ) {
                this.b.booking_expenses.data = null;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\Expenses\\SupplierRemovedExpenses'
              ) {
                const index = this.b.booking_expenses.data.findIndex(x => x.id === event.expenses.id);
                if (index > -1) {
                  this.b.booking_expenses.data.splice(index, 1);
                }
              }

              if (
                event.type === 'App\\Notifications\\Customer\\SupplierScheduledFlexible'
              ) {
                this.b.flexible_request = event.flexible_request;
              }

              if (
                event.type === 'App\\Notifications\\Customer\\SupplierCancelledFlexible'
              ) {
                this.b.flexible_request = null;
              }

            }
            console.log(event);
          });
          this.channelBinded = true;
        }
      }
    }, 500);
  }
}
