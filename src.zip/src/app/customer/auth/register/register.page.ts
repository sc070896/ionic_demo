import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {AgreementsComponent} from '../../../general/components/agreements/agreements.component';
import {RegistrationService} from '../../../services/general/registration.service';
import {ModalController, NavController} from '@ionic/angular';
import {RegisterService} from '../../../services/customer/auth/register.service';
import {LoginService} from '../../../services/customer/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  accountForm: FormGroup;
  terms_of_use: string;
  privacy_policy: string;

  constructor(private formBuilder: FormBuilder, private registrationService: RegistrationService, public registerService: RegisterService,
              private modalController: ModalController, private navController: NavController, private loginService: LoginService,
              private globals: Globals, private storage: Storage) {
    this.accountForm = this.formBuilder.group({
      first_name: ['', Validators.compose([
        Validators.required
      ])
      ],
      last_name: ['', Validators.compose([
        Validators.required
      ])
      ],
      email: ['', Validators.compose([
        Validators.email,
        Validators.required
      ])
      ],
      password: [
        '', Validators.compose([
          Validators.min(8),
          Validators.required
        ])
      ],
      terms_of_use: [
        false, Validators.compose([
          Validators.required
        ])
      ],
      privacy_policy: [
        false, Validators.compose([
          Validators.required
        ])
      ]
    });
  }

  getTermsOfUse() {
    this.registrationService.getLegal('terms-of-use-agreement').subscribe((r: any) => {
      this.terms_of_use = r.data;
    }, (err) => {
      console.error(err);
    });
  }

  getPrivacyPolicy() {
    this.registrationService.getLegal('privacy-policy').subscribe((r: any) => {
      this.privacy_policy = r.data;
    }, (err) => {
      console.error(err);
    });
  }

  // Agree / disagree to terms of use
  async presentTermsOfUseModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: {data: this.terms_of_use}
    });

    modal.onDidDismiss().then((res) => {
      this.accountForm.controls['terms_of_use'].setValue(res.data.data);
    });

    return await modal.present();
  }

  // Agree to privacy policy
  async presentPrivacyPolicyModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: {data: this.privacy_policy}
    });

    modal.onDidDismiss().then((res) => {
      this.accountForm.controls['privacy_policy'].setValue(res.data.data);
    });

    return await modal.present();
  }

  public register() {
    const first_name = this.accountForm.controls['first_name'].value;
    const last_name = this.accountForm.controls['last_name'].value;
    const email = this.accountForm.controls['email'].value;
    const password = this.accountForm.controls['password'].value;

    this.globals.presentLoading('Registering...').then((res) => {
      this.registerService.register(first_name, last_name, email, password).subscribe((r: any) => {
        this.globals.loading.dismiss();
        this.loginUser();
      }, (err) => {
        const errMsg = err.error.msg;
        this.globals.loading.dismiss();
        this.globals.presentAlert(errMsg);
      });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }

  public loginUser() {
    const email = this.accountForm.controls['email'].value;
    const password = this.accountForm.controls['password'].value;

    Object.keys(this.accountForm.controls).forEach(field => {
      const control = this.accountForm.get(field);
      control.markAsTouched({onlySelf: true});
    });

    this.globals.presentLoading('Logging in...').then((res) => {
      this.loginService.login(email, password).subscribe((r: any) => {
          this.storage.set('login_type', 'customer').then((loginRes) => {
            this.storage.set('access_token', r.access_token).then((stRes) => {
                this.navController.navigateRoot('customer/dashboard/tabs/(home:home)');
              },
              (err) => {
                this.navController.navigateRoot('customer/dashboard/tabs/(home:home)');
              });
          });
          this.globals.loading.dismiss();
        },
        (err) => {
          const errMsg = err.error.msg;
          this.globals.loading.dismiss();
          this.globals.presentAlert(errMsg);
        }, () => {
          this.globals.loading.dismiss();
        });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }

  public login() {
    this.navController.navigateRoot('customer/login');
  }

  ngOnInit() {
    this.getPrivacyPolicy();
    this.getTermsOfUse();
  }

}
