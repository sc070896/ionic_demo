import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {AlertController, LoadingController, NavController} from '@ionic/angular';
import {LoginService} from '../../../services/customer/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {OneSignal} from '@ionic-native/onesignal/ngx';
import {Facebook, FacebookLoginResponse} from '@ionic-native/facebook/ngx';
import {GooglePlus} from '@ionic-native/google-plus/ngx';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  credentialsForm: FormGroup;

  constructor(private navController: NavController, private formBuilder: FormBuilder, private oneSignal: OneSignal,
              public loginService: LoginService, public globals: Globals, public storage: Storage, public fb: Facebook,
              private googlePlus: GooglePlus) {
    this.credentialsForm = this.formBuilder.group({
      email: ['', Validators.compose([
        Validators.email,
        Validators.required
      ])],
      password: ['', Validators.compose([
        Validators.min(6),
        Validators.required
      ])]
    });
  }

  public goToRegister() {
    this.navController.navigateForward('customer/register');
  }

  public goToZengiverSignIn() {
    this.navController.navigateForward('zengiver/login');
  }

  public goToForgotPassword() {
    this.navController.navigateForward('customer/forget-password');
  }

  public go(route: string) {
    this.navController.navigateForward(route);
  }

  public login() {
    const email = this.credentialsForm.controls['email'].value;
    const password = this.credentialsForm.controls['password'].value;

    Object.keys(this.credentialsForm.controls).forEach(field => {
      const control = this.credentialsForm.get(field);
      control.markAsTouched({onlySelf: true});
    });

    this.globals.presentLoading('Logging in...').then((res) => {
      this.loginService.login(email, password).subscribe((r: any) => {
          this.storage.set('login_type', 'customer').then((loginRes) => {
            this.storage.set('access_token', r.access_token).then((stRes) => {
                this.storage.set('user', r.user);
                this.storage.set('signin_type', 'normal');

                // Set this one signal device tag - customers_uuid to this customers uuid so
                // we can send push notifications associated with this user
                this.oneSignal.sendTag('customers_uuid', r.user.uuid);

                this.navController.navigateRoot('customer/dashboard/tabs/(home:home)');
              },
              (err) => {
                this.navController.navigateRoot('customer/dashboard/tabs/(home:home)');
              });
          });
          this.globals.loading.dismiss();
        },
        (err) => {
          console.log(err.error);
          const errMsg = err.error.msg;
          this.globals.loading.dismiss();
          this.globals.presentTopToast(errMsg);
        }, () => {
          this.globals.loading.dismiss();
        });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }

  public facebookLogin() {
    // Login with permissions
    this.fb.login(['public_profile', 'email'])
      .then((res: FacebookLoginResponse) => {

        // The connection was successful
        if (res.status === 'connected') {

          // Get user ID and Token
          const fb_id = res.authResponse.userID;
          const fb_token = res.authResponse.accessToken;

          // Get user infos from the API
          this.fb.api('/me?fields=name,email', []).then((user) => {

            // Get the connected user details
            const birthday = user.birthday;
            const name = user.name;
            const email = user.email;

            console.log('=== USER INFOS ===');
            console.log('Name : ' + name);
            console.log('Email : ' + email);

            // => Open user session and redirect to the next page
            const nameArr = name.split(' ');
            const data = {
              email: email,
              first_name: nameArr[0],
              last_name: nameArr[1],
              social_login: true,
              social_type: 'facebook',
            };

            this.globals.presentLoading('Logging in...').then((res) => {
              this.loginService.sccialLogin(data).subscribe((r: any) => {
                  this.storage.set('login_type', 'customer').then((loginRes) => {
                    this.storage.set('access_token', r.access_token).then((stRes) => {
                        this.storage.set('user', r.user);
                        this.storage.set('signin_type', 'facebook');

                        // Set this one signal device tag - customers_uuid to this customers uuid so
                        // we can send push notifications associated with this user
                        this.oneSignal.sendTag('customers_uuid', r.user.uuid);

                        this.navController.navigateRoot('customer/dashboard/tabs/(home:home)');
                      },
                      (err) => {
                        this.navController.navigateRoot('customer/dashboard/tabs/(home:home)');
                      });
                  });
                  this.globals.loading.dismiss();
                },
                (err) => {
                  console.log(err.error);
                  const errMsg = err.error.msg;
                  this.globals.loading.dismiss();
                  this.globals.presentTopToast(errMsg);
                }, () => {
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              console.log(err);
              this.globals.loading.dismiss();
            });
          });

        } else {
          console.log('An error occurred...');
        }
      })
      .catch((e) => {
        console.log('Error logging into Facebook', e);
      });
  }

  public googleLogin() {
    this.googlePlus.getSigningCertificateFingerprint().then((res) => {
      console.log(res);
    });
    this.googlePlus.login({
      'scopes': 'profile email'
    })
      .then((res) => {
        console.log(res);
        const data = {
          email: res.email,
          first_name: res.givenName,
          last_name: res.familyName,
          social_login: true,
          social_type: 'google',
        };

        this.globals.presentLoading('Logging in...').then((res) => {
          this.loginService.sccialLogin(data).subscribe((r: any) => {
              this.storage.set('login_type', 'customer').then((loginRes) => {
                this.storage.set('access_token', r.access_token).then((stRes) => {
                    this.storage.set('user', r.user);
                    this.storage.set('signin_type', 'google');

                    // Set this one signal device tag - customers_uuid to this customers uuid so
                    // we can send push notifications associated with this user
                    this.oneSignal.sendTag('customers_uuid', r.user.uuid);

                    this.navController.navigateRoot('customer/dashboard/tabs/(home:home)');
                  },
                  (err) => {
                    this.navController.navigateRoot('customer/dashboard/tabs/(home:home)');
                  });
              });
              this.globals.loading.dismiss();
            },
            (err) => {
              console.log(err.error);
              const errMsg = err.error.msg;
              this.globals.loading.dismiss();
              this.globals.presentTopToast(errMsg);
            }, () => {
              this.globals.loading.dismiss();
            });
        }, (err) => {
          console.log(err);
          this.globals.loading.dismiss();
        });

      })
      .catch((err) => {
        console.error(err);
        this.globals.presentTopToast('Failed to login. Please try again');
      });
  }

  ngOnInit() {
  }
}
