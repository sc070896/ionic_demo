import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {AlertController, LoadingController, NavController} from '@ionic/angular';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {PasswordResetService} from '../../../services/customer/auth/password-reset.service';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.page.html',
  styleUrls: ['./forget-password.page.scss'],
})
export class ForgetPasswordPage implements OnInit {

  forgetPasswordForm: FormGroup;

  constructor(private navController: NavController, private formBuilder: FormBuilder,
              public passwordResetService: PasswordResetService, public globals: Globals, public storage: Storage) {
    this.forgetPasswordForm = this.formBuilder.group({
      email: ['', Validators.compose([
        Validators.email,
        Validators.required
      ])]
    });
  }

  public resetPassword() {
    const email = this.forgetPasswordForm.controls['email'].value;

    this.globals.presentLoading('Checking email...').then((res) => {
      this.passwordResetService.resetPassword(email).subscribe((r: any) => {
          console.log(r);
          const msg = r.msg;
          this.globals.presentTopToast(msg);
          this.navController.navigateRoot('customer/login');
        },
        (err) => {
          console.log(err.error);
          const errMsg = err.error.msg;
          this.globals.loading.dismiss();
          this.globals.presentTopToast(errMsg);
        }, () => {
          this.globals.loading.dismiss();
        });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }

  ngOnInit() {
  }

}
