import {Component, OnInit, ViewChild} from '@angular/core';
import {NavController, IonSlides, IonRefresher, Events} from '@ionic/angular';
import {FormBuilder} from '@angular/forms';
import {LoginService} from '../../../services/customer/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {CategoriesService} from '../../../services/general/categories.service';
import {Facebook} from '@ionic-native/facebook/ngx';
import {GooglePlus} from '@ionic-native/google-plus/ngx';
import {PusherService} from '../../../services/customer/auth/pusher.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss']
})
export class HomePage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;
  @ViewChild('adslides') ad_slides: IonSlides;
  @ViewChild('servicesslides') services_slides: IonSlides;
  slideOpts = {
    slidesPerView: 2,
    autoplay: {
      delay: 5000,
    }
  };
  public customer: any;
  public general_services: any;
  public all_services: any;
  public loading_general = true;
  public loading_all = true;

  constructor(private navController: NavController, private formBuilder: FormBuilder, public categoriesService: CategoriesService,
              public loginService: LoginService, public globals: Globals, private storage: Storage, public events: Events,
              public fb: Facebook, private googlePlus: GooglePlus, public pusherService: PusherService) {
  }

  ngOnInit() {
    this.init();

    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.init();
    });
  }

  public init() {
    this.getAllServices();
    this.getGeneralServices();
    this.getUser();
  }

  public getUser() {
    this.loginService.user().subscribe((r: any) => {
        console.log(r);
        this.customer = r;
        this.storage.set('user', r).then((loginRes) => {
        });
        this.refresher.complete();
      },
      (err) => {
      });
  }

  public logout() {
    this.globals.presentLoading('Logging out...').then((res) => {
      this.loginService.logout().subscribe((r: any) => {
          console.log(r);
          this.pusherService.unsubscribe();
          this.globals.loading.dismiss();
          this.storage.remove('access_token').then((stRes) => {
              // Depending on the what you signed in with (facebook, google) logout from those services
              this.storage.get('signin_type').then((signInRes) => {
                console.log(signInRes);
                if (signInRes === 'facebook') {
                  this.fb.logout();
                } else if (signInRes === 'google') {
                  this.googlePlus.logout();
                }
              });
              this.storage.remove('user');
              this.navController.navigateRoot('customer/login');
            },
            (err) => {
              let errMsg = err.error.msg;
              this.globals.loading.dismiss();
              if (errMsg === undefined) {
                errMsg = 'Failed to logout';
              }
              this.globals.presentAlert(errMsg);
            });
        },
        (err) => {
          let errMsg = err.error.msg;
          this.globals.loading.dismiss();
          if (errMsg === undefined) {
            errMsg = 'Failed to logout';
          }
          this.globals.presentAlert(errMsg);
        }, () => {
          this.globals.loading.dismiss();
        });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }

  getGeneralServices() {
    this.categoriesService.getSubcategories(1, 1).subscribe((r: any) => {
      this.general_services = r;
      this.loading_general = false;
    }, (err) => {
      console.error(err);
      this.loading_general = false;
    });
  }

  getAllServices() {
    this.categoriesService.getSubcategories(1, 0).subscribe((r: any) => {
      this.all_services = r;
      this.loading_all = false;
    }, (err) => {
      console.error(err);
      this.loading_all = false;
    });
  }

  public order(id) {
    this.navController.navigateForward('customer/order/checkout/' + id);
  }
}
