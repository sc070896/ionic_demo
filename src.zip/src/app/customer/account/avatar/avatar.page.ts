import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalController, NavController, Events, IonRefresher} from '@ionic/angular';
import {Globals} from '../../../globals';
import {CategoriesService} from '../../../services/general/categories.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {AccountService} from '../../../services/customer/account/account.service';
import {Storage} from '@ionic/storage';
import {PhotoPage} from '../../../general/photo/photo.page';

@Component({
  selector: 'app-avatar',
  templateUrl: './avatar.page.html',
  styleUrls: ['./avatar.page.scss'],
})
export class AvatarPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public user: any;
  public description: any;
  public avatar_uploaded = false;
  public hide_avatar_cropper = true;
  croppedImage: any = '../../../../assets/placeholders/avatar_placeholder.svg';
  public randomNumber: any;

  constructor(public navController: NavController, public globals: Globals, public categoriesService: CategoriesService,
              public modalController: ModalController, public registrationService: RegistrationService, public loginService: LoginService,
              public accountService: AccountService, private storage: Storage, public events: Events) {
  }

  ngOnInit() {
    this.randomNumber = Math.random();

    this.storage.get('user').then((user: any) => {
      this.user = user;
    });
    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.getCustomer();
    });
  }

  public getCustomer() {
    this.loginService.user().subscribe((r: any) => {
        this.randomNumber = Math.random();
        this.user = r;
        this.storage.set('user', r).then((loginRes) => {
          this.refresher.complete();
        });
      },
      (err) => {
        this.refresher.complete();
      });
  }

  public updateAvatar() {
    if (!this.avatar_uploaded) {
      this.globals.presentToast(`Upload a photo of yourself`);
      return;
    }
    this.globals.presentLoading('Updating...').then((result) => {
      this.accountService.updateAvatar(this.user.id, {avatar: this.croppedImage})
        .subscribe((res: any) => {
          this.randomNumber = Math.random();
          this.globals.loading.dismiss();
          this.globals.presentToast(res.msg);
          this.storage.set('user', res.data);
          this.user = res.data;
          this.user.avatar = res.data.avatar + '?' + Math.random();
          this.hide_avatar_cropper = true;
        }, (err) => {
          this.globals.presentToast('Something went wrong. Please try again.');
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  async openPhotoModal() {
    const modal = await this.modalController.create({
      component: PhotoPage,
      componentProps: <any>{
        width: 400,
        height: 400
      }
    });

    modal.onDidDismiss().then((res) => {
      if (res.data.image !== undefined) {
        this.croppedImage = res.data.image;
        this.avatar_uploaded = true;
      }
    });

    return await modal.present();
  }

  public back() {
    this.navController.navigateRoot('customer/dashboard/tabs/(about:about)');
  }
}
