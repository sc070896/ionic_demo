import {Component, OnInit} from '@angular/core';
import {Globals} from '../../../globals';
import {CategoriesService} from '../../../services/general/categories.service';
import {Storage} from '@ionic/storage';
import {AlertController, ModalController, NavController, IonRefresher, Events} from '@ionic/angular';
import {AccountService} from '../../../services/customer/account/account.service';

@Component({
  selector: 'app-report',
  templateUrl: './report.page.html',
  styleUrls: ['./report.page.scss'],
})
export class ReportPage implements OnInit {
  public user: any;
  public subject = '';
  public message = '';
  constructor(public navController: NavController, public globals: Globals, public categoriesService: CategoriesService,
              public modalController: ModalController, public accountService: AccountService,
              private storage: Storage, public alertController: AlertController, public events: Events) {
  }

  ngOnInit() {
    this.storage.get('user').then((res) => {
      this.user = res;
    });
  }

  async submit() {
    const data = {
      name: this.user.first_name + ' ' + this.user.last_name,
      email: this.user.email,
      subject: this.subject,
      message: this.message
    };
    const alert = await this.alertController.create({
      header: 'Submit?',
      message: '',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.accountService.sendContactUs(data)
                .subscribe((res: any) => {
                  this.subject = '';
                  this.message = '';
                  this.globals.presentTopToast(res.msg);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.msg;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  public back() {
    this.navController.navigateRoot('customer/dashboard/tabs/(support:support)');
  }
}
