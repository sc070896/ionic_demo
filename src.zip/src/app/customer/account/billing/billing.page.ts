import {Component, NgZone, OnInit, ViewChild} from '@angular/core';
import {NavController, Events, IonRefresher} from '@ionic/angular';
import {FormBuilder} from '@angular/forms';
import {MapsAPILoader} from '@agm/core';
import {LoginService} from '../../../services/customer/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {AccountService} from '../../../services/customer/account/account.service';
import * as dropin from 'braintree-web-drop-in';

@Component({
  selector: 'app-billing',
  templateUrl: './billing.page.html',
  styleUrls: ['./billing.page.scss'],
})
export class BillingPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public customer: any;

  nonce = '';
  btoken = '';
  braintree_instance = null;
  device_data = null;
  valid_payment = false;

  constructor(private navController: NavController, private formBuilder: FormBuilder, private mapsAPILoader: MapsAPILoader,
              private ngZone: NgZone, public loginService: LoginService, public globals: Globals, private storage: Storage,
              public accountService: AccountService, public events: Events) {
  }

  ngOnInit() {
    this.storage.get('user').then((res) => {
      this.customer = res;
      this.getCustomerPaymentInfo();
    });

    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.getCustomerPaymentInfo();
    });
  }

  public getCustomerPaymentInfo() {
    this.accountService.getBraintreeNonce(this.customer.id).subscribe((r: any) => {
        console.log(r);
        this.btoken = r.customer_nonce;
        this.loadBraintree();
        this.refresher.complete();
      },
      (err) => {
        console.log(err);
      });
  }

  public loadBraintree() {
    dropin.create({
      authorization: this.btoken,
      selector: '#billing-dropin-container',
      paypal: {
        flow: 'vault'
      }
    }, (err, dropinInstance) => {
      if (err) {
        // Handle any errors that might've occurred when creating Drop-in
        console.log(err);
        // Message.showError(err);
        return;
      }
      this.braintree_instance = dropinInstance;
    });
  }

  public back() {
    this.navController.navigateRoot('customer/dashboard/tabs/(about:about)');
  }
}
