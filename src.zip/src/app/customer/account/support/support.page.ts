import {Component, OnInit, ViewChild} from '@angular/core';
import {Globals} from '../../../globals';
import {AlertController, ModalController, NavController, IonRefresher, Events} from '@ionic/angular';
import {CategoriesService} from '../../../services/general/categories.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {Storage} from '@ionic/storage';
import {AgreementsComponent} from '../../../general/components/agreements/agreements.component';

@Component({
  selector: 'app-support',
  templateUrl: './support.page.html',
  styleUrls: ['./support.page.scss'],
})
export class SupportPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public faq = 'https://zengot.com/support/customer-support-and-faqs';
  public loading = true;
  public terms_of_use: any;
  public privacy_policy: any;
  public refund_policy: any;

  constructor(public navController: NavController, public globals: Globals, public categoriesService: CategoriesService,
              public modalController: ModalController, public registrationService: RegistrationService,
              private storage: Storage, public alertController: AlertController, public events: Events) {
  }

  ngOnInit() {
    this.init();
    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.init();
    });
  }

  public init() {
    this.getTermsOfUse();
    this.getPrivacyPolicy();
    this.getRefundPolicy();
  }

  // Agree / disagree to terms of use
  async presentTermsOfUseModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{
        data: this.terms_of_use,
        hideButtons: true
      }
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  // Agree to privacy policy
  async presentPrivacyPolicyModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{
        data: this.privacy_policy,
        hideButtons: true
      }
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  async presentRefundPolicyModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{
        data: this.refund_policy,
        hideButtons: true
      }
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  getRefundPolicy() {
    this.registrationService.getPage('refund-policy').subscribe((r: any) => {
      this.refund_policy = r.data;
      this.refund_policy.content = r.data.body;
      this.refresher.complete();
      this.loading = false;
    }, (err) => {
      console.error(err);
    });
  }

  getTermsOfUse() {
    this.registrationService.getLegal('terms-of-use-agreement').subscribe((r: any) => {
      this.terms_of_use = r.data;
      this.refresher.complete();
      this.loading = false;
    }, (err) => {
      console.error(err);
    });
  }

  getPrivacyPolicy() {
    this.registrationService.getLegal('privacy-policy').subscribe((r: any) => {
      this.privacy_policy = r.data;
      this.refresher.complete();
      this.loading = false;
    }, (err) => {
      console.error(err);
    });
  }

  public back() {
    this.navController.navigateRoot('customer/dashboard/tabs/(about:about)');
  }

  public go(route: string) {
    this.navController.navigateForward(route);
  }
}
