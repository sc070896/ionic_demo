import {Component, OnInit, ViewChild} from '@angular/core';
import {BookingsService} from '../../../services/customer/bookings/bookings.service';
import {IonInfiniteScroll, LoadingController, ModalController, NavController, IonRefresher, ToastController, Events} from '@ionic/angular';
import {Globals} from '../../../globals';
import {PusherService} from '../../../services/customer/auth/pusher.service';
import {DetailsPage} from '../../../customer/bookings/details/details.page';
import {PaymentDetailsPage} from '../../bookings/payment-details/payment-details.page';
import {FlatpickrOptions} from 'ng2-flatpickr';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.page.html',
  styleUrls: ['./transactions.page.scss'],
})
export class TransactionsPage implements OnInit {
  @ViewChild('inscroll') bookings_scroll: IonInfiniteScroll;
  @ViewChild('refresher') refresher: IonRefresher;
  public bookings = [];
  public keywords = '';
  public sort_by = 'asc';
  public status = 'completed';
  public page = 1;
  public last_page = 4;
  public loading = true;
  public selected_date: any = '';
  public calendar_options: FlatpickrOptions = {
    defaultDate: 'today',
    inline: false,
    onChange: (selectedDates, dateStr, instance) => {
      this.selected_date = dateStr;
      console.log(this.selected_date);
    },
    altInput: true,
    altFormat: 'F j, Y',
    dateFormat: 'Y-m-d',
    minDate: 'today',
    disableMobile: true,
    clickOpens: true
  };
  constructor(public bookingsService: BookingsService, public modalController: ModalController,
              private navController: NavController, public globals: Globals, public events: Events,
              public loadingCtrl: LoadingController, public pusherService: PusherService,
              public toastCtrl: ToastController) {
  }

  ngOnInit() {
    this.getBookings(null);
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.refresh();
    });
  }

  public getBookings(event) {
    this.bookingsService.getBookings(this.status, this.sort_by, this.keywords, this.selected_date, this.page).subscribe((result: any) => {
      const items = result.bookings;
      console.log(result);
      console.log(this.page);
      this.last_page = items.last_page;
      if (items.data.length <= 0 || this.page > this.last_page) { // if the result we get is nothing or page has past last page
        if (event !== null) {
          event.disabled = true;
        }
      } else {
        if (this.page === 1 && items.data.length <= 0) { // No bookings available
          this.bookings = [];
        } else {
          items.data.forEach((item) => {
            this.bookings.push(item);
          });
          if (event !== null) {
            event.complete();
          }
          this.page = items.current_page + 1;
        }
      }
      this.loading = false;
    }, (err) => {
      console.log(err);
      this.loading = false;
    });
  }

  public getDirectWithoutDisabling(event) {
    this.bookingsService.getBookings(this.status, this.sort_by, this.keywords, this.selected_date, this.page).subscribe((result: any) => {
      const items = result.bookings;
      this.last_page = items.last_page;
      this.bookings = [];
      items.data.forEach((item) => {
        this.bookings.push(item);
      });
      if (event !== null) {
        event.complete();
      }
      this.page = items.current_page + 1;
      this.loading = false;
      this.refresher.complete();
    }, (err) => {
      console.log(err);
      this.loading = false;
    });
  }

  public refresh() {
    this.page = 1;
    this.getDirectWithoutDisabling(this.refresher);
  }

  async goDetails(booking: any) {
    const modal = await this.modalController.create({
      component: DetailsPage,
      componentProps: <any>{b: booking}
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  async goEarningDetails(booking: any) {
    const modal = await this.modalController.create({
      component: PaymentDetailsPage,
      componentProps: <any>{b: booking}
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  public formatCurrency(num: any) {
    return parseFloat(num).toFixed(2);
  }

  public formatDate(d: any) {
    return this.globals.formatDate(d);
  }

  public formatDateShort(d: any) {
    return this.globals.formatDateShort(d);
  }

  public formatDateYearMonthDay(d: any) {
    return this.globals.formatDateYearMonthDay(d);
  }

  public initials(name: any) {
    return this.globals.initials(name);
  }

  public back() {
    this.navController.navigateRoot('customer/dashboard/tabs/(about:about)');
  }
}
