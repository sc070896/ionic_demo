import {Component, OnInit, ViewChild} from '@angular/core';
import {AlertController, NavController, Events, IonRefresher} from '@ionic/angular';
import {FormBuilder} from '@angular/forms';
import {LoginService} from '../../../services/customer/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {PusherService} from '../../../services/customer/auth/pusher.service';
import {Facebook} from '@ionic-native/facebook/ngx';
import {GooglePlus} from '@ionic-native/google-plus/ngx';

@Component({
  selector: 'app-about',
  templateUrl: 'about.page.html',
  styleUrls: ['about.page.scss']
})
export class AboutPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public user: any;
  public loading = true;
  public randomNumber: any;

  constructor(private navController: NavController, private formBuilder: FormBuilder, public pusherService: PusherService,
              public loginService: LoginService, public globals: Globals, private storage: Storage, public events: Events,
              public alertController: AlertController, public fb: Facebook, private googlePlus: GooglePlus) {
  }

  ngOnInit() {
    this.randomNumber = Math.random();

    this.getCustomer();
    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.getCustomer();
    });
  }

  public getCustomer() {
    this.loginService.user().subscribe((r: any) => {
        this.randomNumber = Math.random();
        this.user = r;
        this.loading = false;
        this.storage.set('user', r).then((loginRes) => {
          this.refresher.complete();
        });
      },
      (err) => {
      });
  }

  public formatCurrency(num) {
    return this.globals.formatCurrency(num);
  }

  public go(route: string) {
    this.navController.navigateForward(route);
  }

  async logout() {
    const alert = await this.alertController.create({
      header: 'Logout?',
      message: '',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Logging out...').then((res) => {
              this.loginService.logout().subscribe((r: any) => {
                  console.log(r);
                  this.pusherService.unsubscribe();
                  this.globals.loading.dismiss();
                  this.storage.remove('access_token').then((stRes) => {
                      // Depending on the what you signed in with (facebook, google) logout from those services
                      this.storage.get('signin_type').then((signInRes) => {
                        console.log(signInRes);
                        if (signInRes === 'facebook') {
                          this.fb.logout();
                        } else if (signInRes === 'google') {
                          this.googlePlus.logout();
                        }
                      });
                      this.storage.remove('user');
                      this.navController.navigateRoot('customer/login');
                    },
                    (err) => {
                      let errMsg = err.error.msg;
                      this.globals.loading.dismiss();
                      if (errMsg === undefined) {
                        errMsg = 'Failed to logout';
                      }
                      this.globals.presentAlert(errMsg);
                    });
                },
                (err) => {
                  let errMsg = err.error.msg;
                  this.globals.loading.dismiss();
                  if (errMsg === undefined) {
                    errMsg = 'Failed to logout';
                  }
                  this.globals.presentAlert(errMsg);
                }, () => {
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              console.log(err);
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }
}
