import {Component, OnInit, ViewChild} from '@angular/core';
import {AlertController, ModalController, NavController, IonRefresher, Events} from '@ionic/angular';
import {Globals} from '../../../globals';
import {CategoriesService} from '../../../services/general/categories.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {LoginService} from '../../../services/customer/auth/login.service';
import {AccountService} from '../../../services/customer/account/account.service';
import {Storage} from '@ionic/storage';
import {Facebook} from '@ionic-native/facebook/ngx';
import {GooglePlus} from '@ionic-native/google-plus/ngx';
import {PusherService} from '../../../services/customer/auth/pusher.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.page.html',
  styleUrls: ['./settings.page.scss'],
})
export class SettingsPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public user: any;
  public email_types: any = [];
  public loading = true;

  constructor(public navController: NavController, public globals: Globals, public categoriesService: CategoriesService,
              public modalController: ModalController, public registrationService: RegistrationService, public loginService: LoginService,
              public accountService: AccountService, private storage: Storage, public alertController: AlertController,
              public events: Events, public fb: Facebook, private googlePlus: GooglePlus, public pusherService: PusherService) {
  }

  ngOnInit() {
    this.storage.get('user').then((res) => {
      this.user = res;
      this.getEmailTypes();
    });
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.getEmailTypes();
    });
  }

  public getEmailTypes() {
    this.accountService.getEmailPreferences(this.user.id).subscribe((res: any) => {
      this.email_types = res.data;
      this.loading = false;
      this.refresher.complete();
    }, (err) => {
      console.error(err);
    });
  }

  toggleEmailType(asm_group_id) {
    const index = this.email_types.findIndex(e => e.asm_group_id === asm_group_id);
    if (index > -1) {
      this.accountService.toggleEmailType(asm_group_id, this.email_types[index].status, this.user.id).subscribe((res: any) => {
        this.user = res.data;
        this.storage.set('user', this.user).then((storageRes) => {
          this.globals.presentTopToast(res.msg);
        });
      }, (err) => {
        console.error(err);
      });
    }
  }

  toggleSmsPreference(is_chat) {
    this.accountService.toggleSms(is_chat, this.user.id).subscribe((res: any) => {
      this.user = res.data;
      this.storage.set('user', this.user).then((storageRes) => {
        this.globals.presentTopToast(res.msg);
      });
    }, (err) => {
      console.error(err);
    });
  }

  async deactivate() {
    const alert = await this.alertController.create({
      header: 'Deactivate your account?',
      message: 'Deactivating your account will cancel all current service requests. ' +
        'If you ever wish to re-activate your account, contact support@zengot.com',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Deactivating...').then((resLoading) => {
              this.accountService.deactivate(this.user.id)
                .subscribe((res: any) => {
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                  this.logout();
                }, (err) => {
                  console.log(err);
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  public logout() {
    this.globals.presentLoading('Logging out...').then((res) => {
      this.loginService.logout().subscribe((r: any) => {
          console.log(r);
          this.pusherService.unsubscribe();
          this.globals.loading.dismiss();
          this.storage.remove('access_token').then((stRes) => {
              // Depending on the what you signed in with (facebook, google) logout from those services
              this.storage.get('signin_type').then((signInRes) => {
                console.log(signInRes);
                if (signInRes === 'facebook') {
                  this.fb.logout();
                } else if (signInRes === 'google') {
                  this.googlePlus.logout();
                }
              });
              this.storage.remove('user');
              this.navController.navigateRoot('customer/login');
            },
            (err) => {
              let errMsg = err.error.msg;
              this.globals.loading.dismiss();
              if (errMsg === undefined) {
                errMsg = 'Failed to logout';
              }
              this.globals.presentAlert(errMsg);
            });
        },
        (err) => {
          let errMsg = err.error.msg;
          this.globals.loading.dismiss();
          if (errMsg === undefined) {
            errMsg = 'Failed to logout';
          }
          this.globals.presentAlert(errMsg);
        }, () => {
          this.globals.loading.dismiss();
        });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }

  public back() {
    this.navController.navigateRoot('customer/dashboard/tabs/(about:about)');
  }
}
