import {Component, NgZone, OnInit, ViewChild} from '@angular/core';
import {IonInfiniteScroll, NavController, IonRefresher, Events} from '@ionic/angular';
import {FormBuilder} from '@angular/forms';
import {MapsAPILoader} from '@agm/core';
import {LoginService} from '../../../services/customer/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {AccountService} from '../../../services/customer/account/account.service';
import {OrderService} from '../../../services/general/order.service';

@Component({
  selector: 'app-gift',
  templateUrl: './gift.page.html',
  styleUrls: ['./gift.page.scss'],
})
export class GiftPage implements OnInit {
  @ViewChild('inscroll') infinite_scroll: IonInfiniteScroll;
  @ViewChild('inscrolltwo') infinite_scroll_two: IonInfiniteScroll;
  @ViewChild('refresher') refresher: IonRefresher;

  user: any;
  loading = true;
  hideClaimed = true;
  gift_code = '';
  public gift_cards = [];
  public page = 1;
  public last_page = 4;

  public unclaimed_gift_cards = [];
  public unclaimed_page = 1;
  public unclaimed_last_page = 4;

  constructor(private navController: NavController, private formBuilder: FormBuilder, private mapsAPILoader: MapsAPILoader,
              private ngZone: NgZone, public loginService: LoginService, public globals: Globals, private storage: Storage,
              public accountService: AccountService, public orderService: OrderService, public events: Events) {
  }

  ngOnInit() {
    this.storage.get('user').then((res) => {
      console.log(res);
      this.user = res;
      this.getGiftCards(null);
      this.getGiftCardsToClaim(null);
    });

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.refresh();
    });
  }

  public validate() {
    this.globals.presentLoading('Loading...').then((res) => {
      this.orderService.applyGiftCard(this.gift_code)
        .subscribe((r: any) => {
            this.apply();
          },
          (err) => {
            const errMsg = err.error.error;
            this.globals.loading.dismiss();
            this.globals.presentTopToast(errMsg);
          }, () => {
            this.globals.loading.dismiss();
          });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }

  public apply() {
    if(this.gift_code === '') {
      this.globals.presentTopToast('Enter a gift card code');
      return;
    }
    const data = {code: this.gift_code};
    this.accountService.applyGiftCard(this.user.id, data)
      .subscribe((res: any) => {
          this.user = res.user;
          this.storage.set('user', this.user);
          this.globals.presentToast(res.msg);
          this.refresh();
        },
        (err) => {
          const errMsg = err.error.error;
          this.globals.loading.dismiss();
          this.globals.presentToast(errMsg);
        }, () => {
          this.globals.loading.dismiss();
        });
  }

  public getGiftCards(event) {
    this.accountService.getGiftCards(this.user.id, this.page).subscribe((result: any) => {
      const items = result;
      this.last_page = items.last_page;
      if (items.data.length <= 0 || this.page > this.last_page) { // if the result we get is nothing or page has past last page
        if (event !== null) {
          event.disabled = true;
        }
      } else {
        if (this.page === 1 && items.data.length <= 0) { // No bookings available
          this.gift_cards = [];
        } else {
          items.data.forEach((item) => {
            this.gift_cards.push(item);
          });
          if (event !== null) {
            event.complete();
          }
          this.page = items.current_page + 1;
        }
      }
      this.refresher.complete();
      this.loading = false;
    }, (err) => {
      console.log(err);
      this.loading = false;
    });
  }

  public getGiftCardsToClaim(event) {
    this.accountService.getGiftCardsToClaim(this.user.email, this.page).subscribe((result: any) => {
      const items = result;
      this.unclaimed_last_page = items.last_page;
      if (items.data.length <= 0 || this.unclaimed_page > this.unclaimed_last_page) {
        if (event !== null) {
          event.disabled = true;
        }
      } else {
        if (this.unclaimed_page === 1 && items.data.length <= 0) { // No bookings available
          this.unclaimed_gift_cards = [];
        } else {
          items.data.forEach((item) => {
            this.unclaimed_gift_cards.push(item);
          });
          if (event !== null) {
            event.complete();
          }
          this.unclaimed_page = items.current_page + 1;
        }
      }
      this.refresher.complete();
      this.loading = false;
    }, (err) => {
      console.log(err);
      this.loading = false;
    });
  }

  public refresh() {
    this.unclaimed_page = 1;
    this.page = 1;
    this.unclaimed_gift_cards = [];
    this.gift_cards = [];
    this.getGiftCardsToClaim(this.refresher);
    this.getGiftCards(this.refresher);
  }

  public claim(code) {
    const data = {
      email: this.user.email,
      code: code
    };
    this.globals.presentLoading('Loading...').then((resLoading) => {
      this.accountService.claimGiftCard(data)
        .subscribe((res: any) => {
          this.user = res.user;
          this.storage.set('user', this.user);
          this.globals.presentTopToast(res.msg);
          this.globals.loading.dismiss();
          this.refresh();
        }, (err) => {
          const msg = err.error.msg;
          this.globals.presentAlert(msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.loading.dismiss();
    });
  }

  public show(page) {
    if (page === 'claimed') {
      this.hideClaimed = false;
    } else {
      this.hideClaimed = true;
    }
  }

  formatCurrency(num: any) {
    return this.globals.formatCurrency(num);
  }

  public formatDate(d: any) {
    return this.globals.formatDate(d);
  }

  public back() {
    this.navController.navigateRoot('customer/dashboard/tabs/(about:about)');
  }
}
