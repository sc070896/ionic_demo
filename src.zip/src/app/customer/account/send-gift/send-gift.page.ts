import {Component, OnInit} from '@angular/core';
import {NavController, AlertController} from '@ionic/angular';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {LoginService} from '../../../services/customer/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {AccountService} from '../../../services/customer/account/account.service';
import {OrderService} from '../../../services/general/order.service';
import * as dropin from 'braintree-web-drop-in';

@Component({
  selector: 'app-send-gift',
  templateUrl: './send-gift.page.html',
  styleUrls: ['./send-gift.page.scss'],
})
export class SendGiftPage implements OnInit {
  public options = [25, 50, 75, 100, 125, 150, 200];
  public customer: any;
  form: FormGroup;

  nonce = '';
  btoken = '';
  braintree_instance = null;
  device_data = null;
  valid_payment = false;

  constructor(private navController: NavController, private formBuilder: FormBuilder, public alertController: AlertController,
              public loginService: LoginService, public globals: Globals, private storage: Storage,
              public accountService: AccountService, public orderService: OrderService) {
    this.form = this.formBuilder.group({
      purchaser_name: ['', Validators.compose([
        Validators.required
      ])],
      recipient_name: ['', Validators.compose([
        Validators.required
      ])],
      recipient_email: ['', Validators.compose([
        Validators.required
      ])],
      confirm_recipient_email: ['', Validators.compose([
        Validators.required
      ])],
      amount: ['', Validators.compose([
        Validators.required
      ])],
      card_message: ['', Validators.compose([
        Validators.required,
        Validators.pattern('^[0-9]*$'),
      ])]
    });
  }

  ngOnInit() {
    this.storage.get('user').then((stRes) => {
      this.customer = stRes;
      this.getCustomerPaymentInfo();
    });
  }

  public getCustomerPaymentInfo() {
    this.accountService.getBraintreeNonce(this.customer.id).subscribe((r: any) => {
        console.log(r);
        this.btoken = r.customer_nonce;
        this.loadBraintree();
      },
      (err) => {
        console.log(err);
      });
  }

  public loadBraintree() {
    dropin.create({
      authorization: this.btoken,
      selector: '#dropin-container',
      paypal: {
        flow: 'vault'
      }
    }, (err, dropinInstance) => {
      if (err) {
        // Handle any errors that might've occurred when creating Drop-in
        console.log(err);
        // Message.showError(err);
        return;
      }
      this.braintree_instance = dropinInstance;
    });
  }

  public getBraintreeNonce() {
    return new Promise((resolve, reject) => {
      try {
        this.braintree_instance.requestPaymentMethod((err, payload) => {
          if (err) {
            console.log(err);
            this.globals.presentTopToast('Invalid payment method');
            this.valid_payment = false;
            reject(false);
          }
          // Send payload.nonce to your server
          this.nonce = payload.nonce;
          this.valid_payment = true;
          resolve(true);
        });
      } catch (err) {
        console.log(err);
        this.globals.presentTopToast('Failed to process payment');
        this.valid_payment = false;
        reject(false);
      }
    });
  }

  async pay() {
    const alert = await this.alertController.create({
      header: 'Send a $' + this.form.controls['amount'].value + ' gift card to ' + this.form.controls['recipient_name'].value + '?',
      message: this.form.controls['recipient_email'].value,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.getBraintreeNonce().then((bRes) => {
              if (!this.valid_payment) {
                this.globals.presentAlert('Invalid payment method');
                return;
              }
              const data = {
                'purchaser_name': this.form.controls['purchaser_name'].value,
                'purchaser_email': this.customer.email,
                'purchaser_email_confirmation': this.customer.email,
                'recipient_name': this.form.controls['recipient_name'].value,
                'recipient_email': this.form.controls['recipient_email'].value,
                'recipient_email_confirmation': this.form.controls['confirm_recipient_email'].value,
                'amount': this.form.controls['amount'].value,
                'card_message': this.form.controls['card_message'].value,
                'nonce': this.nonce,
                'device_data': this.device_data,
              };

              console.log(data);
              this.globals.presentLoading('Loading...').then((res) => {
                this.accountService.sendGiftCard(data).subscribe((r: any) => {
                    this.globals.presentTopToast(r.msg);
                    this.form.controls['purchaser_name'].setValue('');
                    this.form.controls['recipient_name'].setValue('');
                    this.form.controls['recipient_email'].setValue('');
                    this.form.controls['card_message'].setValue('');
                    this.form.controls['confirm_recipient_email'].setValue('');
                  },
                  (err) => {
                    const errMsg = err.error.error;
                    this.globals.loading.dismiss();
                    this.globals.presentAlert(errMsg);
                  }, () => {
                    this.globals.loading.dismiss();
                  });
              }, (err) => {
                console.log(err);
                this.globals.loading.dismiss();
              });
            }).catch((err) => {
              console.log(err);
              this.globals.presentAlert(err);
            });
          }
        }
      ]
    });
    await alert.present();
  }

  public back() {
    this.navController.navigateRoot('customer/dashboard/tabs/(about:about)');
  }
}
