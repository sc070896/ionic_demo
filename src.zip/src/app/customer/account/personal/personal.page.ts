import {Component, ElementRef, NgZone, OnInit, ViewChild} from '@angular/core';
import {NavController, IonRefresher, Events} from '@ionic/angular';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {LoginService} from '../../../services/customer/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {MapsAPILoader} from '@agm/core';
import {AccountService} from '../../../services/customer/account/account.service';

@Component({
  selector: 'app-personal',
  templateUrl: './personal.page.html',
  styleUrls: ['./personal.page.scss'],
})
export class PersonalPage implements OnInit {
  @ViewChild('search', {read: ElementRef}) searchElementRef: ElementRef;
  @ViewChild('refresher') refresher: IonRefresher;

  accountForm: FormGroup;
  public user: any;
  public latitude: number;
  public longitude: number;
  public zoom: number;
  public email_sent = false;
  public email: any;
  public current_password: any;
  public new_password: any;
  public confirm_new_password: any;
  constructor(private navController: NavController, private formBuilder: FormBuilder, private mapsAPILoader: MapsAPILoader,
              private ngZone: NgZone, public loginService: LoginService, public globals: Globals, private storage: Storage,
              public accountService: AccountService, public events: Events) {
    this.accountForm = this.formBuilder.group({
      first_name: ['', Validators.compose([
        Validators.required
      ])],
      last_name: ['', Validators.compose([
        Validators.required
      ])],
      address: ['', Validators.compose([
        Validators.required
      ])],
      apt_number: [''],
      country: ['', Validators.compose([
        Validators.required
      ])],
      state: ['', Validators.compose([
        Validators.required
      ])],
      city: ['', Validators.compose([
        Validators.required
      ])],
      zip: [''],
    });
    this.zoom = 4;
    this.latitude = 39.8282;
    this.longitude = -98.5799;
  }

  ngOnInit() {
    this.loadMap();
    this.storage.get('user').then((res) => {
      this.user = res;
      this.accountForm.controls['first_name'].setValue(this.user.first_name);
      this.accountForm.controls['last_name'].setValue(this.user.last_name);
      this.accountForm.controls['address'].setValue(this.user.address);
      this.accountForm.controls['country'].setValue(this.user.country);
      this.accountForm.controls['state'].setValue(this.user.state);
      this.accountForm.controls['city'].setValue(this.user.city);
      this.accountForm.controls['zip'].setValue(this.user.zip);
    });
  }

  public updatePersonal() {
    const data = {
      first_name: this.accountForm.controls['first_name'].value,
      last_name: this.accountForm.controls['last_name'].value,
      address: this.accountForm.controls['address'].value,
      apt_number: this.accountForm.controls['apt_number'].value,
      country: this.accountForm.controls['country'].value,
      state: this.accountForm.controls['state'].value,
      city: this.accountForm.controls['city'].value,
      zip: this.accountForm.controls['zip'].value,
      latitude: this.latitude,
      longitude: this.longitude,
    };

    this.globals.presentLoading('Updating...').then((result) => {
      this.accountService.updatePersonal(this.user.id, data)
        .subscribe((res: any) => {
          this.user = res.data;
          this.storage.set('user', res.data);
          this.globals.loading.dismiss();
          this.globals.presentToast(res.msg);
        }, (err) => {
          this.globals.presentToast(err.error.msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  public updateEmail() {
    const data = {
      email: this.email,
    };

    this.globals.presentLoading('Submitting...').then((result) => {
      this.accountService.updateEmail(this.user.id, data)
        .subscribe((res: any) => {
          this.user = res.data;
          this.email_sent = true;
          this.storage.set('user', res.data);
          this.globals.loading.dismiss();
          this.globals.presentToast(res.success);
        }, (err) => {
          this.globals.presentToast(err.error.error);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  public updatePassword() {
    const data = {
      current_password: this.current_password,
      new_password: this.new_password,
      confirm_new_password: this.confirm_new_password,
    };

    this.globals.presentLoading('Updating Password...').then((result) => {
      this.accountService.updatePassword(this.user.id, data)
        .subscribe((res: any) => {
          this.user = res.data;
          this.storage.set('user', res.data);
          this.globals.loading.dismiss();
          this.globals.presentToast(res.msg);
          this.current_password = '';
          this.new_password = '';
          this.confirm_new_password = '';
        }, (err) => {
          this.globals.presentToast(err.error.msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  private loadMap() {
    // load Places Autocomplete
    this.mapsAPILoader.load().then(() => {
      console.log(google); // returns undefined, expected object here
      const autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: ['address']
      });
      autocomplete.addListener('place_changed', () => {
        this.ngZone.run(() => {
          // get the place result
          const place = autocomplete.getPlace();

          // verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          place.address_components.forEach((item) => {
            if (item.types.includes('country')) {
              this.accountForm.controls['country'].setValue(item.short_name);
            }
            if (item.types.includes('administrative_area_level_1')) {
              this.accountForm.controls['state'].setValue(item.short_name);
            }
            if (item.types.includes('locality')) {
              this.accountForm.controls['city'].setValue(item.short_name);
            }
            if (item.types.includes('zip')) {
              this.accountForm.controls['zip'].setValue(item.short_name);
            }
          });
          // set latitude, longitude and zoom
          this.latitude = place.geometry.location.lat();
          this.longitude = place.geometry.location.lng();
          this.zoom = 12;
        });
      });
    });
  }

  public back() {
    this.navController.navigateRoot('customer/dashboard/tabs/(about:about)');
  }
}
