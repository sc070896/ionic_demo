import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BookingsPage } from './bookings.page';
import {BookingCardComponent} from '../../bookings/booking-card/booking-card.component';
import {Ng2FlatpickrModule} from 'ng2-flatpickr';

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    RouterModule.forChild([{ path: '', component: BookingsPage }]),
    Ng2FlatpickrModule
  ],
  declarations: [BookingsPage, BookingCardComponent]
})
export class BookingsPageModule {}
