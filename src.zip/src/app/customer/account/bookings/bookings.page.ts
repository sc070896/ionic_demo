import {Component, OnInit, ViewChild} from '@angular/core';
import {IonInfiniteScroll, LoadingController, ModalController, NavController, IonRefresher, ToastController} from '@ionic/angular';
import {Globals} from '../../../globals';
import {BookingsService} from '../../../services/customer/bookings/bookings.service';
import {PusherService} from '../../../services/customer/auth/pusher.service';
import {FlatpickrOptions} from 'ng2-flatpickr';
import {Storage} from '@ionic/storage';

@Component({
  selector: 'app-bookings',
  templateUrl: 'bookings.page.html',
  styleUrls: ['bookings.page.scss']
})
export class BookingsPage implements OnInit {
  @ViewChild('inscroll') bookings_scroll: IonInfiniteScroll;
  @ViewChild('refresher') refresher: IonRefresher;

  public user: any;
  public bookings = [];
  public sort_by = 'asc';
  public status = 'current';
  public keywords = '';
  public page = 1;
  public last_page = 4;
  public loaded = true;
  public hideFilter = true;
  public channelBinded = false;
  public selected_date: any = '';
  public calendar_options: FlatpickrOptions = {
    defaultDate: 'today',
    inline: false,
    onChange: (selectedDates, dateStr, instance) => {
      this.selected_date = dateStr;
      console.log(this.selected_date);
      this.refresh();
    },
    altInput: true,
    altFormat: 'F j, Y',
    dateFormat: 'Y-m-d',
    disableMobile: true,
    clickOpens: true
  };

  constructor(public bookingsService: BookingsService, public modalController: ModalController,
              private navController: NavController, public globals: Globals, public storage: Storage,
              public loadingCtrl: LoadingController, public pusherService: PusherService,
              public toastCtrl: ToastController) {
  }

  async ngOnInit() {
    this.storage.get('user').then((res) => {
      this.user = res;
    });
    this.getBookings(null);
    await this.handleNotifications();
  }

  public toggleFilter() {
    (this.hideFilter) ? this.hideFilter = false : this.hideFilter = true;
  }

  public getBookings(event) {
    this.bookingsService.getBookings(this.status, this.sort_by, this.keywords, this.selected_date, this.page)
      .subscribe((result: any) => {
        const items = result.bookings;
        console.log(result);
        this.last_page = items.last_page;
        if (items.data.length <= 0 || this.page > this.last_page) { // if the result we get is nothing or page has past last page
          if (event !== null) {
            event.disabled = true;
          }
        } else {
          if (this.page === 1 && items.data.length <= 0) { // No bookings available
            this.bookings = [];
          } else {
            items.data.forEach((item) => {
              this.bookings.push(item);
            });
            if (event !== null) {
              event.complete();
            }
            this.page = items.current_page + 1;
          }
        }
        this.loaded = false;
      }, (err) => {
        console.log(err);
        this.loaded = false;
      });
  }

  public getDirectWithoutDisabling(event) {
    this.bookingsService.getBookings(this.status, this.sort_by, this.keywords, this.selected_date, this.page).subscribe((result: any) => {
      const items = result.bookings;
      this.last_page = items.last_page;
      this.bookings = [];
      items.data.forEach((item) => {
        this.bookings.push(item);
      });
      if (event !== null) {
        event.complete();
      }
      this.page = items.current_page + 1;
      this.loaded = false;
    }, (err) => {
      console.log(err);
      this.loaded = false;
    });
  }

  public refresh() {
    this.page = 1;
    this.getDirectWithoutDisabling(this.refresher);
  }

  public eraseDate() {
    this.selected_date = '';
    this.refresh();
  }

  async handleNotifications() {
    let channel = this.pusherService.init();
    if (channel === undefined) {
      channel = this.pusherService.init();
    }
    setInterval(() => {
      if (channel === undefined) {
        channel = this.pusherService.init();
      } else {
        if (!this.channelBinded) {
          channel.bind('Illuminate\\Notifications\\Events\\BroadcastNotificationCreated', (event) => {
            if (
              event.type === 'App\\Notifications\\Customer\\ServiceOrdered' ||
              event.type === 'App\\Notifications\\Customer\\OrderedImmediateService' ||
              event.type === 'App\\Notifications\\Customer\\RebookedSupplier' ||
              event.type === 'App\\Notifications\\Customer\\RemindFrequentBooking'
            ) {
              // reset current page
              this.refresh();
            }
            console.log(event);
          });
          this.channelBinded = true;
        }
      }
    }, 5000);
  }
}
