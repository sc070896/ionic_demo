import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TabsPageRoutingModule } from './tabs.router.module';

import { TabsPage } from './tabs.page';
import { BookingsPageModule } from '../bookings/bookings.module';
import { AboutPageModule } from '../about/about.module';
import { HomePageModule } from '../home/home.module';
import {PersonalPageModule} from '../personal/personal.module';
import {BillingPageModule} from '../billing/billing.module';
import {TransactionsPageModule} from '../transactions/transactions.module';
import {GiftPageModule} from '../gift/gift.module';
import {SettingsPageModule} from '../settings/settings.module';
import {AvatarPageModule} from '../avatar/avatar.module';
import {NotificationsPageModule} from '../notifications/notifications.module';
import {SendGiftPageModule} from '../send-gift/send-gift.module';
import {SupportPageModule} from '../support/support.module';
import {ReportPageModule} from '../report/report.module';

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    SupportPageModule,
    TabsPageRoutingModule,
    HomePageModule,
    AboutPageModule,
    BookingsPageModule,
    PersonalPageModule,
    BillingPageModule,
    TransactionsPageModule,
    GiftPageModule,
    SettingsPageModule,
    AvatarPageModule,
    NotificationsPageModule,
    SendGiftPageModule,
    ReportPageModule
  ],
  declarations: [TabsPage]
})
export class TabsPageModule {}
