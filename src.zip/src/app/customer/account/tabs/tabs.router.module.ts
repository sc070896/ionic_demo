import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { TabsPage } from './tabs.page';
import { HomePage } from '../home/home.page';
import { AboutPage } from '../about/about.page';
import { BookingsPage } from '../bookings/bookings.page';
import {PersonalPage} from '../personal/personal.page';
import {BillingPage} from '../billing/billing.page';
import {TransactionsPage} from '../transactions/transactions.page';
import {GiftPage} from '../gift/gift.page';
import {SettingsPage} from '../settings/settings.page';
import {AvatarPage} from '../avatar/avatar.page';
import {NotificationsPage} from '../notifications/notifications.page';
import {SendGiftPage} from '../send-gift/send-gift.page';
import {SupportPage} from '../support/support.page';
import {ReportPage} from '../report/report.page';

const routes: Routes = [
  {
    path: 'tabs',
    component: TabsPage,
    children: [
      {
        path: 'home',
        outlet: 'home',
        component: HomePage
      },
      {
        path: 'about',
        outlet: 'about',
        component: AboutPage
      },
      {
        path: 'bookings',
        outlet: 'bookings',
        component: BookingsPage
      },
      {
        path: 'personal',
        outlet: 'personal',
        component: PersonalPage
      },
      {
        path: 'billing',
        outlet: 'billing',
        component: BillingPage
      },
      {
        path: 'transactions',
        outlet: 'transactions',
        component: TransactionsPage
      },
      {
        path: 'gift',
        outlet: 'gift',
        component: GiftPage
      },
      {
        path: 'settings',
        outlet: 'settings',
        component: SettingsPage
      },
      {
        path: 'avatar',
        outlet: 'avatar',
        component: AvatarPage
      },
      {
        path: 'notifications',
        outlet: 'notifications',
        component: NotificationsPage
      },
      {
        path: 'send-gift',
        outlet: 'send-gift',
        component: SendGiftPage
      },
      {
        path: 'support',
        outlet: 'support',
        component: SupportPage
      },
      {
        path: 'report',
        outlet: 'report',
        component: ReportPage
      }
    ]
  },
  {
    path: '/customer/dashboard',
    redirectTo: '/tabs/(home:home)',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TabsPageRoutingModule {}
