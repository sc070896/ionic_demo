import {Component, ElementRef, NgZone, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {FlatpickrOptions} from 'ng2-flatpickr';
import {ActivatedRoute, Router} from '@angular/router';
import {Globals} from '../../../globals';
import {AlertController, NavController, Events, IonRefresher} from '@ionic/angular';
import {RegistrationService} from '../../../services/general/registration.service';
import {MapsAPILoader} from '@agm/core';
import {CategoriesService} from '../../../services/general/categories.service';
import {OrderService} from '../../../services/general/order.service';
import {Storage} from '@ionic/storage';
import {BookingService} from '../../../services/general/booking.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.page.html',
  styleUrls: ['./edit.page.scss'],
})
export class EditPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  checkoutForm: FormGroup;
  public subcategory_id: any;
  public service: any;
  public service_options: any = [];
  public selected_service_options: any = [];
  public latitude: number;
  public longitude: number;
  public zoom: number;
  public hours: number;
  public hours_options: any;
  public minutes = 1;
  public minutes_options: any;
  public times: any;
  public requested_time: any;
  public frequency: any;
  public frequency_options: any;
  public selected_date: any;
  public previous_date: any;
  public user: any;
  public uuid: any;
  public booking: any;
  loading = true;
  first_time = true;
  warningOpened = false;
  is_immediate = 1;
  public calendar_options: FlatpickrOptions = {
    defaultDate: 'today',
    inline: false,
    onChange: (selectedDates, dateStr, instance) => {
      this.selected_date = dateStr;
      this.validateTimes(this.selected_date, this.requested_time);
    },
    onReady: (selectedDates, dateStr, instance) => {
      this.selected_date = dateStr;
    },
    altInput: true,
    altFormat: 'F j, Y',
    dateFormat: 'Y-m-d',
    minDate: 'today',
    disableMobile: true,
    clickOpens: true
  };

  @ViewChild('search', {read: ElementRef}) searchElementRef: ElementRef;

  constructor(private route: ActivatedRoute, private router: Router, public globals: Globals, private navController: NavController,
              public registrationService: RegistrationService, private alertController: AlertController, private formBuilder: FormBuilder,
              private mapsAPILoader: MapsAPILoader, private ngZone: NgZone, public categoriesService: CategoriesService,
              public orderService: OrderService, private storage: Storage, public bookingService: BookingService, public events: Events) {
    this.checkoutForm = this.formBuilder.group({
      customer_location: ['', Validators.compose([
        Validators.required
      ])
      ],
      country: ['', Validators.compose([
        Validators.required
      ])
      ],
      state: ['', Validators.compose([
        Validators.required
      ])
      ],
      service_details: ['', Validators.compose([
        Validators.required
      ])
      ],
      city: ['', Validators.compose([
        Validators.required
      ])
      ],
      customer_phone_num: ['', Validators.compose([
        Validators.required
      ])
      ],
      postal_code: ['', Validators.compose([
        Validators.required
      ])
      ]
    });
  }

  ngOnInit() {
    this.zoom = 4;
    this.latitude = 39.8282;
    this.longitude = -98.5795;
    this.times = this.orderService.getTimes();
    this.minutes_options = this.orderService.getMinutes();

    this.storage.get('user').then((res) => {
      this.user = res;
    });
    this.route.params.subscribe((params) => {
      this.subcategory_id = params['id'];
      this.uuid = params['uuid'];
      this.init();
    });

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.init();
    });
  }

  public init() {
    this.getBooking();
    this.loadMap();
  }

  public loadMap() {
    this.mapsAPILoader.load().then(() => {
      console.log(google); // returns undefined, expected object here
      const autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: ['address']
      });
      autocomplete.addListener('place_changed', () => {
        console.log('place changed');
        this.ngZone.run(() => {
          // get the place result
          const place = autocomplete.getPlace();

          // verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          this.checkoutForm.controls['customer_location'].setValue(place.formatted_address);
          place.address_components.forEach((item) => {
            if (item.types.includes('country')) {
              this.checkoutForm.controls['country'].setValue(item.short_name);
            }
            if (item.types.includes('administrative_area_level_1')) {
              this.checkoutForm.controls['state'].setValue(item.short_name);
            }
            if (item.types.includes('locality')) {
              this.checkoutForm.controls['city'].setValue(item.short_name);
            }
            if (item.types.includes('postal_code')) {
              this.checkoutForm.controls['postal_code'].setValue(item.short_name);
            }
          });
          // set latitude, longitude and zoom
          this.latitude = place.geometry.location.lat();
          this.longitude = place.geometry.location.lng();
          this.zoom = 12;
        });
      });
    });
  }

  public getBooking() {
    this.bookingService.getBookingByUuid(this.uuid).subscribe((result: any) => {
      console.log(result);
      this.booking = result;
      this.checkoutForm.controls['customer_location'].setValue(this.booking.customer_location);
      this.checkoutForm.controls['country'].setValue(this.booking.country_code);
      this.checkoutForm.controls['state'].setValue(this.booking.state);
      this.checkoutForm.controls['city'].setValue(this.booking.city);
      this.checkoutForm.controls['customer_phone_num'].setValue(this.booking.customer_phone_num);
      this.latitude = this.booking.customer_latitude;
      this.longitude = this.booking.customer_longitude;
      this.checkoutForm.controls['service_details'].setValue(this.booking.service_details);
      if (this.booking.flexible === 1) { // ASAP and Flexible
        this.requested_time = 'flexible';
      } else if (this.booking.is_asap === 1) {
        this.requested_time = 'asap';
      } else {
        this.requested_time = this.booking.requested_time;
      }

      this.frequency = this.booking.frequency.id;
      this.selected_service_options = this.booking.service_options;
      console.log(this.selected_service_options);
      console.log(this.booking.frequency.id);
      console.log(this.booking.hours);
      this.hours = this.booking.hours;
      if (this.booking.minutes === 0) { // for the work around
        this.minutes = 1;
      } else {
        this.minutes = this.booking.minutes;
      }
      this.previous_date = this.booking.service_date;
      this.subcategory_id = this.booking.subcategory.id;
      this.categoriesService.getSingleSubcategory(this.subcategory_id).subscribe((r: any) => {
        console.log(r);
        this.service = r.data;
        this.service_options = this.service.service_options;
        this.frequency_options = this.orderService.getFrequencies(this.service.uses_reduced_discount,
          r.data.minimum_hours, this.service.id);
        this.hours_options = this.orderService.getHours(0, r.data.minimum_hours);
        this.loading = false;
        this.refresher.complete();
      }, (err) => {
        console.error(err);
        this.loading = false;
        this.refresher.complete();
      });
    }, (err) => {
      console.log(err);
    });
  }

  public validateTimes(service_date, requested_time) {
    if (this.first_time) {
      this.first_time = false;
      return;
    }
    const now = new Date();
    const nowDay = new Date();
    const hour = now.getHours();
    const selectedDate = new Date(service_date);
    const selectedDateTime = new Date(service_date + ' ' + requested_time);

    // Add a day
    selectedDate.setDate(selectedDate.getDate() + 1);
    nowDay.setDate(nowDay.getDate() + 1);

    if (selectedDateTime < now) { // date and time past
      // Message.showError('The requested time you have selected has already past');
      this.globals.presentAlert('The requested time you have selected has already past');
      return false;
    } else if (selectedDateTime < nowDay) { // within 24 hours
      if (!this.warningOpened) {
        this.openWarning();
      }
    }

    // if (this.requested_time === 'flexible') {
    //   //this.frequencies_id = 1;
    //
    //   // Set date to today
    //   this.calendar_date = new Date();
    //   this.service_date = 'TBD';
    // }
    if (this.requested_time !== 'asap') {
      if (now.setHours(0, 0, 0, 0) === selectedDate.setHours(0, 0, 0, 0)) {
        const nowHours = hour + ':00';
        if (this.globals.strtotime(this.requested_time) <= this.globals.strtotime(nowHours)) {
          this.globals.presentAlert('The requested time you have selected has already past');
          return false;
        }
      }
    } else {
      // this.openAsapModal();
    }

    return true;
  }

  selectedServiceOption(id, val) {
    const result = this.service_options.findIndex(x => x.id === id);
    if (result !== undefined && result > -1) {
      this.service_options[result]['chosen'] = val;
      console.log(this.service_options);
    }
  }

  public openWarning() {
    this.warningOpened = true;
    this.globals.presentAlert(`Same day and next day services: let's give it a try! Just a heads up that in some cases
                        it may be difficult to have your order filled on such short notice. We encourage you to
                        book services more than 24-hours in advance where possible!`);
  }

  public direct() {
    this.is_immediate = 0;
    this.update();
  }

  public instant() {
    this.is_immediate = 1;
    this.update();
  }

  public update() {
    console.log(this.requested_time);

    Object.keys(this.checkoutForm.controls).forEach(field => { // {1}
      const control = this.checkoutForm.get(field);            // {2}
      control.markAsTouched({onlySelf: true});       // {3}
    });

    if (this.requested_time === undefined) {
      this.globals.presentToast('Select the time of your service');
      return;
    }

    if (this.frequency === undefined) {
      this.globals.presentToast('Select the frequency of your service');
      return;
    }

    if (this.hours === undefined) {
      this.globals.presentToast('Select s number of hours');
      return;
    }

    if (this.minutes === undefined) {
      this.globals.presentToast('Select the number of minutes');
      return;
    }
    if (!this.validateTimes(this.selected_date, this.requested_time)) {
      return;
    }

    if (this.minutes === 1) { // work around a bug around having 0 as a value with ngModel
      this.minutes = 0;
    }

    const customer_location = this.checkoutForm.controls['customer_location'].value;
    const country_code = this.checkoutForm.controls['country'].value;
    const state = this.checkoutForm.controls['state'].value;
    const city = this.checkoutForm.controls['city'].value;
    const service_details = this.checkoutForm.controls['service_details'].value;
    const customer_phone_num = this.checkoutForm.controls['customer_phone_num'].value;
    const data = {
      uuid_booking: this.uuid,
      customer_id: this.user.id,
      sub_category_id: this.service.id,
      customer_location: customer_location,
      country_code: country_code,
      state: state,
      city: city,
      customer_latitude: this.latitude,
      customer_longitude: this.longitude,
      booked_hours: this.hours,
      booked_minutes: this.minutes,
      service_date: this.selected_date,
      service_details: service_details,
      requested_time: this.requested_time,
      customer_email: this.user.email,
      supplier_id: 0,
      frequencies_id: this.frequency,
      is_immediate: this.is_immediate,
      customer_phone_num: customer_phone_num,
      subcategory: this.service,
      service_options: this.service_options,
      submitted_estimation: '', // TODO
      estimated_hours: 0, // TODO
    };

    console.log(data);

    this.globals.presentLoading('Updating...').then((res) => {

      this.orderService.edit(data).subscribe((r: any) => {
          if (this.is_immediate) {
            this.navController.navigateRoot('customer/order/finalize/' + r.uuid_booking);
          } else {
            this.navController.navigateRoot('customer/order/choose/' + r.uuid_booking);
          }
          this.globals.loading.dismiss();
        },
        (err) => {
          const errMsg = err.error.msg;
          this.globals.loading.dismiss();
          this.globals.presentAlert(errMsg);
        }, () => {
          this.globals.loading.dismiss();
        });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }
}
