import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FinalizePage } from './finalize.page';

describe('FinalizePage', () => {
  let component: FinalizePage;
  let fixture: ComponentFixture<FinalizePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FinalizePage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FinalizePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
