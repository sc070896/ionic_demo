import {Component, OnInit, ViewChild} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Storage} from '@ionic/storage';
import {NavController, Events, IonRefresher} from '@ionic/angular';
import {BookingService} from '../../../services/general/booking.service';
import {OrderService} from '../../../services/general/order.service';
import {Globals} from '../../../globals';
import {LoginService} from '../../../services/customer/auth/login.service';
import {AccountService} from '../../../services/customer/account/account.service';
import * as dropin from 'braintree-web-drop-in';

@Component({
  selector: 'app-finalize',
  templateUrl: './finalize.page.html',
  styleUrls: ['./finalize.page.scss'],
})
export class FinalizePage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public customer: any;
  public uuid: any;
  public booking: any;
  public tax: any;
  public hide_additional = true;
  public loading = true;
  public bucket_url: string;
  public promo_code = '';
  public gift_code = '';
  public parking_options = '';
  public additional_details = '';
  public trust_fee: any;
  public tax_price: any;
  public tax_percent: any;
  public frequency_discount_percentage: any = 0;
  public frequency_discount: any;
  public service_total: any;
  public order_total: any;
  public steps = 1;
  public is_auto_instant = 0;
  public dont_ask_auto_instant = 0;
  public promo_codes_id = 0;
  public promo_percent = 0;
  public promo_discount = 0;
  public promo_hours = 0;
  public promo = null;
  public use_credit = 0;
  public gift_card_amount = 0;
  public gift_card_remaining: any = 0;
  public credit_remaining: any = 0;
  public credit_to_use: any = 0;
  public use_account_credit: any = false;
  gift_cards = [];

  nonce = '';
  btoken = '';
  braintree_instance = null;
  device_data = null;
  valid_payment = false;

  constructor(private route: ActivatedRoute, private router: Router, private storage: Storage, private navController: NavController,
              public bookingService: BookingService, public orderService: OrderService, public globals: Globals,
              public loginService: LoginService, public accountService: AccountService, public events: Events) {
    this.bucket_url = this.globals.bucket_url;
  }

  // http://localhost:8100/customer/order/finalize/2fb13cad-d650-4d51-97da-8e5d9d06430e
  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.uuid = params['uuid'];
      this.init();
    });

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.init();
    });
  }

  public init() {
    // get booking details
    this.bookingService.getBookingByUuid(this.uuid).subscribe((result: any) => {
      this.booking = result;
      this.getCustomer();
      this.getTax();
    }, (err) => {
      console.log(err);
    });
  }

  public pay() {
    this.getBraintreeNonce().then((res) => {
      console.log(res);
      const data = {
        customer_id: this.booking.customer.id,
        uuid_booking: this.booking.uuid_booking,
        customer_location: this.booking.customer_location,
        country_code: this.booking.country_code,
        state: this.booking.state,
        city: this.booking.city,
        customer_latitude: this.booking.customer_latitude,
        customer_longitude: this.booking.customer_longitude,
        service_details: this.booking.service_details,
        booked_hours: this.booking.hours,
        booked_minutes: this.booking.minutes,
        service_date: this.booking.service_date,
        requested_time: this.booking.requested_time,
        frequencies_id: this.booking.frequencies_id,
        first_name: this.customer.first_name,
        last_name: this.customer.last_name,
        customer_phone_num: this.booking.customer_phone_num,
        use_credit: this.use_credit,
        address_unit: this.booking.address_unit,
        gift_cards: this.gift_cards,
        promo_codes_id: this.promo_codes_id,
        nonce: this.nonce,
        device_data: this.device_data,
        additional_details: this.additional_details,
        parking_options: this.parking_options,
        is_auto_instant: this.is_auto_instant,
        references: [],
        dont_ask_auto_instant: this.dont_ask_auto_instant,
      };
      this.globals.presentLoading('Loading...').then((res) => {
        this.orderService.finalize(data).subscribe((r: any) => {
            console.log(r);
            this.navController.navigateRoot('customer/order/complete/' + r.uuid_booking);
          },
          (err) => {
            const errMsg = err.error.error;
            this.globals.loading.dismiss();
            this.globals.presentAlert(errMsg);
          }, () => {
            this.globals.loading.dismiss();
          });
      }, (err) => {
        console.log(err);
        this.globals.loading.dismiss();
      });
    }).catch((err) => {
      console.log(err);
      this.globals.presentAlert(err);
    });
  }

  public goEdit() {
    this.navController.navigateForward('customer/order/edit/' + this.uuid);
  }

  public goToProfile(username) {
    this.navController.navigateForward('zengiver/profile/' + username);
  }

  public getCustomer() {
    this.loginService.user().subscribe((r: any) => {
        console.log(r);
        this.customer = r;
        this.credit_remaining = this.customer.credit;
        this.getCustomerPaymentInfo();
        this.storage.set('user', r).then((loginRes) => {
        });
        this.loading = false;
        this.refresher.complete();
      },
      (err) => {
        this.loading = false;
        this.refresher.complete();
      });
  }

  public getCustomerPaymentInfo() {
    this.accountService.getBraintreeNonce(this.customer.id).subscribe((r: any) => {
        console.log(r);
        this.btoken = r.customer_nonce;
        this.loadBraintree();
      },
      (err) => {
        console.log(err);
      });
  }

  public loadBraintree() {
    dropin.create({
      authorization: this.btoken,
      selector: '#dropin-container',
      paypal: {
        flow: 'vault'
      }
    }, (err, dropinInstance) => {
      if (err) {
        // Handle any errors that might've occurred when creating Drop-in
        // Message.showError(err);
        return;
      }
      this.braintree_instance = dropinInstance;
    });
  }

  public getBraintreeNonce() {
    return new Promise((resolve, reject) => {
      try {
        this.braintree_instance.requestPaymentMethod((err, payload) => {
          if (err) {
            this.globals.presentTopToast('Invalid payment method');
            this.valid_payment = false;
            reject(false);
          }
          // Send payload.nonce to your server
          this.nonce = payload.nonce;
          this.valid_payment = true;
          resolve(true);
        });
      } catch (err) {
        console.log('Process Payment',err);
        this.globals.presentTopToast('Failed to process payment');
        this.valid_payment = false;
        reject(false);
      }
    });
  }

  public getTax() {
    this.orderService.getTax(this.uuid).subscribe((r: any) => {
        console.log(r);
        this.tax = r;
        this.frequencyDiscount();
        this.calculateTrustFee();
        this.calculateServiceTotal();
        this.tax_percent = (parseFloat(this.tax.tax) * 100).toFixed(0);
      },
      (err) => {
      });
  }

  formatDate(d) {
    return this.globals.formatDate(d);
  }

  formatTime(d) {
    return this.globals.formatTime(d);
  }

  formatPercent(num: any) {
    return (parseFloat(num) * 100).toFixed(0);
  }

  formatCurrency(num: any) {
    return this.globals.formatCurrency(num);
  }

  public initials(name: string) {
    return this.globals.initials(name);
  }

  public forward() {
    this.steps++;
  }

  public back() {
    this.steps--;
  }

  public navigateBack() {
    this.navController.back();
  }

  public applyPromo() {
    if (this.promo_code.length <= 0) {
      this.globals.presentTopToast('Enter a valid promo code');
      return;
    }
    this.globals.presentLoading('Loading...').then((loadingRes) => {
      this.orderService.applyPromo(this.booking.frequencies_id, this.booking.sub_category_id, this.promo_code,
        this.booking.customer.email, this.booking.subcategory.uses_reduced_discount)
        .subscribe((res: any) => {
            // Apply only if there is no complimentary gift code
            // find gift code that is complimentary
            const found = this.gift_cards.find(function (element) {
              return element.is_complimentary === 1;
            });

            if (found !== undefined) {
              // if any found give out error - can't be used with promo
              this.globals.presentTopToast('Sorry, promo codes cannot be used with your complimentary gift card.');
            } else {
              // Apply code if NO complimentary gift code found
              this.promo_codes_id = res.promo.id;
              this.promo = res.promo;
              this.promo_discount = res.promo.discount;
              this.promo_percent = res.promo.is_percent;
              this.promo_hours = res.promo.hours;

              // Check if customer already used promo code
              if (res.promo.is_percent === 1) {
                const discount = parseFloat(res.promo.discount).toFixed(0);
                this.globals.presentTopToast('Applied promo code: ' + res.promo.code + ' - for ' + discount + '% off your service');
              } else {
                const discount = parseFloat(res.promo.discount).toFixed(2);
                this.globals.presentTopToast('Applied promo code: ' + res.promo.code + ' - for ' + discount + '% off your service');
              }
              this.calculateServiceTotal();
            }

            this.globals.loading.dismiss();
          },
          (err) => {
            const errMsg = err.error.error;
            this.globals.loading.dismiss();
            this.globals.presentAlert(errMsg);
          }, () => {
            this.globals.loading.dismiss();
          });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }

  public applyGiftCard() {
    if (this.gift_code.length <= 0) {
      this.globals.presentTopToast('Enter a valid gift card code');
      return;
    }
    this.globals.presentLoading('Loading...').then((res) => {
      this.orderService.applyGiftCard(this.gift_code)
        .subscribe((r: any) => {
            console.log(r);
            const id = r.gift_card.id;
            const index = this.gift_cards.map(function (e) {
              return e.id;
            }).indexOf(id);

            // Can't apply same gift card
            if (index < 0) {
              // Can't apply complimentary gift card to promo/frequent booking
              if (r.gift_card.is_complimentary === 1 && (this.booking.frequencies_id !== 1 || this.promo_codes_id > 0)) {
                this.globals.presentTopToast('Sorry, your complimentary gift card cannot be applied to your order. ' +
                  'Can only be used on "Just Once" requests with no Promo Code applied.');
              } else {
                const result = this.gift_cards.find(card => card.is_complimentary === 1);
                // Can't stack complimentary gift cards
                if (r.gift_card.is_complimentary === 1 && result !== undefined) {
                  this.globals.presentTopToast('Sorry, your complimentary gift card cannot be ' +
                    'used with another complimentary gift card.');
                } else {
                  this.gift_code = '';
                  this.gift_cards.push(r.gift_card);
                  this.use_credit = 1;
                  this.globals.presentTopToast('Applied gift card');
                  this.calculateGiftCardAmount();
                }
              }
            } else {
              this.globals.presentTopToast('Gift card already applied');
            }

            this.globals.loading.dismiss();
          },
          (err) => {
            const errMsg = err.error.error;
            this.globals.loading.dismiss();
            // this.globals.presentAlert(errMsg);
            this.globals.presentTopToast(errMsg);

          }, () => {
            this.globals.loading.dismiss();
          });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }

  public calculateGiftCardAmount() {
    this.gift_card_amount = 0; // reset amount
    this.gift_cards.map((e) => {
      console.log(e.amount);
      this.gift_card_amount += parseFloat(e.amount);
    });
    this.calculateServiceTotal();
  }

  // Calculate the frequency discount percentage
  public frequencyDiscount() {
    let discount: any = 0;

    if (this.booking.subcategory.uses_reduced_discount === 1) {
      discount = parseFloat(this.booking.frequency.new_discount_percentage);
    } else {
      discount = parseFloat(this.booking.frequency.discount_percentage);
    }

    this.frequency_discount_percentage = discount.toFixed(2);
  }

  public calculateTrustFee() {
    this.trust_fee = this.booking.order_total;
    this.trust_fee = this.trust_fee * 0.05;
    this.trust_fee = this.trust_fee.toFixed(2);
  }

  public calculateServiceTotal() {
    let price: any = parseFloat(this.booking.order_total);
    let pc: any = 0;
    // Trust fee applied
    price = (price + parseFloat(this.trust_fee));

    // Frequency discount
    if (this.frequency_discount_percentage !== 0) {
      this.frequency_discount = (price * this.frequency_discount_percentage).toFixed(2);
    } else {
      this.frequency_discount = 0;
    }

    // Calculate promo
    if (this.promo !== null) {
      if (this.promo_percent === 1) {
        if (this.promo_hours > 0) {
          // Need amount of hours to handle time-limited promo codes
          const hours = parseFloat(this.booking.hours) + (this.booking.minutes / 60);
          const promoHours = this.promo_hours;

          if (promoHours < hours) {
            // Get discount only for amount of hours within promo code's limit
            const hourlyRate = parseFloat(this.booking.price);
            const basePrice = (hourlyRate * promoHours);
            pc = (basePrice + (basePrice * this.frequency_discount) + (basePrice * 0.05)) * (this.promo_discount / 100);
          } else {
            // If promo code hours can cover all of booking hours then apply discount normally
            pc = price * (this.promo_discount / 100);
          }
        } else {
          pc = price * (this.promo_discount / 100);
        }
      } else {
        pc = this.promo_discount;
      }
    }

    // Frequency discount applied
    this.service_total = parseFloat(price) - parseFloat(this.frequency_discount) - parseFloat(pc);

    this.calculateTax();
    this.calculateOrderTotal();
  }

  public calculateTax() {
    this.tax_price = (this.service_total * parseFloat(this.tax.tax)).toFixed(2);
  }

  public calculateOrderTotal() {
    let price: any = parseFloat(this.service_total);

    // Service total + tax
    price = (price + parseFloat(this.tax_price)).toFixed(2);

    // Calculate gift card
    if (price <= 0) { // if the service total at this point is zero don't need to calculate in gift card amount
      price = 0;
      this.gift_card_remaining = this.gift_card_amount;
    } else {
      if (this.gift_card_amount > 0) {
        price = price - this.gift_card_amount;
        if (price <= 0) { // if gift card amount made service total to zero
          this.gift_card_amount = (this.gift_card_amount + (price)).toFixed(2);
          this.gift_card_remaining = -1 * price;
          this.gift_card_remaining = this.gift_card_remaining.toFixed(2);
          price = 0;
        }
      }
    }

    // Calculate credit
    if (this.use_account_credit) {
      if (price <= 0) { // if the service total at this point is zero don't need to calculate in gift card amount
        price = 0;
        this.credit_remaining = this.customer.credit;
      } else {
        this.use_credit = 1;
        if (this.credit_remaining > 0) {
          const ogPrice = price;
          price = price - this.credit_remaining;
          if (price <= 0) { // if credit amount used made service total to zero
            this.credit_to_use = ogPrice; // uses full cost of the service
            this.credit_remaining = -1 * price;
            this.credit_remaining = this.credit_remaining.toFixed(2);
            price = 0;
          } else { // credit only covers the service cost partially
            this.credit_to_use = this.credit_remaining; // use what's remaining
            this.credit_remaining = 0;
          }
        }
      }
    } else {
      if (this.credit_to_use > 0) {
        this.credit_remaining = parseFloat(this.credit_remaining) + parseFloat(this.credit_to_use);
        this.credit_to_use = 0;
      }
    }

    this.order_total = price;
  }

  toggleAdditional() {
    this.hide_additional = !this.hide_additional;
  }
}
