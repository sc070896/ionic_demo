import {Component, ElementRef, NgZone, OnInit, ViewChild} from '@angular/core';
import {Router, ActivatedRoute, ParamMap} from '@angular/router';
import {Globals} from '../../../globals';
import {AlertController, NavController, Events, IonRefresher} from '@ionic/angular';
import {RegistrationService} from '../../../services/general/registration.service';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {MapsAPILoader} from '@agm/core';
import {FlatpickrOptions} from 'ng2-flatpickr';
import {CategoriesService} from '../../../services/general/categories.service';
import {OrderService} from '../../../services/general/order.service';
import {Storage} from '@ionic/storage';
import {BookingService} from '../../../services/general/booking.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.page.html',
  styleUrls: ['./checkout.page.scss'],
})
export class CheckoutPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  checkoutForm: FormGroup;
  public subcategory_id: any;
  public service: any;
  public service_options: any = [];
  public latitude: number;
  public longitude: number;
  public zoom: number;
  public hours: number;
  public hours_options: any;
  public minutes: any;
  public minutes_options: any;
  public times: any;
  public requested_time: any;
  public frequency: any;
  public frequency_options: any;
  public selected_date: any;
  public user: any;
  public service_name = '';
  loading = true;
  warningOpened = false;
  is_immediate = 1;
  steps = 1;
  public calendar_options: FlatpickrOptions = {
    defaultDate: 'today',
    inline: false,
    onChange: (selectedDates, dateStr, instance) => {
      this.selected_date = dateStr;
      this.validateTimes(this.selected_date, this.requested_time);
    },
    onReady: (selectedDates, dateStr, instance) => {
      this.selected_date = dateStr;
    },
    altInput: true,
    altFormat: 'F j, Y',
    dateFormat: 'Y-m-d',
    minDate: 'today',
    disableMobile: true,
    clickOpens: true
  };

  @ViewChild('search', {read: ElementRef}) searchElementRef: ElementRef;

  constructor(private route: ActivatedRoute, private router: Router, public globals: Globals, private navController: NavController,
              public registrationService: RegistrationService, private alertController: AlertController, private formBuilder: FormBuilder,
              private mapsAPILoader: MapsAPILoader, private ngZone: NgZone, public categoriesService: CategoriesService,
              public orderService: OrderService, private storage: Storage, public events: Events) {
    this.checkoutForm = this.formBuilder.group({
      customer_location: ['', Validators.compose([
        Validators.required
      ])
      ],
      country: ['', Validators.compose([
        Validators.required
      ])
      ],
      state: ['', Validators.compose([
        Validators.required
      ])
      ],
      service_details: ['', Validators.compose([
        Validators.required
      ])
      ],
      city: ['', Validators.compose([
        Validators.required
      ])
      ],
      customer_phone_num: ['', Validators.compose([
        Validators.required,
        Validators.minLength(10)
      ])
      ],
      postal_code: ['', Validators.compose([
        Validators.required
      ])
      ]
    });
  }

  ngOnInit() {
    this.init();

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.init();
    });
  }

  public init() {
    this.zoom = 4;
    this.latitude = 39.8282;
    this.longitude = -98.5795;
    this.times = this.orderService.getTimes();
    this.minutes_options = this.orderService.getMinutes();

    this.storage.get('user').then((res) => {
      this.user = res;
      this.setPreviousInput();
    });
    this.route.params.subscribe((params) => {
      this.subcategory_id = params['id'];
      this.categoriesService.getSingleSubcategory(this.subcategory_id).subscribe((r: any) => {
        console.log(r);
        this.service = r.data;
        this.service_options = this.service.service_options;
        this.service_name = this.service.name;
        this.frequency_options = this.orderService.getFrequencies(this.service.uses_reduced_discount,
          r.data.minimum_hours, this.service.id);
        this.hours_options = this.orderService.getHours(0, r.data.minimum_hours);
        this.loadMap();
        this.loading = false;
      }, (err) => {
        console.error(err);
        this.loading = false;
      });
    });
  }

  // Set location and mobile number to latest one used
  public setPreviousInput() {
    // Set location if any
    if (this.user.booking_addresses.length > 0) {
      const prevAddress = this.user.booking_addresses[this.user.booking_addresses.length - 1]; // latest/last one
      this.checkoutForm.controls['customer_location'].setValue(prevAddress.address);
      this.checkoutForm.controls['country'].setValue(prevAddress.country_code);
      this.checkoutForm.controls['state'].setValue(prevAddress.state);
      this.checkoutForm.controls['city'].setValue(prevAddress.city);
      this.latitude = prevAddress.latitude;
      this.longitude = prevAddress.longitude;
    }

    // Set phone number if any
    if (this.user.phone_numbers.length > 0) {
      const prevNumber = this.user.phone_numbers[this.user.phone_numbers.length - 1]; // latest/last one
      console.log(prevNumber);
      this.checkoutForm.controls['customer_phone_num'].setValue(prevNumber.phone_number);
    }
  }

  public loadMap() {
    let autocomplete;
    this.mapsAPILoader.load().then(() => {
      console.log(google); // returns undefined, expected object here
      console.log(this.searchElementRef); // returns undefined, expected object here
      if (this.searchElementRef !== undefined) {
        autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
          types: ['address']
        });
      } else {
        const element = document.getElementById('autocomplete').getElementsByTagName('input')[0];
        console.log(document.getElementById('autocomplete'));
        autocomplete = new google.maps.places.Autocomplete(element, {
          types: ['address']
        });
      }

      autocomplete.addListener('place_changed', () => {
        console.log('place changed');
        this.ngZone.run(() => {
          // get the place result
          const place = autocomplete.getPlace();

          // verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          this.checkoutForm.controls['customer_location'].setValue(place.formatted_address);

          place.address_components.forEach((item) => {
            if (item.types.includes('country')) {
              this.checkoutForm.controls['country'].setValue(item.short_name);
            }
            if (item.types.includes('administrative_area_level_1')) {
              this.checkoutForm.controls['state'].setValue(item.short_name);
            }
            if (item.types.includes('locality')) {
              this.checkoutForm.controls['city'].setValue(item.short_name);
            }
            if (item.types.includes('postal_code')) {
              this.checkoutForm.controls['postal_code'].setValue(item.short_name);
            }
          });
          // set latitude, longitude and zoom
          this.latitude = place.geometry.location.lat();
          this.longitude = place.geometry.location.lng();
          this.zoom = 12;
        });
      });
    });
  }

  public forward() {
    const addressControl = this.checkoutForm.get('customer_location');
    addressControl.markAsTouched({onlySelf: true});
    const addressValid = addressControl.valid;

    const detailsControl = this.checkoutForm.get('service_details');
    detailsControl.markAsTouched({onlySelf: true});
    const detailsValid = detailsControl.valid;

    const phoneControl = this.checkoutForm.get('customer_phone_num');
    const phoneValue = this.checkoutForm.controls['customer_phone_num'].value;
    phoneControl.markAsTouched({onlySelf: true});
    const phoneValid = phoneControl.valid;

    console.log(addressValid);
    console.log(detailsValid);
    console.log(phoneValid);

    if (addressValid && detailsValid && phoneValue.length > 0) {
      this.steps++;
    }
  }

  public navigateBack() {
    this.navController.back();
  }

  public back() {
    this.steps--;
  }

  public next() {
    if (this.steps === 1) {
      this.forward();
    } else {
      this.orderInstant();
    }
  }

  selectedServiceOption(id, val) {
    const result = this.service_options.findIndex(x => x.id === id);
    if (result !== undefined && result > -1) {
      this.service_options[result]['chosen'] = val;
      console.log(this.service_options);
    }
  }

  public validateTimes(service_date, requested_time) {
    const now = new Date();
    const nowDay = new Date();
    const hour = now.getHours();
    const selectedDate = new Date(service_date);
    const selectedDateTime = new Date(service_date + ' ' + requested_time);

    // Add a day
    selectedDate.setDate(selectedDate.getDate() + 1);
    nowDay.setDate(nowDay.getDate() + 1);

    if (selectedDateTime < now) { // date and time past
      // Message.showError('The requested time you have selected has already past');
      this.globals.presentAlert('The requested time you have selected has already past');
      return false;
    } else if (selectedDateTime < nowDay) { // within 24 hours
      if (!this.warningOpened) {
        this.openWarning();
      }
    }

    if (this.requested_time !== 'asap') {
      console.log(this.requested_time);
      if (now.setHours(0, 0, 0, 0) === selectedDate.setHours(0, 0, 0, 0)) {
        const nowHours = hour + ':00';
        if (this.globals.strtotime(this.requested_time) <= this.globals.strtotime(nowHours)) {
          this.globals.presentAlert('The requested time you have selected has already past');
          return false;
        }
      }
    }

    return true;
  }

  public openWarning() {
    this.warningOpened = true;
    this.globals.presentAlert(`Same day and next day services: let's give it a try! Just a heads up that in some cases
                        it may be difficult to have your order filled on such short notice. We encourage you to
                        book services more than 24-hours in advance where possible!`);
  }

  public orderDirect() {
    this.is_immediate = 0;
    this.order();
  }

  public orderInstant() {
    this.is_immediate = 1;
    this.order();
  }

  public order() {
    console.log(this.requested_time);

    Object.keys(this.checkoutForm.controls).forEach(field => {
      const control = this.checkoutForm.get(field);
      control.markAsTouched({onlySelf: true});
    });

    if (this.requested_time === undefined) {
      this.globals.presentToast('Select the time of your service');
      return;
    }

    if (this.frequency === undefined) {
      this.globals.presentToast('Select the frequency of your service');
      return;
    }

    if (this.hours === undefined) {
      this.globals.presentToast('Select the number of hours');
      return;
    }

    if (this.minutes === undefined) {
      this.globals.presentToast('Select the number of minutes');
      return;
    }

    if (!this.validateTimes(this.selected_date, this.requested_time)) {
      return;
    }

    if (this.minutes === 1) { // work around a bug around having 0 as a value with ngModel
      this.minutes = 0;
    }

    const customer_location = this.checkoutForm.controls['customer_location'].value;
    const country_code = this.checkoutForm.controls['country'].value;
    const state = this.checkoutForm.controls['state'].value;
    const city = this.checkoutForm.controls['city'].value;
    const service_details = this.checkoutForm.controls['service_details'].value;
    const customer_phone_num = this.checkoutForm.controls['customer_phone_num'].value;
    const data = {
      customer_id: this.user.id,
      sub_category_id: this.service.id,
      customer_location: customer_location,
      country_code: country_code,
      state: state,
      city: city,
      customer_latitude: this.latitude,
      customer_longitude: this.longitude,
      booked_hours: this.hours,
      booked_minutes: this.minutes,
      service_date: this.selected_date,
      service_details: service_details,
      requested_time: this.requested_time,
      customer_email: this.user.email,
      supplier_id: 0,
      frequencies_id: this.frequency,
      is_immediate: this.is_immediate,
      customer_phone_num: customer_phone_num,
      subcategory: this.service,
      service_options: this.service_options,
      submitted_estimation: '', // TODO
      estimated_hours: 0, // TODO
    };

    console.log(data);

    this.globals.presentLoading('Loading...').then((res) => {

      this.orderService.initialize(data).subscribe((r: any) => {
          if (this.is_immediate === 1) {
            this.navController.navigateRoot('customer/order/finalize/' + r.uuid_booking);
          } else {
            this.navController.navigateRoot('customer/order/choose/' + r.uuid_booking);
          }
          this.globals.loading.dismiss();
        },
        (err) => {
          const errMsg = err.error.error;
          this.globals.loading.dismiss();
          this.globals.presentAlert(errMsg);
        }, () => {
          this.globals.loading.dismiss();
        });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }

}
