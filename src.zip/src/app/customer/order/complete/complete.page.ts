import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {Storage} from '@ionic/storage';
import {NavController} from '@ionic/angular';
import {BookingService} from '../../../services/general/booking.service';
import {OrderService} from '../../../services/general/order.service';
import {Globals} from '../../../globals';
import {LoginService} from '../../../services/customer/auth/login.service';
import {AccountService} from '../../../services/customer/account/account.service';

@Component({
  selector: 'app-complete',
  templateUrl: './complete.page.html',
  styleUrls: ['./complete.page.scss'],
})
export class CompletePage implements OnInit {
  public uuid: any;
  public booking: any;
  // http://localhost:8100/customer/order/complete/192815e3-9e7d-4bad-9266-397086440978
  constructor(private route: ActivatedRoute, private router: Router, private storage: Storage, private navController: NavController,
  public bookingService: BookingService, public orderService: OrderService, public globals: Globals,
  public loginService: LoginService, public accountService: AccountService) { }

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.uuid = params['uuid'];
      // get booking details
      this.bookingService.getBookingByUuid(this.uuid).subscribe((result: any) => {
        this.booking = result;
      }, (err) => {
        console.log(err);
      });
    });
  }

  public go(route: string) {
    this.navController.navigateRoot(route);
  }
}
