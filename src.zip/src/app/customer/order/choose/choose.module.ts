import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { ChoosePage } from './choose.page';
import {StarRatingModule} from 'angular-star-rating';

const routes: Routes = [
  {
    path: '',
    component: ChoosePage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes),
    StarRatingModule.forRoot()
  ],
  declarations: [ChoosePage]
})
export class ChoosePageModule {}
