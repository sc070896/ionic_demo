import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Storage } from '@ionic/storage';
import { OrderService } from '../../../services/general/order.service';
import { BookingService } from '../../../services/general/booking.service';
import { NavController, IonRefresher, Events, IonInfiniteScroll } from '@ionic/angular';
import { Globals } from '../../../globals';

@Component({
  selector: 'app-choose',
  templateUrl: './choose.page.html',
  styleUrls: ['./choose.page.scss'],
})
export class ChoosePage implements OnInit {
  @ViewChild('inscroll') supplier_scroll: IonInfiniteScroll;
  @ViewChild('refresher') refresher: IonRefresher;
  public user: any;
  public uuid: any;
  public booking: any;
  public suppliers = [];
  public page = 1;
  public last_page = 4;
  public sort_by = 'rating_desc';
  public loading_init = true;
  public hideFilter = true;
  public name = '';
  public min_price: number = 1;
  public max_price: number = 250;
  public price_range: any = {
    lower: 1,
    upper: 250
  };

  constructor(private route: ActivatedRoute, private router: Router, private storage: Storage, private navController: NavController,
    public bookingService: BookingService, public orderService: OrderService, public globals: Globals, public events: Events) {
    this.price_range.lower = 1;
    this.price_range.upper = 250;
  }

  // http://localhost:8100/customer/order/choose/192815e3-9e7d-4bad-9266-397086440978
  ngOnInit() {
    this.storage.get('user').then((res) => {
      this.user = res;
    });
    this.route.params.subscribe((params) => {
      console.log(params['uuid']);
      this.uuid = params['uuid'];
      // get booking details
      this.bookingService.getBookingByUuid(this.uuid).subscribe((result: any) => {
        console.log(result);
        this.booking = result;
        if (this.booking.is_asap === 1) {
          this.booking.requested_time = 'asap';
        }
        if (this.booking.flexible === 1) {
          this.booking.requested_time = 'flexible';
        }
        this.getSuppliers(null);
      }, (err) => {
        console.log(err);
      });
    });

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.refresh();
    });
  }

  public priceRange() {
    console.log(this.price_range);
    this.min_price = this.price_range.lower;
    this.max_price = this.price_range.upper;
    this.refresh();
  }

  public getSuppliers(event) {
    this.orderService.getSuppliers(this.page, this.sort_by, this.booking, this.name, this.min_price, this.max_price)
      .subscribe((result: any) => {
        console.log(result);
        this.last_page = result.suppliers.last_page;
        if (result.suppliers.data.length <= 0 || this.page > this.last_page) { // if the result we get is nothing or page has past last page
          if (event !== null) {
            event.disabled = true;
          }
        } else {
          result.suppliers.data.forEach((item) => {
            console.log(item);
            this.suppliers.push(item);
          });
          if (event !== null) {
            event.complete();
          }
          this.page = result.suppliers.current_page + 1;
        }
        this.loading_init = false;
      }, (err) => {
        console.log(err);
        this.loading_init = false;
      });
  }

  public getSuppliersRefresher(event) {
    this.orderService.getSuppliers(this.page, this.sort_by, this.booking, this.name, this.min_price, this.max_price)
      .subscribe((result: any) => {
        this.last_page = result.suppliers.last_page;
        this.suppliers = [];
        result.suppliers.data.forEach((item) => {
          console.log(item);
          this.suppliers.push(item);
        });
        if (event !== null) {
          event.complete();
        }
        this.page = result.suppliers.current_page + 1;
      }, (err) => {
        console.log(err);
        this.refresher.complete();
      });
  }

  public refresh() {
    this.page = 1;
    this.getSuppliersRefresher(this.refresher);
  }

  public discountPrice(newPrice, oldPrice) {
    const price: string = (parseFloat(oldPrice) - parseFloat(newPrice)).toFixed(2);
    return price;
  }

  public toggleFilter() {
    if (this.hideFilter) {
      this.hideFilter = false;
    } else {
      this.hideFilter = true;
    }
  }

  // Reset supplier list and have new data and reset infinite scroll (turn it on)
  public changeFilter() {
    this.page = 1;
    this.supplier_scroll.complete();
    this.supplier_scroll.disabled = false;
    this.suppliers = [];
    this.loading_init = true;
    this.getSuppliers(this.supplier_scroll);
  }

  public goEdit() {
    this.navController.navigateForward('customer/order/edit/' + this.uuid);
  }

  public goToProfile(username) {
    this.navController.navigateForward('zengiver/profile/' + username);
  }

  public goToReviews(username) {
    this.navController.navigateForward('zengiver/reviews/' + username);
  }

  public choose(supplier_id) {
    const data = {
      uuid_booking: this.uuid,
      supplier_id: supplier_id,
      frequencies_id: this.booking.frequency.id,
      requested_time: this.booking.requested_time,
      service_date: this.booking.service_date,
      booked_hours: this.booking.hours,
      booked_minutes: this.booking.minutes,
    };

    this.globals.presentLoading('Loading...').then((res) => {
      this.orderService.choose(data).subscribe((r: any) => {
        console.log(r);
        this.navController.navigateForward('customer/order/finalize/' + r.uuid_booking);
      },
        (err) => {
          const errMsg = err.error.msg;
          this.globals.loading.dismiss();
          this.globals.presentAlert(errMsg);
        }, () => {
          this.globals.loading.dismiss();
        });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }
}
