import {Component, OnInit, ViewChild, ElementRef} from '@angular/core';
import {NavController, IonSlides} from '@ionic/angular';
import {Platform} from '@ionic/angular';
import {faShoppingBag} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-how-it-works',
  templateUrl: './how-it-works.page.html',
  styleUrls: ['./how-it-works.page.scss'],
})
export class HowItWorksPage implements OnInit {
  faShoppingBag = faShoppingBag;
  public height = '540';
  public skipMsg = 'Skip';
  @ViewChild('myslides') slides: IonSlides;

  constructor(platform: Platform, private navController: NavController) {
    platform.ready().then((readySource) => {
      const deviceHeight = platform.height();
      console.log('Width: ' + platform.width());
      console.log('Height: ' + deviceHeight);
      this.height = deviceHeight + 'px';
      this.slides.stopAutoplay();
    });
  }

  async slideChanged() {
    this.slides.isEnd().then((res) => {
      if (res) {
        this.skipMsg = 'Alright, I got it!';
      } else {
        this.skipMsg = 'Skip';
      }
    });
  }

  public skip() {
    this.navController.navigateForward('choose');
  }

  public slideForward() {
    this.slides.slideNext();
  }

  ngOnInit() {
  }

}
