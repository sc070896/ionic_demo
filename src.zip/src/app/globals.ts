// globals.ts
import {Injectable} from '@angular/core';
import {AlertController, LoadingController, ToastController} from '@ionic/angular';
import {HttpHeaders} from '@angular/common/http';
import {environment as ENV} from '../environments/environment';

@Injectable()
export class Globals {
  public disconnected = false;
  public pusher_app_key = 'a3c423f7983d4694f249';
  public pusher_cluster = 'us2';
  public bucket_url = 'https://zengotca-dev.s3.ca-central-1.amazonaws.com/';
  public assets_bucket_url = 'https://s3.ca-central-1.amazonaws.com/zengot-assets/';
  public days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  public month_long_names = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
    'August', 'September', 'October', 'November', 'December'];
  public month_short_names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
  public times = [
    {
      id: 1,
      time: '8:00 AM',
      value: '08:00',
    },
    {
      id: 2,
      time: '9:00 AM',
      value: '09:00',
    },
    {
      id: 3,
      time: '10:00 AM',
      value: '10:00',
    },
    {
      id: 4,
      time: '11:00 AM',
      value: '11:00',
    },
    {
      id: 5,
      time: '12:00 PM',
      value: '12:00',
    },
    {
      id: 6,
      time: '1:00 PM',
      value: '13:00',
    },
    {
      id: 7,
      time: '2:00 PM',
      value: '14:00',
    },
    {
      id: 8,
      time: '3:00 PM',
      value: '15:00',
    },
    {
      id: 9,
      time: '4:00 PM',
      value: '16:00',
    },
    {
      id: 10,
      time: '5:00 PM',
      value: '17:00',
    },
    {
      id: 11,
      time: '6:00 PM',
      value: '18:00',
    },
    {
      id: 12,
      time: '7:00 PM',
      value: '19:00',
    },
    {
      id: 13,
      time: '8:00 PM',
      value: '20:00',
    },
  ];
  public api_url = 'https://api.zengot.com/v1/';
  public loading: any = null; // global loading controller
  public headers = new HttpHeaders({
    'Content-Type': 'application/json'
  });
  public canvas;
  public maxSize = 500;
  public file;
  public image;

  constructor(public alertController: AlertController, public loadingController: LoadingController,
              public toastController: ToastController) {
    this.api_url = ENV.API_URL;
    this.assets_bucket_url = ENV.S3_ASSETS_URL;
    this.bucket_url = ENV.S3_URL;
    this.pusher_app_key = ENV.PUSHER_KEY;
    this.pusher_cluster = ENV.PUSHER_CLUSTER;
    console.log(this.bucket_url);
    console.log(this.pusher_app_key);
  }

  async presentLoading(msg: string) {
    this.loading = await this.loadingController.create({
      message: msg
    });

    // If loading for 30 seconds or more just dismiss the loading to allow users to not have to refresh the app to continue
    setTimeout(() => {
      if (this.loading !== null) {
        this.loading.dismiss();
      }
    }, 30000);

    return await this.loading.present();
  }

  async presentAlert(msg) {
    const alert = await this.alertController.create({
      subHeader: msg,
      buttons: ['OK']
    });

    await alert.present();
  }

  async presentToast(msg) {
    const toast = await this.toastController.create({
      message: msg,
      showCloseButton: true,
      position: 'bottom',
      closeButtonText: 'X',
      duration: 5000
    });
    await toast.present();
  }

  async presentTopToast(msg) {
    const toast = await this.toastController.create({
      message: msg,
      showCloseButton: true,
      position: 'top',
      closeButtonText: 'X',
      duration: 5000
    });
    await toast.present();
  }

  initials(name: string) {
    return name.substr(0, 1) + '.';
  }

  readImage(input) {
    let result = '';
    if (input.files && input.files[0]) {
      const reader = new FileReader();

      reader.onload = function (e) {
        result = (<any>e.target).result;
      };

      reader.readAsDataURL(input.files[0]);
    }
    return result;
  }

  public strtotime(string) {
    const time = string.split(':');
    return time[0] * 3600 + time[1] * 60;
  }

  formatMysqlDate(date) {
    // Split timestamp into [ Y, M, D, h, m, s ]
    const t = date.split(/[- :]/);

    // Apply each element to the Date function
    const d = new Date(Date.UTC(t[0], t[1] - 1, t[2], t[3], t[4], t[5]));
    return d;
  }

  formatDate(d) {
    const options = {year: 'numeric', month: 'long', day: 'numeric'};
    const date = new Date(d + ' UTC');
    return date.toLocaleDateString('en-US', options); // "September 17, 2018"
  }

  formatDateShort(d) {
    const options = {month: 'short', day: 'numeric'};
    const date = new Date(d + ' UTC');
    return date.toLocaleDateString('en-US', options); // "Sep 17"
  }

  formatDateLong(d) {
    const options = {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      hour12: true,
      timeZoneName: 'short'
    };
    const date = new Date(d + ' UTC');
    return date.toLocaleDateString('en-US', options); // "Wed Jun 29 2011 09:52:48 GMT-0700 (PDT)"
  }

  formatDateYearMonthDay(date) {
    const d = new Date(date),
      year = d.getFullYear();
    let month = '' + (d.getMonth() + 1),
      day = '' + d.getDate();

    if (month.length < 2) {
      month = '0' + month;
    }

    if (day.length < 2) {
      day = '0' + day;
    }

    return [year, month, day].join('-');
  }

  formatTime(d) {
    const options = {weekday: 'long', hour: 'numeric', minute: 'numeric', hour12: true, timeZoneName: 'short'};
    const date = new Date(d + ' UTC');
    return date.toLocaleDateString('en-US', options); // "Wed Jun 29 2011 09:52:48 GMT-0700 (PDT)"
  }

  formatTimeLocal(d) {
    const options = {year: 'numeric', month: 'long', day: 'numeric', weekday: 'long',
      hour: 'numeric', minute: 'numeric', hour12: true, timeZoneName: 'short'};
    const date = new Date(d);
    return date.toLocaleDateString('en-US', options); // "Wed Jun 29 2011 09:52:48 GMT-0700 (PDT)"
  }

  formatCurrency(num) {
    return parseFloat(num).toFixed(2);
  }

  convertTime(time) {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
      time = time.slice(1);  // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    time.splice(3, 1);
    return time.join(''); // return adjusted time or original string
  }

  public formatHours(h: number) {
    // split whole number and decimals
    const decimals = h - Math.floor(h);
    const hours = h - decimals;
    const minutes = 60 * decimals;
    // return * hours and * minutes
    if (decimals === 0) {
      return hours + ' hours';
    } else {
      return hours + ' hours and ' + minutes + ' minutes';
    }
  }

  /**
   * Compare between two time strings
   * @param str1 - start
   * @param str2 - end
   */
  compareTime(str1, str2) {
    if (str1 === str2) {
      return false;
    }
    const time1 = str1.split(':');
    const time2 = str2.split(':');
    if (parseFloat(time1[0]) < parseFloat(time2[0])) {
      return true;
    } else if (parseFloat(time1[0]) === parseFloat(time2[0]) && parseFloat(time1[1]) < parseFloat(time2[1])) {
      return true;
    } else {
      return false;
    }
  }

  dataURItoBlob(dataURI: string) {
    const bytes = dataURI.split(',')[0].indexOf('base64') >= 0 ?
      atob(dataURI.split(',')[1]) :
      unescape(dataURI.split(',')[1]);
    const mime = dataURI.split(',')[0].split(':')[1].split(';')[0];
    const max = bytes.length;
    const ia = new Uint8Array(max);
    for (let i = 0; i < max; i++) {
      ia[i] = bytes.charCodeAt(i);
    }
    return new Blob([ia], {type: mime});
  }

  resize() {
    let width = this.image.width;
    let height = this.image.height;

    if (width > height) {
      if (width > this.maxSize) {
        height *= this.maxSize / width;
        width = this.maxSize;
      }
    } else {
      if (height > this.maxSize) {
        width *= this.maxSize / height;
        height = this.maxSize;
      }
    }

    this.canvas.width = width;
    this.canvas.height = height;
    this.canvas.getContext('2d').drawImage(this.image, 0, 0, width, height);
    const dataUrl = this.canvas.toDataURL('image/jpeg');
    return this.dataURItoBlob(dataUrl);
  }

  /**
   * Resize the image to width specified
   * @param maxSize
   * @param file
   */
  resizeImage(maxSize: number, file: File) {
    this.maxSize = maxSize;
    this.file = file;
    const reader = new FileReader();
    this.image = new Image();
    this.canvas = document.createElement('canvas');

    return new Promise((ok, no) => {
      if (!this.file.type.match(/image.*/)) {
        no(new Error('Not an image'));
        return;
      }

      reader.onload = (readerEvent: any) => {
        this.image.onload = () => ok(this.resize());
        this.image.src = readerEvent.target.result;
      };
      reader.readAsDataURL(this.file);
    });
  }
}

export const sender_id = '265461549350';
export const oneSignalAppId = '69345139-3ba2-4fd6-9aaf-3e919dc1a1bb';

