import {Component} from '@angular/core';

import {NavController, Platform, Events, ToastController} from '@ionic/angular';
import {SplashScreen} from '@ionic-native/splash-screen/ngx';
import {StatusBar} from '@ionic-native/status-bar/ngx';
import {Storage} from '@ionic/storage';
import {Globals, oneSignalAppId, sender_id} from './globals';
import {PusherService} from './services/customer/auth/pusher.service';
import {PusherService as SupplierPusherService} from './services/supplier/auth/pusher.service';
import {Network} from '@ionic-native/network/ngx';
import {OneSignal, OSNotificationPayload} from '@ionic-native/onesignal/ngx';
import {NetworkProvider} from './common/network-provider';
import {timer} from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent {
  customerChannelBinded = false;
  supplierChannelBinded = false;
  showSplash = true;

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private toastController: ToastController,
    public storage: Storage,
    public customerPusherService: PusherService,
    public supplierPusherService: SupplierPusherService,
    public globals: Globals,
    private navController: NavController,
    private network: Network,
    private networkProvider: NetworkProvider,
    private oneSignal: OneSignal,
    public events: Events
  ) {
    this.initializeApp();
  }

  // http://localhost:8100/customer/order/choose/0cde5412-29bb-43cd-8543-ad9b69d640aa
  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      // check login type - if customer go to customer login or zengiver login
      this.storage.get('login_type').then((res) => {
        if (res === 'supplier') {
          // if api_token is not null go to dashboard based on login_type
          this.storage.get('access_token').then((loggedRes) => {
            if (loggedRes === null || loggedRes === 'null') {
              this.navController.navigateRoot('zengiver/login');
              this.splashScreen.hide();
            } else {
              this.navController.navigateRoot('zengiver/dashboard/tabs/(home:home)');
              this.splashScreen.hide();
            }
          }, (err) => {
            this.navController.navigateRoot('zengiver/login');
            this.splashScreen.hide();
          });
        } else if (res === 'customer') {
          // if api_token is not null go to dashboard based on login_type
          this.storage.get('access_token').then((loggedRes) => {
            if (loggedRes === null || loggedRes === 'null') {
              this.navController.navigateRoot('customer/login');
              this.splashScreen.hide();
            } else {
              this.navController.navigateRoot('customer/dashboard/tabs/(home:home)');
              this.splashScreen.hide();
            }
          }, (err) => {
            this.navController.navigateRoot('customer/login');
            this.splashScreen.hide();
          });
        } else {
          this.navController.navigateRoot('/');
          this.splashScreen.hide();
        }
      }, (err) => {
        this.navController.navigateRoot('choose');
        this.splashScreen.hide();
      });

      timer(3000).subscribe(() => this.showSplash = false);

      if (this.platform.is('cordova')) {
        console.log('Connected to OneSignal');
        this.oneSignal.startInit(oneSignalAppId, sender_id);
        this.oneSignal.inFocusDisplaying(this.oneSignal.OSInFocusDisplayOption.Notification);
        this.oneSignal.handleNotificationReceived().subscribe(data => this.onPushReceived(data.payload));
        this.oneSignal.handleNotificationOpened().subscribe(data => this.onPushOpened(data.notification.payload));
        this.oneSignal.endInit();
      } else {
        console.log('not cordova');
        console.log('NOT Connected to OneSignal');
      }

      // watch network for a disconnect/reconnecting
      this.networkProvider.initializeNetworkEvents();

      // In app notifications
      this.storage.get('login_type').then((res) => {
        this.storage.get('access_token').then((loggedRes) => {
          console.log(loggedRes);
          if (loggedRes !== null && loggedRes !== 'null') { // if logged in as a customer or supplier
            if (res === 'supplier') {
              this.handleSupplierNotifications();
            } else if (res === 'customer') {
              this.handleCustomerNotifications();
            }
          }
        });
      });
    });
  }

  // Notifications for customer events
  private handleCustomerNotifications() {
    let channel = this.customerPusherService.init();
    if (channel === undefined) {
      channel = this.customerPusherService.init();
    }
    setInterval(() => {
      if (channel === undefined) {
        channel = this.customerPusherService.init();
      } else {
        if (!this.customerChannelBinded) {
          channel.bind('Illuminate\\Notifications\\Events\\BroadcastNotificationCreated', (event) => {
            if (event.flash_msg !== '') {
              this.globals.presentTopToast(event.flash_msg);
            }
            console.log(event);
          });
          this.customerChannelBinded = true;
        }
      }
    }, 5000);
  }

  // Notifications for zengiver events
  private handleSupplierNotifications() {
    let channel = this.supplierPusherService.init();
    if (channel === undefined) {
      channel = this.supplierPusherService.init();
    }
    setInterval(() => {
      if (channel === undefined) {
        channel = this.supplierPusherService.init();
      } else {
        if (!this.supplierChannelBinded) {
          channel.bind('Illuminate\\Notifications\\Events\\BroadcastNotificationCreated', (event) => {
            if (event.flash_msg !== '') {
              this.globals.presentTopToast(event.flash_msg);
            }
            console.log(event);
          });
          this.supplierChannelBinded = true;
        }
      }
    }, 5000);
  }

  private onPushReceived(payload: OSNotificationPayload) {
    // alert('Push recevied:' + payload.body);
  }

  private onPushOpened(payload: OSNotificationPayload) {
    // alert('Push opened: ' + payload.body);
  }
}
