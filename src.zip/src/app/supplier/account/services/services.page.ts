import {Component, OnInit, ViewChild} from '@angular/core';
import {AlertController, ModalController, NavController, IonRefresher, Events} from '@ionic/angular';
import {FormBuilder} from '@angular/forms';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {RegistrationService} from '../../../services/general/registration.service';
import {CategoriesService} from '../../../services/general/categories.service';
import {EditServicesPage} from '../../components/edit-services/edit-services.page';
import {ProfileService} from '../../../services/supplier/account/profile.service';

@Component({
  selector: 'app-services',
  templateUrl: './services.page.html',
  styleUrls: ['./services.page.scss'],
})
export class ServicesPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public assets_bucket_url: string;
  public user: any;
  public categories: any;
  public loading = true;
  public selected_services = [];
  public experiences = [];
  public services = [];

  constructor(private navController: NavController, private formBuilder: FormBuilder, public events: Events,
              public loginService: LoginService, public globals: Globals, private storage: Storage, public modalController: ModalController,
              public registrationService: RegistrationService, public categoriesService: CategoriesService,
              private alertController: AlertController, public profileService: ProfileService) {
  }

  ngOnInit() {
    this.assets_bucket_url = this.globals.assets_bucket_url;
    this.storage.get('user').then((user: any) => {
      this.user = user;
      this.services = user.services;
      this.init();
    });
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.getUser();
    });
  }

  public init() {
    this.getCategories();
    this.getExperiences();
  }

  public back() {
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }

  public getUser() {
    this.loginService.user().subscribe((r: any) => {
      this.user = r;
      this.services = this.user.services;
      this.storage.set('user', r).then((loginRes) => {
        this.init();
      });
      this.refresher.complete();
    }, (err) => {
      console.log(err);
      this.globals.presentTopToast('Failed to load. Please try again.');
      this.refresher.complete();
    });
  }

  getCategories() {
    this.categoriesService.getCategories().subscribe((r: any) => {
      this.categories = r.categories;
      this.loading = false;
    }, (err) => {
      console.error(err);
      this.loading = false;
    });
  }

  getExperiences() {
    this.categoriesService.getExperiences().subscribe((r: any) => {
      this.experiences = r.experiences;
    }, (err) => {
      console.error(err);
    });
  }

  /**
   * Get service to edit
   * @param c
   * @param id
   */
  async getService(c, id) {
    this.globals.presentLoading('Loading...').then((loadingRes) => {
      this.profileService.getService(id).subscribe((r: any) => {
        console.log(r);
        this.presentModal(c, r);
        this.globals.loading.dismiss();
      }, (err) => {
        console.error(err);
        this.globals.presentTopToast('Failed to load. Please try again.');
        this.globals.loading.dismiss();
      });
    });
  }

  // Show Services details to edit
  async presentModal(c, service_details) {
    const modal = await this.modalController.create({
      component: EditServicesPage,
      componentProps: <any>{
        data: c,
        experiences: this.experiences,
        service: this.services,
        service_details: service_details,
        current_services: this.user.services,
      }
    });

    modal.onDidDismiss().then((res) => {
      const data = res.data.data;
      const action = res.data.action;
      if (action === 'update' || action === 'create') {
        // store user data and update services
        this.storage.set('user', data).then(() => {
          this.user = data;
          this.services = this.user.services;
          console.log(this.services);
        });
      }
    });

    return await modal.present();
  }

  async delete(id) {
    const alert = await this.alertController.create({
      header: 'Delete Service?',
      message: 'Deleting this service, will remove you from receiving future request under this service',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Delete',
          handler: () => {
            this.globals.presentLoading('Deleting...').then((resLoading) => {
              this.profileService.deleteService(id)
                .subscribe((res: any) => {
                  this.user = res.supplier;
                  this.services = this.user.services;

                  // store new user data
                  this.storage.set('user', this.user).then(() => {
                    this.globals.presentToast(res.msg);
                    this.globals.loading.dismiss();
                  });
                }, (err) => {
                  const msg = err.error.msg;
                  this.globals.presentToast(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async selectServiceAlert() {
    const btns = [];
    this.categories.forEach((c) => {
      const found = this.user.services.findIndex(s => s.category.id === c.id);
      if (found < 0) {
        const btnObj = {
          text: c.title,
          handler: () => {
            this.presentModal(c, null);
          }
        };
        btns.push(btnObj);
      }
    });
    const alert = await this.alertController.create({
      header: 'Select a service to add',
      message: '',
      buttons: btns
    });

    await alert.present();
  }
}
