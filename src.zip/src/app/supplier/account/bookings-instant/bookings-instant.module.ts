import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { BookingsInstantPage } from './bookings-instant.page';
import {CardModule} from '../../components/bookings/card/card.module';

const routes: Routes = [
  {
    path: '',
    component: BookingsInstantPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CardModule,
    RouterModule.forChild(routes)
  ],
  declarations: [BookingsInstantPage]
})
export class BookingsInstantPageModule {}
