import {Component, OnInit, ViewChild} from '@angular/core';
import {NavController, Events,  AlertController, IonRefresher} from '@ionic/angular';
import {FormBuilder} from '@angular/forms';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {ProfileService} from '../../../services/supplier/account/profile.service';
import {RegisterService} from '../../../services/supplier/auth/register.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss']
})
export class HomePage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public user: any;
  public loading_user = true;
  public overall_rating: any;
  public randomNumber: any;

  constructor(private navController: NavController, private formBuilder: FormBuilder, public profileService: ProfileService,
              public loginService: LoginService, public globals: Globals, private storage: Storage, public events: Events,
              public alertController: AlertController, public registerService: RegisterService) {
  }

  ngOnInit() {
    this.randomNumber = Math.random();

    this.getUser(); // main event

    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.getUser();
    });
  }

  public getUser() {
    this.loginService.user().subscribe((r: any) => {
      this.randomNumber = Math.random();
      this.user = r;
      this.storage.set('user', r).then((loginRes) => {
        this.getRating();
      });
      this.refresher.complete();
      this.loading_user = false;
    }, (err) => {
      console.log(err);
      this.loading_user = false;
    });
  }

  public getRating() {
    this.profileService.getOverallRating(this.user.uuid).subscribe((result: any) => {
      console.log(result);
      this.overall_rating = result.overall_rating;
    }, (err) => {
      console.log(err);
    });
  }

  public go(route: string) {
    this.navController.navigateForward(route);
  }

  public formatCurrency(num: any) {
    return parseFloat(num).toFixed(2);
  }

  public logout() {
    this.globals.presentLoading('Logging out...').then((res) => {
      this.loginService.logout().subscribe((r: any) => {
          console.log(r);
          this.storage.remove('access_token').then((stRes) => {
              this.globals.presentToast(r.msg);
              this.navController.navigateRoot('zengiver/login');
            },
            (err) => {
              console.log(err);
              let errMsg = err.error.msg;
              if (errMsg === undefined) {
                errMsg = 'Failed to logout';
              }
              this.globals.presentAlert(errMsg);
            });
          this.globals.loading.dismiss();
        },
        (err) => {
          console.log(err);
          let errMsg = err.error.msg;
          this.globals.loading.dismiss();
          if (errMsg === undefined) {
            errMsg = 'Failed to logout';
          }
          this.globals.presentAlert(errMsg);
        }, () => {
          this.globals.loading.dismiss();
        });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }

  async resendEmailVerification() {
    const alert = await this.alertController.create({
      header: 'Resend Verification Email?',
      message: '',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Resending...').then((result) => {
              this.registerService.resendEmailVerification(this.user.uuid)
                .subscribe((res: any) => {
                  this.globals.presentTopToast(res.msg);
                  this.globals.loading.dismiss();
                }, (err) => {
                  this.globals.presentTopToast(err.error.msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.presentTopToast('Something went wrong. Please try again');
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }
}
