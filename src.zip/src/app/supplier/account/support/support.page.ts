import {Component, OnInit, ViewChild} from '@angular/core';
import {Globals} from '../../../globals';
import {AlertController, ModalController, NavController, IonRefresher, Events} from '@ionic/angular';
import {CategoriesService} from '../../../services/general/categories.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {Storage} from '@ionic/storage';
import {AgreementsComponent} from '../../../general/components/agreements/agreements.component';

@Component({
  selector: 'app-support',
  templateUrl: './support.page.html',
  styleUrls: ['./support.page.scss'],
})
export class SupportPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public faq = 'https://zengot.com/support/zengiver-support-and-faqs';
  public loading = true;
  public terms_of_use: any;
  public privacy_policy: any;
  public respect_policy: any;
  public coc: any;
  public certn_terms_of_service: any;
  public certn_privacy_policy: any;
  public service_provider_agreement: any;

  constructor(public navController: NavController, public globals: Globals, public categoriesService: CategoriesService,
              public modalController: ModalController, public registrationService: RegistrationService,
              private storage: Storage, public alertController: AlertController, public events: Events) {
  }

  ngOnInit() {
    this.init();
    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.init();
    });
  }

  public init() {
    this.getTermsOfUse();
    this.getPrivacyPolicy();
    this.getRespectPolicy();
    this.getCodeOfConduct();
    this.getServiceProviderAgreement();
    this.getCertnPrivacyPolicy();
    this.getCertnTermsOfService();
  }

  // Agree / disagree to terms of use
  async presentTermsOfUseModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{data: this.terms_of_use, hideButtons: true}
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  // Agree to privacy policy
  async presentPrivacyPolicyModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{data: this.privacy_policy, hideButtons: true}
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  async presentRespectPolicyModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{
        data: this.respect_policy,
        hideButtons: true
      }
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  async presentCocModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{
        data: this.coc,
        hideButtons: true
      }
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  async presentCertnPrivacyPolicyModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{data: this.certn_privacy_policy, hideButtons: true}
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  async presentCertnTermsOfServicesModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{data: this.certn_terms_of_service, hideButtons: true}
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  async presentServiceProviderAgreementModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{data: this.service_provider_agreement, hideButtons: true}
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  getRespectPolicy() {
    this.registrationService.getPage('respect-policy').subscribe((r: any) => {
      this.respect_policy = r.data;
      this.respect_policy.content = r.data.body;
      this.refresher.complete();
      this.loading = false;
    }, (err) => {
      console.error(err);
    });
  }

  getCodeOfConduct() {
    this.registrationService.getPage('zengiver-code-of-conduct-and-deactivation-policy').subscribe((r: any) => {
      this.coc = r.data;
      this.coc.content = r.data.body;
      this.refresher.complete();
      this.loading = false;
    }, (err) => {
      console.error(err);
    });
  }

  getTermsOfUse() {
    this.registrationService.getLegal('terms-of-use-agreement').subscribe((r: any) => {
      this.terms_of_use = r.data;
      this.refresher.complete();
      this.loading = false;
    }, (err) => {
      console.error(err);
    });
  }

  getServiceProviderAgreement() {
    this.registrationService.getLegal('zengiver-service-provider-agreement').subscribe((r: any) => {
      this.service_provider_agreement = r.data;
    }, (err) => {
      console.error(err);
    });
  }

  getPrivacyPolicy() {
    this.registrationService.getLegal('privacy-policy').subscribe((r: any) => {
      this.privacy_policy = r.data;
      this.refresher.complete();
      this.loading = false;
    }, (err) => {
      console.error(err);
    });
  }

  getCertnPrivacyPolicy() {
    this.registrationService.getLegal('certn-privacy-policy').subscribe((r: any) => {
      this.certn_privacy_policy = r.data;
    }, (err) => {
      console.error(err);
    });
  }

  getCertnTermsOfService() {
    this.registrationService.getLegal('certn-terms-of-service').subscribe((r: any) => {
      this.certn_terms_of_service = r.data;
    }, (err) => {
      console.error(err);
    });
  }

  public back() {
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }

  public go(route: string) {
    this.navController.navigateForward(route);
  }
}
