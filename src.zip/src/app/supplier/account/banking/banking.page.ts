import {Component, NgZone, OnInit, ViewChild} from '@angular/core';
import {ModalController, NavController,  Events, IonRefresher} from '@ionic/angular';
import {Globals} from '../../../globals';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {CategoriesService} from '../../../services/general/categories.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {AccountService} from '../../../services/supplier/account/account.service';
import {Storage} from '@ionic/storage';

@Component({
  selector: 'app-banking',
  templateUrl: './banking.page.html',
  styleUrls: ['./banking.page.scss'],
})
export class BankingPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  accountForm: FormGroup;
  public banks: any;
  public details: any = null;
  public user: any;
  public loading = true;
  public error = false;
  public details_empty = false;
  public hide = true;
  public show_other = false;
  public hide_info = true;

  constructor(public navController: NavController, public globals: Globals, private formBuilder: FormBuilder,
              public categoriesService: CategoriesService, public modalController: ModalController,
              public registrationService: RegistrationService, public storage: Storage,
              public accountService: AccountService, private events: Events) {
    this.accountForm = this.formBuilder.group({
      bank: ['', Validators.compose([
        Validators.required
      ])],
      bank_name: [''],
      payee_name: ['', Validators.compose([
        Validators.required
      ])],
      transit_number: ['', Validators.compose([
        Validators.required
      ])],
      institution_number: ['', Validators.compose([
        Validators.required
      ])],
      account_number: ['', Validators.compose([
        Validators.required
      ])]
    });
  }

  ngOnInit() {
    this.init();
    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.init();
    });
  }

  public init() {
    this.storage.get('user').then((res) => {
      this.user = res;
      this.getBanking();
    });
    this.getBanks();
  }

  public show() {
    this.hide = !this.hide;
  }

  public getBanks() {
    this.accountService.getBanks()
      .subscribe((res: any) => {
        console.log(res);
        this.banks = res;
      }, (err) => {
      });
  }

  public getBanking() {
    this.accountService.getBanking(this.user.id)
      .subscribe((res: any) => {
        this.details = res.data;
        if (Object.keys(this.details).length === 0) {
          this.details_empty = true;
        } else {
          this.details_empty = false;
        }
        this.loading = false;
        this.refresher.complete();
      }, (err) => {
        this.error = true;
        this.loading = false;
      });
  }

  public otherBank() {
    // show other input
    console.log(this.accountForm.controls['bank'].value);
    if (this.accountForm.controls['bank'].value === 99) {
      this.show_other = true;
    } else {
      this.show_other = false;
    }
  }

  public updateBanking() {
    Object.keys(this.accountForm.controls).forEach(field => {
      const control = this.accountForm.get(field);
      control.markAsTouched({onlySelf: true});
    });

    if (!this.accountForm.valid) {
      return;
    }

    const banks_id = (this.accountForm.controls['bank'].value === 99) ? 0 : this.accountForm.controls['bank'].value;
    const data = {
      banks_id: banks_id,
      bank_name: this.accountForm.controls['bank_name'].value,
      payee_name: this.accountForm.controls['payee_name'].value,
      transit_number: this.accountForm.controls['transit_number'].value,
      institution_number: this.accountForm.controls['institution_number'].value,
      account_number: this.accountForm.controls['account_number'].value,
    };
    this.globals.presentLoading('Updating...').then((result) => {
      this.accountService.updateBanking(this.user.id, data)
        .subscribe((res: any) => {
          this.globals.loading.dismiss();
          this.globals.presentToast(res.msg);
          this.getBanking();
        }, (err) => {
          this.globals.presentToast(err.error.msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  public back() {
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }

  public toggleHide() {
    this.hide_info = !this.hide_info;
  }
}
