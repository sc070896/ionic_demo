import {Component, OnInit} from '@angular/core';
import {AlertController, ModalController, NavController} from '@ionic/angular';
import {FormBuilder} from '@angular/forms';
import {RegisterService} from '../../../services/supplier/auth/register.service';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {RegistrationService} from '../../../services/general/registration.service';
import {FlatpickrOptions} from 'ng2-flatpickr';

@Component({
  selector: 'app-documents',
  templateUrl: './documents.page.html',
  styleUrls: ['./documents.page.scss'],
})
export class DocumentsPage implements OnInit {
  loading = true;
  public user: any;
  public has_vehicle: boolean;
  public has_insurance: boolean;
  public license_expiry: any;
  public insurance_expiry: any;
  public prev_license_date: any = '';
  public prev_insurance_date: any = '';
  public license_uploaded = false;
  public insurance_uploaded = false;
  public licenseFile = '../../../../assets/placeholders/file_placeholder.svg';
  public insuranceFile = '../../../../assets/placeholders/file_placeholder.svg';
  public license_calendar_options: FlatpickrOptions = {
    defaultDate: 'today',
    inline: false,
    onChange: (selectedDates, dateStr, instance) => {
      this.license_expiry = dateStr;
    },
    onReady: (selectedDates, dateStr, instance) => {
      this.license_expiry = dateStr;
    },
    altInput: true,
    altFormat: 'F j, Y',
    dateFormat: 'Y-m-d',
    minDate: 'today',
    disableMobile: true,
    clickOpens: true
  };

  public insurance_calendar_options: FlatpickrOptions = {
    defaultDate: 'today',
    inline: false,
    onChange: (selectedDates, dateStr, instance) => {
      this.insurance_expiry = dateStr;
    },
    onReady: (selectedDates, dateStr, instance) => {
      this.insurance_expiry = dateStr;
    },
    altInput: true,
    altFormat: 'F j, Y',
    dateFormat: 'Y-m-d',
    minDate: 'today',
    disableMobile: true,
    clickOpens: true
  };

  constructor(private navController: NavController, private formBuilder: FormBuilder, public registerService: RegisterService,
              public loginService: LoginService, public globals: Globals, private storage: Storage, public modalController: ModalController,
              private alertController: AlertController, public registrationService: RegistrationService) {
  }

  ngOnInit() {
    this.storage.get('user').then((stRes) => {
      this.user = stRes;
      if (this.user.has_vehicle) {
        this.has_vehicle = true;
      } else {
        this.has_vehicle = false;
      }
      if (this.user.supplier_driver_information !== null) {
        this.has_insurance = true;
      } else {
        this.has_insurance = false;
      }
      this.prev_license_date = this.user.license_expiry;
      this.prev_insurance_date = this.user.insurance_expiry;
      this.loading = false;
    });
  }

  submit() {
    this.globals.presentLoading('Submitting...').then((result) => {
      this.registerService.insuranceDocuments(this.user.uuid, this.has_vehicle, this.has_insurance, this.licenseFile,
        this.insuranceFile, this.license_expiry, this.insurance_expiry, this.license_uploaded, this.insurance_uploaded)
        .subscribe((res: any) => {
          this.user = res.data;
          this.storage.set('user', this.user);
          this.globals.loading.dismiss();
          this.globals.presentToast('Updated successfully');
        }, (err) => {
          this.globals.presentToast(err.error.msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  readImage(event: any, btn, file) {
    const fileBtn = document.getElementById(btn);
    if (event.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (e) => {
        switch (file) {
          case 2:
            this.licenseFile = (<any>e.target).result;
            this.license_uploaded = true;
            break;
          case 3:
            this.insuranceFile = (<any>e.target).result;
            this.insurance_uploaded = true;
            break;
        }
        fileBtn.classList.add('active');
      };
      reader.readAsDataURL(event.target.files[0]);
    } else {
      fileBtn.classList.remove('active');
    }
  }

  public back() {
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }
}
