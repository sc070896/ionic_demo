import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalController, NavController,  Events, IonRefresher} from '@ionic/angular';
import {Globals} from '../../../globals';
import {FormBuilder} from '@angular/forms';
import {CategoriesService} from '../../../services/general/categories.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {AccountService} from '../../../services/supplier/account/account.service';
import {Storage} from '@ionic/storage';
import {PhotoPage} from '../../../general/photo/photo.page';

@Component({
  selector: 'app-details',
  templateUrl: './details.page.html',
  styleUrls: ['./details.page.scss'],
})
export class DetailsPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public user: any;
  public description: any;
  public banner = '../../../../assets/images/errand_run.jpg';
  public image = '../../../../assets/images/errand_run.jpg';
  public avatar_uploaded = false;
  public banner_uploaded = false;
  public hide_avatar_cropper = true;
  public hide_banner_cropper = true;
  public randomNumber: any;
  croppedImage: any = '../../../../assets/placeholders/avatar_placeholder.svg';

  constructor(public navController: NavController, public globals: Globals, public events: Events,
              private formBuilder: FormBuilder, public categoriesService: CategoriesService, public modalController: ModalController,
              public registrationService: RegistrationService, public loginService: LoginService,
              public accountService: AccountService, private storage: Storage) {
  }

  ngOnInit() {
    this.randomNumber = Math.random();

    this.hide_banner_cropper = true;

    this.storage.get('user').then((user: any) => {
      this.description = user.description;
      this.user = user;
    });

    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.getUser();
    });
  }

  public getUser() {
    this.loginService.user().subscribe((r: any) => {
      this.randomNumber = Math.random();
      this.user = r;
      this.storage.set('user', r).then((loginRes) => {
      });
      this.refresher.complete();
    }, (err) => {
      console.log(err);
      this.refresher.complete();
    });
  }

  public updateDescription() {
    this.globals.presentLoading('Updating...').then((result) => {
      this.accountService.updateDescription(this.user.id, this.description)
        .subscribe((res: any) => {
          console.log(res);
          this.globals.loading.dismiss();
          this.globals.presentToast(res.msg);
          this.storage.set('user', res.data);
          this.user = res.data;
        }, (err) => {
          this.globals.presentToast('Something went wrong. Please try again.');
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  public updateAvatar() {
    if (!this.avatar_uploaded) {
      this.globals.presentToast(`Upload a photo of yourself`);
      return;
    }
    this.globals.presentLoading('Updating...').then((result) => {
      this.accountService.updateAvatar(this.user.id, this.croppedImage)
        .subscribe((res: any) => {
          this.randomNumber = Math.random();
          this.globals.loading.dismiss();
          this.globals.presentToast(res.msg);
          this.storage.set('user', res.data);
          this.user = res.data;
          this.user.avatar = res.data.avatar + '?' + Math.random();
          this.hide_avatar_cropper = true;
        }, (err) => {
          this.globals.presentToast('Something went wrong. Please try again.');
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  public updateBanner() {
    if (!this.banner_uploaded) {
      this.globals.presentToast(`Upload a new banner`);
      return;
    }
    this.globals.presentLoading('Updating...').then((result) => {
      this.accountService.updateBanner(this.user.id, this.banner)
        .subscribe((res: any) => {
          this.globals.loading.dismiss();
          this.globals.presentToast(res.msg);
          this.storage.set('user', res.data);
          this.user = res.data;
          this.user.thumbnail = res.data.thumbnail + '?' + Math.random();
          this.hide_banner_cropper = true;
        }, (err) => {
          this.globals.presentToast('Something went wrong. Please try again.');
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  public back() {
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }

  async openPhotoModal() {
    const modal = await this.modalController.create({
      component: PhotoPage,
      componentProps: <any>{
        width: 400,
        height: 400
      }
    });

    modal.onDidDismiss().then((res) => {
      if (res.data.image !== undefined) {
        this.croppedImage = res.data.image;
        this.avatar_uploaded = true;
      }
    });

    return await modal.present();
  }

  async openBannerPhotoModal() {
    const modal = await this.modalController.create({
      component: PhotoPage,
      componentProps: <any>{
        width: 1280,
        height: 800
      }
    });

    modal.onDidDismiss().then((res) => {
      if (res.data.image !== undefined) {
        this.banner = res.data.image;
        this.hide_banner_cropper = false;
        this.banner_uploaded = true;
      }
    });

    return await modal.present();
  }
}
