import { Component, OnInit, ViewChild } from '@angular/core';
import { AlertController, ModalController, NavController, IonRefresher, Events } from '@ionic/angular';
import { FormBuilder } from '@angular/forms';
import { LoginService } from '../../../services/supplier/auth/login.service';
import { Globals } from '../../../globals';
import { Storage } from '@ionic/storage';
import { ProfileService } from '../../../services/supplier/account/profile.service';
import { EditAvailabilityPage } from '../../components/edit-availability/edit-availability.page';

@Component({
  selector: 'app-availability',
  templateUrl: './availability.page.html',
  styleUrls: ['./availability.page.scss'],
})
export class AvailabilityPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  hours = [];
  public loading = true;
  public user: any;
  public error = false;

  constructor(private navController: NavController, private formBuilder: FormBuilder, public profileService: ProfileService,
    public loginService: LoginService, public globals: Globals, private storage: Storage, public modalController: ModalController,
    private alertController: AlertController, private events: Events) {
  }

  ngOnInit() {
    this.getUser();

    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.getUser();
    });
  }

  public getUser() {
    this.loginService.user().subscribe((r: any) => {
      this.user = r;
      this.storage.set('user', r).then((loginRes) => {
        this.getHours();
      });
      this.refresher.complete();
    }, (err) => {
      console.log(err);
      this.globals.presentTopToast('Failed to load. Please try again.');
      this.refresher.complete();
    });
  }

  public getHours() {
    this.profileService.getAvailability(this.user.id)
      .subscribe((res: any) => {
        this.hours = res;
        this.loading = false;
      }, (err) => {
        this.loading = false;
      });
  }

  async presentModal(id, title, isUpdate) {
    const modal = await this.modalController.create({
      component: EditAvailabilityPage,
      componentProps: <any>{
        title: title,
        data: {
          id: id,
          suppliers_id: this.user.id,
          isUpdate: isUpdate,
          details: {}
        },
      }
    });

    modal.onDidDismiss().then((res) => {
      const data = res.data.data;
      const action = res.data.action;
      if (action === 'update' || action === 'create') {
        // store user data and update services
        this.storage.set('user', data).then(() => {
          this.getHours();
        });
      }
    });

    return await modal.present();
  }

  async presentUpdateModal(id, title, day, start, end) {
    const modal = await this.modalController.create({
      component: EditAvailabilityPage,
      componentProps: <any>{
        title: title,
        data: {
          id: id,
          suppliers_id: this.user.id,
          isUpdate: true,
          details: {
            day: day,
            start: start,
            end: end,
          }
        },
      }
    });

    modal.onDidDismiss().then((res) => {
      const data = res.data.data;
      const action = res.data.action;
      if (action === 'update' || action === 'create') {
        // store user data and update services
        this.storage.set('user', data).then(() => {
          this.getHours();
        });
      }
    });

    return await modal.present();
  }

  async delete(id) {
    const alert = await this.alertController.create({
      header: 'Delete Availability?',
      message: '',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Delete',
          handler: () => {
            this.globals.presentLoading('Deleting...').then((resLoading) => {
              this.profileService.deleteAvailability(id)
                .subscribe((res: any) => {
                  this.getHours();
                  this.globals.presentToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentToast(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  public convertTime(d) {
    return this.globals.convertTime(d);
  }

  public back() {
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }
}
