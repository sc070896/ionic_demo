import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalController, NavController, Events, IonRefresher} from '@ionic/angular';
import {FormBuilder} from '@angular/forms';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {RegistrationService} from '../../../services/general/registration.service';
import {RegisterService} from '../../../services/supplier/auth/register.service';

@Component({
  selector: 'app-areas',
  templateUrl: './areas.page.html',
  styleUrls: ['./areas.page.scss'],
})
export class AreasPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  areas = [];
  states = [];
  public selected_cities = [];
  public selected_state: number;
  public loading = true;
  public user: any;
  public error = false;

  constructor(private navController: NavController, private formBuilder: FormBuilder, public registerService: RegisterService,
              public loginService: LoginService, public globals: Globals, private storage: Storage, public modalController: ModalController,
              private events: Events, public registrationService: RegistrationService) {
  }

  ngOnInit() {
    this.getUser();

    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.getUser();
    });
  }

  public getUser() {
    this.loginService.user().subscribe((r: any) => {
      this.user = r;
      this.storage.set('user', r).then((loginRes) => {
        this.getStates();
        this.selected_state = this.user.states_id;
        this.user.cities.forEach((item) => {
          this.selected_cities.push(item.id);
        });
      });
      this.refresher.complete();
    }, (err) => {
      console.log(err);
      this.globals.presentTopToast('Failed to load. Please try again.');
      this.refresher.complete();
    });
  }

  getStates() {
    this.registrationService.getStates().subscribe((r: any) => {
      this.states = r;
      this.loading = false;
    }, (err) => {
      console.error(err);
      this.loading = false;
    });
  }

  toggleCity(id) {
    const i = this.selected_cities.findIndex(city => city === id);

    if (i > -1) { // remove if found
      this.selected_cities.splice(i, 1);
    } else { // add if not
      this.selected_cities.push(id);
    }

    console.log(this.selected_cities);
  }

  submitAreas() {
    if (this.selected_state === undefined) {
      this.globals.presentToast(`Select a province/state`);
      return;
    }
    if (this.selected_cities.length < 1) {
      this.globals.presentToast(`Select at least one city/area to provide your services in`);
      return;
    }
    this.globals.presentLoading('Submitting...').then((result) => {
      this.registerService.areas(this.user.uuid, this.selected_state, this.selected_cities)
        .subscribe((res: any) => {
          this.getUser();
          this.globals.loading.dismiss();
          this.globals.presentToast(res.msg);
        }, (err) => {
          this.globals.presentToast(err.error.msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  public back() {
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }
}
