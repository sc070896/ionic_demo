import {Component, NgZone, OnInit, ViewChild} from '@angular/core';
import {ModalController, NavController,  Events, IonRefresher} from '@ionic/angular';
import {MapsAPILoader} from '@agm/core';
import {Globals} from '../../../globals';
import {FormBuilder} from '@angular/forms';
import {CategoriesService} from '../../../services/general/categories.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {RegisterService} from '../../../services/supplier/auth/register.service';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {AccountService} from '../../../services/supplier/account/account.service';
import {Storage} from '@ionic/storage';
import {DetailsPage} from '../../bookings/details/details.page';
import {EarningDetailsPage} from '../../components/earning-details/earning-details.page';

@Component({
  selector: 'app-earnings',
  templateUrl: './earnings.page.html',
  styleUrls: ['./earnings.page.scss'],
})
export class EarningsPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public user: any;
  public loading = true;
  public from = '';
  public from_text = '';
  public to = '';
  public to_text = '';
  public current_date: any;
  public earnings = [];
  public recent_earnings = [];
  public weekly_earnings = 0;

  constructor(public navController: NavController, private mapsAPILoader: MapsAPILoader, private ngZone: NgZone, public globals: Globals,
              private formBuilder: FormBuilder, public categoriesService: CategoriesService, public modalController: ModalController,
              public registrationService: RegistrationService, public registerService: RegisterService, public loginService: LoginService,
              public accountService: AccountService, private storage: Storage, public events: Events) {
  }

  ngOnInit() {
    this.storage.get('user').then((res) => {
      this.user = res;
      this.init();
    });

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.init();
    });
  }

  public init() {
    this.getPreviousDate(5);
    this.getRecentEarnings();
  }

  public getEarnings() {
    this.accountService.getEarnings(this.user.id, this.from, this.to, false)
      .subscribe((res: any) => {
        console.log(res);
        this.earnings = res.data;
        this.weekly_earnings = 0;
        this.earnings.forEach((item) => {
          this.weekly_earnings = this.weekly_earnings + parseFloat(item.amount);
        });
        this.refresher.complete();
      }, (err) => {
      });
  }

  public getRecentEarnings() {
    this.accountService.getEarnings(this.user.id, this.from, this.to, true)
      .subscribe((res: any) => {
        console.log(res);
        this.recent_earnings = res.data;
        this.loading = false;
      }, (err) => {
      });
  }

  async goDetails(booking: any) {
    const modal = await this.modalController.create({
      component: DetailsPage,
      componentProps: <any>{b: booking}
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  async goEarningDetails(booking: any) {
    const modal = await this.modalController.create({
      component: EarningDetailsPage,
      componentProps: <any>{b: booking}
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  /**
   * 7 - sunday | 6 - monday | 5 - tuesday | 4 - wednesday | 3 - thursday | 2 - friday | 1 - saturday
   * @param day
   */
  public getPreviousDate(day) {
    const prevDate = new Date();
    prevDate.setDate(prevDate.getDate() - (prevDate.getDay() + day) % 7);
    this.current_date = prevDate;
    console.log(prevDate);
    console.log(this.formatDateYearMonthDay(prevDate));
    console.log(this.formatDateShort(prevDate));
    this.from_text = this.formatDateShort(prevDate);
    this.from = this.formatDateYearMonthDay(prevDate);
    this.getNextDate(prevDate);
  }

  public getNextDate(date) {
    const newDate = new Date(date);
    newDate.setDate(newDate.getDate() + 7);
    console.log(newDate);
    console.log(this.formatDateYearMonthDay(newDate));
    console.log(this.formatDateShort(newDate));
    this.to_text = this.formatDateShort(newDate);
    this.to = this.formatDateYearMonthDay(newDate);
    this.getEarnings();
  }

  public forwardDate() {
    this.current_date.setDate(this.current_date.getDate() + 7);
    this.from_text = this.formatDateShort(this.current_date);
    this.from = this.formatDateYearMonthDay(this.current_date);
    this.getNextDate(this.current_date);
  }

  public backDate() {
    this.current_date.setDate(this.current_date.getDate() - 7);
    this.from_text = this.formatDateShort(this.current_date);
    this.from = this.formatDateYearMonthDay(this.current_date);
    this.getNextDate(this.current_date);
  }

  public formatCurrency(num: any) {
    if (num < 0) {
      const number = Math.abs(num);
      return '-$' + number.toFixed(2);
    } else {
      const number = Math.abs(num);
      return '$' + number.toFixed(2);
    }
  }

  public formatDate(d: any) {
    return this.globals.formatDate(d);
  }

  public formatDateShort(d: any) {
    return this.globals.formatDateShort(d);
  }

  public formatDateYearMonthDay(d: any) {
    return this.globals.formatDateYearMonthDay(d);
  }

  public initials(name: any) {
    return this.globals.initials(name);
  }

  public back() {
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }

  public go(route: string) {
    this.navController.navigateForward(route);
  }
}
