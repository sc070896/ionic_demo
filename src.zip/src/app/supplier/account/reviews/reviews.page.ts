import {Component, OnInit, ViewChild} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {ProfileService} from '../../../services/supplier/account/profile.service';
import { NavController,  Events, IonRefresher, IonInfiniteScroll} from '@ionic/angular';
import {ReviewsService} from '../../../services/supplier/account/reviews.service';
import {Globals} from "../../../globals";

@Component({
  selector: 'app-reviews',
  templateUrl: './reviews.page.html',
  styleUrls: ['./reviews.page.scss'],
})
export class ReviewsPage implements OnInit {
  @ViewChild('inscroll') reviews_scroll: IonInfiniteScroll;
  @ViewChild('refresher') refresher: IonRefresher;

  public username: string;
  public overall_rating: any;
  public reviews = [];
  public supplier: any;
  public loading = true;
  public page = 1;
  public last_page = 4;

  constructor(private route: ActivatedRoute, private router: Router, public reviewsService: ReviewsService,
              public profileService: ProfileService, private navController: NavController, public events: Events,
              public globals: Globals) {
  }

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.username = params['username'];
      this.getSupplier();
    });

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.refresh();
    });
  }

  public getSupplier() {
    this.profileService.getSupplierByUsername(this.username).subscribe((result: any) => {
      console.log(result);
      this.supplier = result.data;
      this.getRating();
      this.getReviews(null);
    }, (err) => {
      console.log(err);
      this.loading = false;
    });
  }

  public getRating() {
    this.profileService.getOverallRating(this.supplier.uuid).subscribe((result: any) => {
      this.overall_rating = result.overall_rating;
    }, (err) => {
      console.log(err);
      this.loading = false;
    });
  }

  public getReviews(event) {
    this.reviewsService.getReviews(this.supplier.id, this.page).subscribe((result: any) => {
      this.last_page = result.last_page;
      if (result.data.length <= 0 || this.page > this.last_page) { // if the result we get is nothing or page has past last page
        if (event !== null) {
          event.disabled = true;
        }
      } else {
        result.data.forEach((item) => {
          this.reviews.push(item);
        });
        if (event !== null) {
          event.complete();
        }
        this.page = result.current_page + 1;
      }
      this.loading = false;
    }, (err) => {
      console.log(err);
      this.loading = false;
    });
  }

  public getDirectWithoutDisabling(event) {
    this.reviewsService.getReviews(this.supplier.id, this.page).subscribe((result: any) => {
      const items = result.bookings;
      this.last_page = items.last_page;
      this.reviews = [];
      items.data.forEach((item) => {
        this.reviews.push(item);
      });
      if (event !== null) {
        event.complete();
      }
      this.page = items.current_page + 1;
      this.loading = false;
      this.refresher.complete();
    }, (err) => {
      console.log(err);
      this.loading = false;
      this.refresher.complete();
    });
  }

  public refresh() {
    this.page = 1;
    this.getDirectWithoutDisabling(this.refresher);
  }

  public back() {
    console.log('back');
    this.navController.back();
  }
}
