import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { TabsPage } from './tabs.page';
import { HomePage } from '../home/home.page';
import { AboutPage } from '../about/about.page';
import { BookingsPage } from '../bookings/bookings.page';
import { InstantPage } from '../instant/instant.page';
import { ServicesPage } from '../services/services.page';
import { AvailabilityPage } from '../availability/availability.page';
import { AreasPage } from '../areas/areas.page';
import {PersonalPage} from '../personal/personal.page';
import {BankingPage} from '../banking/banking.page';
import {OrientationPage} from '../orientation/orientation.page';
import {SettingsPage} from '../settings/settings.page';
import {DetailsPage} from '../details/details.page';
import {EarningsPage} from '../earnings/earnings.page';
import {BookingsInstantPage} from '../bookings-instant/bookings-instant.page';
import {NotificationsPage} from '../notifications/notifications.page';
import {DocumentsPage} from '../documents/documents.page';
import {AllEarningsPage} from '../all-earnings/all-earnings.page';
import {SupportPage} from '../support/support.page';
import {ReportPage} from '../report/report.page';
import {BackgroundCheckPage} from '../background-check/background-check.page';

const routes: Routes = [
  {
    path: 'tabs',
    component: TabsPage,
    children: [
      {
        path: 'home',
        outlet: 'home',
        component: HomePage
      },
      {
        path: 'about',
        outlet: 'about',
        component: AboutPage
      },
      {
        path: 'bookings',
        outlet: 'bookings',
        component: BookingsPage
      },
      {
        path: 'bookings-instant',
        outlet: 'bookings-instant',
        component: BookingsInstantPage
      },
      {
        path: 'instant',
        outlet: 'instant',
        component: InstantPage
      },
      {
        path: 'services',
        outlet: 'services',
        component: ServicesPage
      },
      {
        path: 'availability',
        outlet: 'availability',
        component: AvailabilityPage
      },
      {
        path: 'areas',
        outlet: 'areas',
        component: AreasPage
      },
      {
        path: 'personal',
        outlet: 'personal',
        component: PersonalPage
      },
      {
        path: 'banking',
        outlet: 'banking',
        component: BankingPage
      },
      {
        path: 'orientation',
        outlet: 'orientation',
        component: OrientationPage
      },
      {
        path: 'settings',
        outlet: 'settings',
        component: SettingsPage
      },
      {
        path: 'details',
        outlet: 'details',
        component: DetailsPage
      },
      {
        path: 'earnings',
        outlet: 'earnings',
        component: EarningsPage
      },
      {
        path: 'notifications',
        outlet: 'notifications',
        component: NotificationsPage
      },
      {
        path: 'documents',
        outlet: 'documents',
        component: DocumentsPage
      },
      {
        path: 'all-earnings',
        outlet: 'all-earnings',
        component: AllEarningsPage
      },
      {
        path: 'support',
        outlet: 'support',
        component: SupportPage
      },
      {
        path: 'report',
        outlet: 'report',
        component: ReportPage
      },
      {
        path: 'background-check',
        outlet: 'background-check',
        component: BackgroundCheckPage
      }
    ]
  },
  {
    path: '/zengiver/dashboard',
    redirectTo: '/tabs/(home:home)',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TabsPageRoutingModule {}
