import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { TabsPageRoutingModule } from './tabs.router.module';

import { TabsPage } from './tabs.page';
import { InstantPageModule } from '../instant/instant.module';
import { BookingsPageModule } from '../bookings/bookings.module';
import { AboutPageModule } from '../about/about.module';
import { HomePageModule } from '../home/home.module';
import { ServicesPageModule } from '../services/services.module';
import { AvailabilityPageModule } from '../availability/availability.module';
import { AreasPageModule } from '../areas/areas.module';
import {PersonalPageModule} from '../personal/personal.module';
import {BankingPageModule} from '../banking/banking.module';
import {OrientationPageModule} from '../orientation/orientation.module';
import {SettingsPageModule} from '../settings/settings.module';
import {DetailsPageModule} from '../details/details.module';
import {EarningsPageModule} from '../earnings/earnings.module';
import {BookingsInstantPageModule} from '../bookings-instant/bookings-instant.module';
import {NotificationsPageModule} from '../notifications/notifications.module';
import {DocumentsPageModule} from '../documents/documents.module';
import {AllEarningsPageModule} from '../all-earnings/all-earnings.module';
import {SupportPageModule} from '../support/support.module';
import {ReportPageModule} from '../report/report.module';
import {BackgroundCheckPageModule} from '../background-check/background-check.module';

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    TabsPageRoutingModule,
    BookingsInstantPageModule,
    EarningsPageModule,
    DetailsPageModule,
    SettingsPageModule,
    OrientationPageModule,
    BankingPageModule,
    PersonalPageModule,
    HomePageModule,
    AboutPageModule,
    BookingsPageModule,
    InstantPageModule,
    ServicesPageModule,
    AvailabilityPageModule,
    AreasPageModule,
    NotificationsPageModule,
    DocumentsPageModule,
    AllEarningsPageModule,
    SupportPageModule,
    ReportPageModule,
    BackgroundCheckPageModule
  ],
  declarations: [TabsPage]
})
export class TabsPageModule {}
