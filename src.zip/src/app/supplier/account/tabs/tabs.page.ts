import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss']
})
export class TabsPage implements OnInit{
  ngOnInit() {
    window.addEventListener('keyboardWillShow', this.showListener);
    window.addEventListener('keyboardDidHide', this.hideListener);
  }

  showListener() {
    console.log('keyboard visible');
    document.getElementById('TabBarOpen').classList.add('keyboard-is-open');
  }
  hideListener() {
    console.log('keyboard hides');
    document.getElementById('TabBarOpen').classList.remove('keyboard-is-open');
  }
}
