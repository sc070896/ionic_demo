import {Component, ElementRef, NgZone, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {ModalController, NavController, IonRefresher} from '@ionic/angular';
import {MapsAPILoader} from '@agm/core';
import {Globals} from '../../../globals';
import {CategoriesService} from '../../../services/general/categories.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {AccountService} from '../../../services/supplier/account/account.service';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {Storage} from '@ionic/storage';

@Component({
  selector: 'app-personal',
  templateUrl: './personal.page.html',
  styleUrls: ['./personal.page.scss'],
})
export class PersonalPage implements OnInit {
  @ViewChild('search', {read: ElementRef}) searchElementRef: ElementRef;
  @ViewChild('refresher') refresher: IonRefresher;

  accountForm: FormGroup;
  public user: any;
  public latitude: number;
  public longitude: number;
  public zoom: number;
  public languages_options = [];
  public languages = [];
  public loading = true;
  public email_sent = false;
  public phone_sent = false;
  public email: any;
  public phone: any;
  public verification_token: any;
  public current_password: any;
  public new_password: any;
  public confirm_new_password: any;

  constructor(public navController: NavController, private mapsAPILoader: MapsAPILoader, private ngZone: NgZone, public globals: Globals,
              private formBuilder: FormBuilder, public categoriesService: CategoriesService, public modalController: ModalController,
              public registrationService: RegistrationService, public loginService: LoginService,
              public accountService: AccountService, private storage: Storage) {
    this.accountForm = this.formBuilder.group({
      first_name: ['', Validators.compose([
        Validators.required
      ])],
      last_name: ['', Validators.compose([
        Validators.required
      ])],
      address: ['', Validators.compose([
        Validators.required
      ])],
      apt_number: [''],
      country: ['', Validators.compose([
        Validators.required
      ])],
      state: ['', Validators.compose([
        Validators.required
      ])],
      city: ['', Validators.compose([
        Validators.required
      ])],
      zip: [''],
    });
    this.zoom = 4;
    this.latitude = 39.8282;
    this.longitude = -98.5799;
  }

  ngOnInit() {
    this.storage.get('user').then((res) => {
      this.user = res;
    });
    this.loadMap();
    this.getUser(null);
  }

  public back() {
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }

  public updatePersonal() {
    const data = {
      first_name: this.accountForm.controls['first_name'].value,
      last_name: this.accountForm.controls['last_name'].value,
      address: this.accountForm.controls['address'].value,
      apt_number: this.accountForm.controls['apt_number'].value,
      country: this.accountForm.controls['country'].value,
      state: this.accountForm.controls['state'].value,
      city: this.accountForm.controls['city'].value,
      zip: this.accountForm.controls['zip'].value,
      latitude: this.latitude,
      longitude: this.longitude,
      languages: this.languages,
      mobile: true,
    };

    this.globals.presentLoading('Submitting...').then((result) => {
      this.accountService.updatePersonal(this.user.id, data)
        .subscribe((res: any) => {
          this.getUser(this.refresher);
          this.globals.loading.dismiss();
          this.globals.presentToast(res.msg);
        }, (err) => {
          this.globals.presentToast(err.error.msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  public getUser(event) {
    this.loginService.user().subscribe((r: any) => {
      this.user = r;
      this.storage.set('user', r).then((loginRes) => {
        this.accountForm.controls['first_name'].setValue(this.user.first_name);
        this.accountForm.controls['last_name'].setValue(this.user.last_name);
        this.accountForm.controls['address'].setValue(this.user.address);
        this.accountForm.controls['apt_number'].setValue(this.user.apt_number);
        this.accountForm.controls['country'].setValue(this.user.country);
        this.accountForm.controls['state'].setValue(this.user.state);
        this.accountForm.controls['city'].setValue(this.user.city);
        this.accountForm.controls['zip'].setValue(this.user.zip);
        this.user.languages.forEach((item) => {
          this.languages.push(item.id);
        });
        if (event !== null) {
          this.refresher.complete();
        }
        console.log(this.languages);
        this.getLanguages();
        this.loading = false;
      });
    }, (err) => {
      console.log(err);
      this.loading = false;
      this.globals.presentTopToast('Failed to load. Please try again.');
    });
  }

  async updateEmail() {
    this.globals.presentLoading('Submitting...').then((result) => {
      this.accountService.updateEmail(this.user.uuid, this.email)
        .subscribe((res: any) => {
          this.getUser(this.refresher);
          this.globals.loading.dismiss();
          this.globals.presentToast(res.success);
          this.email_sent = true;
        }, (err) => {
          this.globals.presentToast(err.error.error);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  async sendPhone() {
    this.globals.presentLoading('Sending...').then((result) => {
      this.accountService.sendPhoneVerification(this.user.id, this.phone)
        .subscribe((res: any) => {
          this.globals.loading.dismiss();
          this.globals.presentToast(res.success);
          this.phone_sent = true;
        }, (err) => {
          this.globals.presentToast(err.error.error);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  async updatePhone() {
    this.globals.presentLoading('Sending...').then((result) => {
      this.accountService.verifyPhoneVerification(this.user.id, this.phone, this.verification_token)
        .subscribe((res: any) => {
          this.getUser(this.refresher);
          this.globals.loading.dismiss();
          this.globals.presentToast(res.success);
          this.phone_sent = false;
        }, (err) => {
          this.globals.presentToast(err.error.error);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  async updatePassword() {
    if (this.new_password !== this.confirm_new_password) {
      this.globals.presentToast('New password and confirm new password must be the same');
      return;
    }
    this.globals.presentLoading('Sending...').then((result) => {
      this.accountService.updatePassword(this.user.id, this.current_password, this.new_password)
        .subscribe((res: any) => {
          this.globals.loading.dismiss();
          this.globals.presentToast(res.msg);
          this.current_password = '';
          this.new_password = '';
          this.confirm_new_password = '';
        }, (err) => {
          this.globals.presentToast(err.error.msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  private loadMap() {
    // load Places Autocomplete
    this.mapsAPILoader.load().then(() => {
      console.log(google); // returns undefined, expected object here
      const autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: ['address']
      });
      autocomplete.addListener('place_changed', () => {
        this.ngZone.run(() => {
          // get the place result
          const place = autocomplete.getPlace();

          // verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          place.address_components.forEach((item) => {
            if (item.types.includes('country')) {
              this.accountForm.controls['country'].setValue(item.short_name);
            }
            if (item.types.includes('administrative_area_level_1')) {
              this.accountForm.controls['state'].setValue(item.short_name);
            }
            if (item.types.includes('locality')) {
              this.accountForm.controls['city'].setValue(item.short_name);
            }
            if (item.types.includes('zip')) {
              this.accountForm.controls['zip'].setValue(item.short_name);
            }
          });
          // set latitude, longitude and zoom
          this.latitude = place.geometry.location.lat();
          this.longitude = place.geometry.location.lng();
          this.zoom = 12;
        });
      });
    });
  }

  getLanguages() {
    this.registrationService.getLanguages().subscribe((r: any) => {
      console.log(r);

      this.languages_options = r;
    }, (err) => {
      console.error(err);
    });
  }

}
