import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllEarningsPage } from './all-earnings.page';

describe('AllEarningsPage', () => {
  let component: AllEarningsPage;
  let fixture: ComponentFixture<AllEarningsPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AllEarningsPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllEarningsPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
