import {Component, NgZone, OnInit, ViewChild} from '@angular/core';
import {IonInfiniteScroll, ModalController, NavController, Events, IonRefresher} from '@ionic/angular';
import {MapsAPILoader} from '@agm/core';
import {Globals} from '../../../globals';
import {FormBuilder} from '@angular/forms';
import {CategoriesService} from '../../../services/general/categories.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {AccountService} from '../../../services/supplier/account/account.service';
import {Storage} from '@ionic/storage';
import {DetailsPage} from '../../bookings/details/details.page';
import {EarningDetailsPage} from '../../components/earning-details/earning-details.page';

@Component({
  selector: 'app-all-earnings',
  templateUrl: './all-earnings.page.html',
  styleUrls: ['./all-earnings.page.scss'],
})
export class AllEarningsPage implements OnInit {
  @ViewChild('inscroll') bookings_scroll: IonInfiniteScroll;
  @ViewChild('refresher') refresher: IonRefresher;
  public user: any;
  public loading = true;
  public from = '';
  public to = '';
  public earnings = [];
  public recent_earnings = [];
  public page = 1;
  public last_page = 4;

  constructor(public navController: NavController, private mapsAPILoader: MapsAPILoader, private ngZone: NgZone, public globals: Globals,
              private formBuilder: FormBuilder, public categoriesService: CategoriesService, public modalController: ModalController,
              public registrationService: RegistrationService, public events: Events, public loginService: LoginService,
              public accountService: AccountService, private storage: Storage) {
  }

  ngOnInit() {
    this.storage.get('user').then((res) => {
      this.user = res;
      this.get(null);
    });

    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.refresh();
    });
  }

  public get(event) {
    this.accountService.getAllEarnings(this.user.id)
      .subscribe((result: any) => {
        const items = result.data;
        this.last_page = items.last_page;
        if (items.data.length <= 0 || this.page > this.last_page) { // if the result we get is nothing or page has past last page
          if (event !== null) {
            event.disabled = true;
          }
        } else {
          if (this.page === 1 && items.data.length <= 0) { // No bookings available
            this.earnings = [];
          } else {
            items.data.forEach((item) => {
              this.earnings.push(item);
            });
            if (event !== null) {
              event.complete();
            }
            this.page = items.current_page + 1;
          }
        }
        this.loading = false;
      }, (err) => {
        console.log(err);
        this.loading = false;
      });
  }

  public getWithoutDisabling(event) {
    this.accountService.getAllEarnings(this.user.id)
      .subscribe((result: any) => {
        const items = result.data;
        this.last_page = items.last_page;
        this.earnings = [];
        items.data.forEach((item) => {
          this.earnings.push(item);
        });
        if (event !== null) {
          event.complete();
        }
        this.page = items.current_page + 1;
        this.loading = false;
      }, (err) => {
        console.log(err);
        this.loading = false;
      });
  }

  public refresh() {
    this.page = 1;
    this.getWithoutDisabling(this.refresher);
  }

  async goDetails(booking: any) {
    const modal = await this.modalController.create({
      component: DetailsPage,
      componentProps: <any>{b: booking}
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  async goEarningDetails(booking: any) {
    const modal = await this.modalController.create({
      component: EarningDetailsPage,
      componentProps: <any>{b: booking}
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  public formatCurrency(num: any) {
    return parseFloat(num).toFixed(2);
  }

  public formatDate(d: any) {
    return this.globals.formatDate(d);
  }

  public formatDateShort(d: any) {
    return this.globals.formatDateShort(d);
  }

  public formatDateYearMonthDay(d: any) {
    return this.globals.formatDateYearMonthDay(d);
  }

  public initials(name: any) {
    return this.globals.initials(name);
  }

  public back() {
    this.navController.back();
  }
}
