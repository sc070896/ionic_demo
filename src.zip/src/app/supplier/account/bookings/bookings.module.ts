import { IonicModule } from '@ionic/angular';
import {RouterModule, Routes} from '@angular/router';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BookingsPage } from './bookings.page';
import {CardModule} from '../../components/bookings/card/card.module';
import {Ng2FlatpickrModule} from 'ng2-flatpickr';

const routes: Routes = [
  {
    path: '',
    component: BookingsPage
  }
];

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
    CardModule,
    RouterModule.forChild(routes),
    Ng2FlatpickrModule
  ],
  declarations: [BookingsPage]
})
export class BookingsPageModule {}
