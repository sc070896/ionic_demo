import {Component, OnInit, ViewChild} from '@angular/core';
import {BookingsService} from '../../../services/supplier/bookings/bookings.service';
import {
  LoadingController,
  ModalController,
  NavController,
  ToastController,
  Events,
  IonRefresher,
  IonInfiniteScroll
} from '@ionic/angular';
import {Globals} from '../../../globals';
import {PusherService} from '../../../services/supplier/auth/pusher.service';
import {Storage} from '@ionic/storage';
import {FlatpickrOptions} from 'ng2-flatpickr';

@Component({
  selector: 'app-bookings',
  templateUrl: 'bookings.page.html',
  styleUrls: ['bookings.page.scss']
})
export class BookingsPage implements OnInit {
  @ViewChild('inscroll') bookings_scroll: IonInfiniteScroll;
  @ViewChild('refresher') refresher: IonRefresher;

  public bookings = [];
  public sort_by = 'asc';
  public status = 'current';
  public page = 1;
  public last_page = 4;
  public loaded = true;
  public hideFilter = true;
  public channelBinded = false;
  public user: any;
  public keywords = '';
  public selected_date: any = '';
  public calendar_options: FlatpickrOptions = {
    defaultDate: 'today',
    inline: false,
    onChange: (selectedDates, dateStr, instance) => {
      this.selected_date = dateStr;
      console.log(this.selected_date);
      this.refresh();
    },
    altInput: true,
    altFormat: 'F j, Y',
    dateFormat: 'Y-m-d',
    disableMobile: true,
    clickOpens: true
  };

  constructor(public bookingsService: BookingsService, public modalController: ModalController,
              private navController: NavController, public globals: Globals, private events: Events,
              public loadingCtrl: LoadingController, public pusherService: PusherService, public storage: Storage) {
  }


  async ngOnInit() {
    this.storage.get('user').then((res) => {
      this.user = res;
    });
    this.init();

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.refresh();
    });
  }

  async init() {
    this.getDirect(null);
    await this.handleSupplierNotifications();
  }

  public toggleFilter() {
    (this.hideFilter) ? this.hideFilter = false : this.hideFilter = true;
  }

  public getDirect(event) {
    this.bookingsService.getDirect(this.status, this.sort_by, this.keywords, this.selected_date, this.page)
      .subscribe((result: any) => {
        const items = result.bookings;
        this.last_page = items.last_page;
        if (items.data.length <= 0 || this.page > this.last_page) { // if the result we get is nothing or page has past last page
          if (event !== null) {
            event.disabled = true;
          }
        } else {
          if (this.page === 1 && items.data.length <= 0) { // No bookings available
            this.bookings = [];
          } else {
            items.data.forEach((item) => {
              if(parseInt(item.price) > 0 && item.supplier){
                item.price = (item.price / ( 1 + (item.supplier.member_ship_plans[0].charge_percentage/100))).toFixed(2);
              }
              this.bookings.push(item);
            });
            if (event !== null) {
              event.complete();
            }
            this.page = items.current_page + 1;
          }
        }
        this.loaded = false;
      }, (err) => {
        console.log(err);
        this.loaded = false;
      });
  }

  public getDirectWithoutDisabling(event) {
    this.bookingsService.getDirect(this.status, this.sort_by, this.keywords, this.selected_date, this.page)
      .subscribe((result: any) => {
        const items = result.bookings;
        this.last_page = items.last_page;
        this.bookings = [];
        items.data.forEach((item) => {
          this.bookings.push(item);
        });
        if (event !== null) {
          event.complete();
        }
        this.page = items.current_page + 1;
        this.loaded = false;
      }, (err) => {
        console.log(err);
        this.loaded = false;
      });
  }

  public refresh() {
    this.page = 1;
    this.getDirectWithoutDisabling(this.refresher);
  }

  public eraseDate() {
    this.selected_date = '';
    this.refresh();
  }

  async handleSupplierNotifications() {
    let channel = this.pusherService.init();
    if (channel === undefined) {
      channel = this.pusherService.init();
    }
    setInterval(() => {
      if (channel === undefined) {
        channel = this.pusherService.init();
      } else {
        if (!this.channelBinded) {
          channel.bind('Illuminate\\Notifications\\Events\\BroadcastNotificationCreated', (event) => {
            if ( // Update bookings to re-update list
              event.type === 'App\\Notifications\\Supplier\\CustomerOrderedService' ||
              event.type === 'App\\Notifications\\Supplier\\CustomerOrderedImmediateService' ||
              event.type === 'App\\Notifications\\Supplier\\AcceptedBooking' ||
              event.type === 'App\\Notifications\\Supplier\\ConsiderBooking' ||
              event.type === 'App\\Notifications\\Supplier\\RemindFrequentBooking'
            ) {
              this.refresh();
            }
            console.log(event);
          });
          this.channelBinded = true;
        }
      }
    }, 5000);
  }
}
