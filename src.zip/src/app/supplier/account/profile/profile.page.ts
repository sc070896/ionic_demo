import {Component, OnInit, ViewChild} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {OrderService} from '../../../services/general/order.service';
import {ProfileService} from '../../../services/supplier/account/profile.service';
import {NavController,  Events, ModalController, IonRefresher} from '@ionic/angular';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {faLanguage} from '@fortawesome/free-solid-svg-icons';
import {PhotoPage} from '../../../general/photo/photo.page';
import {FlagPage} from '../../../customer/bookings/flag/flag.page';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
})
export class ProfilePage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  faLanguage = faLanguage;
  public username: string;
  public overall_rating: any;
  public supplier: any;
  public assets_url = '';
  public loading = true;
  public showFlag = false;

  constructor(private route: ActivatedRoute, private router: Router, public orderService: OrderService, public events: Events,
              public profileService: ProfileService, private navController: NavController, public globals: Globals,
              public modalController: ModalController, public storage: Storage) {
    this.assets_url = this.globals.assets_bucket_url;
  }

  ngOnInit() {
    this.storage.get('login_type').then((res) => {
      if (res === 'customer') {
        this.showFlag = true;
      }
    });
    this.route.params.subscribe((params) => {
      this.username = params['username'];
      this.getSupplier();
    });

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.getSupplier();
    });
  }

  public convertTime(time) {
    return this.globals.convertTime(time);
  }

  public getSupplier() {
    this.profileService.getSupplierByUsername(this.username).subscribe((result: any) => {
      console.log(result);
      this.supplier = result.data;
      this.loading = false;
      this.getRating();
      this.refresher.complete();
    }, (err) => {
      console.log(err);
      this.loading = false;
    });
  }

  public getRating() {
    this.profileService.getOverallRating(this.supplier.uuid).subscribe((result: any) => {
      console.log(result);
      this.overall_rating = result.overall_rating;
    }, (err) => {
      console.log(err);
    });
  }

  async openFlagModal() {
    const modal = await this.modalController.create({
      component: FlagPage,
      componentProps: <any>{
        suppliers_id: this.supplier.id
      }
    });

    modal.onDidDismiss().then((res) => {
    });

    return await modal.present();
  }

  public goToReviews(username) {
    this.navController.navigateForward('zengiver/reviews/' + username);
  }

  public back() {
    this.navController.back();
  }

}
