import {Component, NgZone, OnInit} from '@angular/core';
import {ModalController, NavController} from '@ionic/angular';
import {MapsAPILoader} from '@agm/core';
import {Globals} from '../../../globals';
import {FormBuilder} from '@angular/forms';
import {CategoriesService} from '../../../services/general/categories.service';
import {AccountService} from '../../../services/supplier/account/account.service';
import {DomSanitizer} from '@angular/platform-browser';
import {Storage} from '@ionic/storage';
import * as reframe from 'reframe.js';

@Component({
  selector: 'app-orientation',
  templateUrl: './orientation.page.html',
  styleUrls: ['./orientation.page.scss'],
})
export class OrientationPage implements OnInit {
  public user: any;
  public orientation: any = {};
  public YT: any;
  public video: any;
  public player: any;
  public reframed: Boolean = false;
  public loading_user: Boolean = true;

  constructor(public navController: NavController, private mapsAPILoader: MapsAPILoader, private ngZone: NgZone, public globals: Globals,
              private formBuilder: FormBuilder, public categoriesService: CategoriesService, public modalController: ModalController,
              public storage: Storage, public accountService: AccountService, private domSanitizer: DomSanitizer) {}

  init() {
    const tag = document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    const firstScriptTag = document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
  }

  ngOnInit() {
    this.storage.get('user').then((res) => {
      this.user = res;
      this.getOrientation();
    });
  }

  getOrientation() {
    this.accountService.getOrientation(1)
      .subscribe((res: any) => {
        this.init();

        this.orientation = res.data;
        this.video = this.orientation.video_id;  // video id
        this.loading_user = false;

        window['onYouTubeIframeAPIReady'] = (e) => {
          this.YT = window['YT'];
          this.reframed = false;
          this.player = new window['YT'].Player('player', {
            videoId: this.video,
            events: {
              'onStateChange': this.onPlayerStateChange.bind(this),
              'onError': this.onPlayerError.bind(this),
              'onReady': (e) => {
                if (!this.reframed) {
                  this.reframed = true;
                  reframe(e.target.a);
                }
              }
            },
            playerVars: {
              modestbranding: 1,
              disablekb: 1,
              rel: 0
            }
          });
        };
      }, (err) => {
      });
  }

  public onPlayerStateChange(event) {
    switch (event.data) {
      case window['YT'].PlayerState.PLAYING:
        if (this.cleanTime() === 0) {
          console.log('started ' + this.cleanTime());
        } else {
          console.log('playing ' + this.cleanTime());
        }
        break;
      case window['YT'].PlayerState.PAUSED:
        if (this.player.getDuration() - this.player.getCurrentTime() !== 0) {
          console.log('paused' + ' @ ' + this.cleanTime());
        }
        break;
      case window['YT'].PlayerState.ENDED:
        console.log('ended ');
        this.accountService.updateOrientation(this.user.id)
          .subscribe((res: any) => {
            this.globals.presentTopToast(res.msg);
            this.storage.set('user', res.data);
            this.user = res.data;
          }, (err) => {
            this.globals.presentToast('Something went wrong. Please try again.');
          });
        break;
    }
  }

  // utility
  cleanTime() {
    return Math.round(this.player.getCurrentTime());
  }

  onPlayerError(event) {
    switch (event.data) {
      case 2:
        console.log('' + this.video);
        break;
      case 100:
        break;
      case 101 || 150:
        break;
    }
  }

  public sanitize(vid: string) {
    return this.domSanitizer.bypassSecurityTrustResourceUrl(vid);
  }

  public back() {
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }
}
