import {Component, OnInit, ViewChild} from '@angular/core';
import { ModalController, NavController,  Events, IonRefresher, IonInfiniteScroll} from '@ionic/angular';
import {Globals} from '../../../globals';
import {CategoriesService} from '../../../services/general/categories.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {AccountService} from '../../../services/supplier/account/account.service';
import {Storage} from '@ionic/storage';

@Component({
  selector: 'app-notifications',
  templateUrl: './notifications.page.html',
  styleUrls: ['./notifications.page.scss'],
})
export class NotificationsPage implements OnInit {

  @ViewChild('inscroll') infinite_scroll: IonInfiniteScroll;
  @ViewChild('minscroll') minfinite_scroll: IonInfiniteScroll;
  @ViewChild('refresher') refresher: IonRefresher;
  @ViewChild('mrefresher') mrefresher: IonRefresher;

  public user: any;
  notifications: any = [];
  public page = 1;
  public last_page = 4;
  message_notifications: any = [];
  public mpage = 1;
  public mlast_page = 4;
  loading = true;
  show_messages = false;

  constructor(public navController: NavController, public globals: Globals, public categoriesService: CategoriesService,
              public modalController: ModalController, public registrationService: RegistrationService, public loginService: LoginService,
              public accountService: AccountService, private storage: Storage, public events: Events) {
  }

  ngOnInit() {
    this.storage.get('user').then((res) => {
      this.user = res;
      this.getNotifications(null);
      this.getMessageNotifications(null);
    });

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.refresh();
      this.mrefresh();
    });
  }

  public getNotifications(event) {
    this.accountService.getNotifications(this.user.id, this.page).subscribe((result: any) => {
      const items = result;
      this.last_page = items.last_page;
      if (items.data.length <= 0 || this.page > this.last_page) { // if the result we get is nothing or page has past last page
        if (event !== null) {
          event.disabled = true;
        }
      } else {
        if (this.page === 1 && items.data.length <= 0) { // No bookings available
          this.notifications = [];
        } else {
          items.data.forEach((item) => {
            item.data = JSON.parse(item.data);
            this.notifications.push(item);
          });
          if (event !== null) {
            event.complete();
          }
          this.page = items.current_page + 1;
        }
      }
      this.loading = false;
    }, (err) => {
      console.log(err);
      this.loading = false;
    });
  }

  public getNotificationsWithoutDisabling(event) {
    this.accountService.getNotifications(this.user.id, this.page).subscribe((result: any) => {
      const items = result;
      this.last_page = items.last_page;
      this.notifications = [];
      items.data.forEach((item) => {
        item.data = JSON.parse(item.data);
        this.notifications.push(item);
      });
      if (event !== null) {
        event.complete();
      }
      this.page = items.current_page + 1;
      this.refresher.complete();
    }, (err) => {
      console.log(err);
    });
  }

  public refresh() {
    this.page = 1;
    this.getNotificationsWithoutDisabling(this.refresher);
  }

  public getMessageNotifications(event) {
    this.accountService.getMessageNotifications(this.user.id, this.mpage).subscribe((result: any) => {
      const items = result;
      this.mlast_page = items.last_page;
      if (items.data.length <= 0 || this.mpage > this.mlast_page) { // if the result we get is nothing or page has past last page
        if (event !== null) {
          event.disabled = true;
        }
      } else {
        if (this.mpage === 1 && items.data.length <= 0) { // No bookings available
          this.message_notifications = [];
        } else {
          items.data.forEach((item) => {
            this.message_notifications.push(item);
          });
          if (event !== null) {
            event.complete();
          }
          this.mpage = items.current_page + 1;
        }
      }
    }, (err) => {
      console.log(err);
    });
  }

  public getMessageNotificationsWithoutDisabling(event) {
    this.accountService.getMessageNotifications(this.user.id, this.mpage).subscribe((result: any) => {
      const items = result;
      this.mlast_page = items.last_page;
      this.message_notifications = [];
      items.data.forEach((item) => {
        this.message_notifications.push(item);
      });
      if (event !== null) {
        event.complete();
      }
      this.mpage = items.current_page + 1;
      this.refresher.complete();
    }, (err) => {
      console.log(err);
    });
  }

  public mrefresh() {
    this.mpage = 1;
    this.getMessageNotificationsWithoutDisabling(this.mrefresher);
  }

  public formatDateLong(d) {
    return this.globals.formatDateLong(d);
  }

  public show(page) {
    if (page === 'messages') {
      this.show_messages = true;
    } else {
      this.show_messages = false;
    }
  }

  public back() {
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }

}
