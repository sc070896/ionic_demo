import {Component, OnInit, ViewChild} from '@angular/core';
import {Globals} from '../../../globals';
import {CategoriesService} from '../../../services/general/categories.service';
import {AccountService} from '../../../services/customer/account/account.service';
import {Storage} from '@ionic/storage';
import {AlertController, ModalController, NavController,  Events, IonRefresher} from '@ionic/angular';
import {LoginService} from '../../../services/supplier/auth/login.service';

@Component({
  selector: 'app-background-check',
  templateUrl: './background-check.page.html',
  styleUrls: ['./background-check.page.scss'],
})
export class BackgroundCheckPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public user: any;
  public msg = '';

  constructor(public navController: NavController, public globals: Globals, public categoriesService: CategoriesService,
              public modalController: ModalController, public accountService: AccountService, public loginService: LoginService,
              private storage: Storage, public alertController: AlertController, public events: Events) {
  }

  ngOnInit() {
    this.storage.get('user').then((res) => {
      this.user = res;
      if (this.user.certn_background_check === null) {
        this.msg = 'After your interview with our zenGOT representative we will submit ' +
          'a background check under your name. Check back to this page to view the results of your background check.';
      } else {
        this.msg = 'Here are the results of your background check. Click the link below to see the report details.';
      }
    });
    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.getUser();
    });
  }

  public getUser() {
    this.loginService.user().subscribe((r: any) => {
      console.log(r);
      this.user = r;
      this.storage.set('user', r).then((loginRes) => {
      });
      this.refresher.complete();
    }, (err) => {
      console.log(err);
      this.refresher.complete();
    });
  }

  public goInterview(uuid) {
    this.navController.navigateForward('zengiver/interviews/' + uuid);
  }

  public back() {
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }
}
