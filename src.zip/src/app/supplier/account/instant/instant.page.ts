import {Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {NavController,  Events, IonRefresher} from '@ionic/angular';
import {FormBuilder} from '@angular/forms';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {AccountService} from '../../../services/supplier/account/account.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {OnEnter} from '../../../on-enter';
import {Subscription} from 'rxjs/Subscription';
import {NavigationEnd, Router} from '@angular/router';

@Component({
  selector: 'app-instant',
  templateUrl: './instant.page.html',
  styleUrls: ['./instant.page.scss'],
})
export class InstantPage implements OnInit, OnEnter, OnDestroy {
  @ViewChild('refresher') refresher: IonRefresher;

  public able_immediate_services: any;
  public user: any;
  public states: any;
  public selected_state: any;
  public selected_cities = [];
  public loading = true;
  private subscription: Subscription;

  constructor(private navController: NavController, private formBuilder: FormBuilder, public accountService: AccountService,
              public loginService: LoginService, public globals: Globals, private storage: Storage, private router: Router,
              public registrationService: RegistrationService, public events: Events) {
  }

  async ngOnInit() {
    await this.onEnter();

    this.subscription = this.router.events.subscribe((event: any) => {
      console.log(event.url);
      if (event instanceof NavigationEnd && event.url === '/tabs/(instant:instant)') {
        this.onEnter();
      }
    });
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.onEnter();
    });
  }

  public async onEnter(): Promise<void> {
    this.storage.get('user').then((user: any) => {
      console.log(user);
      this.selected_state = user.states_id;
      this.able_immediate_services = user.able_immediate_services;
      user.immediate_areas.forEach((item) => {
        this.selected_cities.push(item.id);
      });
      this.user = user;
      this.getStates();
      this.refresher.complete();
    });
  }

  public ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  public back() {
    this.ngOnDestroy();
    this.navController.navigateRoot('zengiver/dashboard/tabs/(about:about)');
  }

  getStates() {
    this.registrationService.getStates().subscribe((r: any) => {
      console.log(r);
      this.states = r;
      this.loading = false;
    }, (err) => {
      console.error(err);
      this.loading = false;
    });
  }

  toggleCity(id) {
    const i = this.selected_cities.findIndex(city => city === id);
    if (i > -1) { // remove if found
      this.selected_cities.splice(i, 1);
    } else { // add if not
      this.selected_cities.push(id);
    }
  }

  update() {
    this.globals.presentLoading('Updating...').then((result) => {
      this.accountService.instantServiceAreas(this.user.id, this.selected_cities, this.selected_state,
        this.able_immediate_services).subscribe((r: any) => {
        this.storage.set('user', r.data).then((loginRes) => {
        });
        this.globals.presentTopToast(r.msg);
        this.globals.loading.dismiss();
      }, (err) => {
        console.error(err);
        const msg = err.error.msg;
        this.globals.presentTopToast(msg);
        this.globals.loading.dismiss();
      });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }
}
