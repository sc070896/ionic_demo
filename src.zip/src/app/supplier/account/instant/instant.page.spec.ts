import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InstantPage } from './instant.page';

describe('InstantPage', () => {
  let component: InstantPage;
  let fixture: ComponentFixture<InstantPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InstantPage ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InstantPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
