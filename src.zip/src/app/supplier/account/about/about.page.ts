import {Component, OnInit, ViewChild} from '@angular/core';
import {AlertController, NavController, Events, IonRefresher} from '@ionic/angular';
import {FormBuilder} from '@angular/forms';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {PusherService} from '../../../services/supplier/auth/pusher.service';

@Component({
  selector: 'app-about',
  templateUrl: 'about.page.html',
  styleUrls: ['about.page.scss']
})
export class AboutPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public user: any;
  public loading_user = true;

  constructor(private navController: NavController, private formBuilder: FormBuilder, public pusherService: PusherService,
              public loginService: LoginService, public globals: Globals, private storage: Storage, public events: Events,
              public alertController: AlertController) {
  }

  ngOnInit() {
    this.getUser();

    // Offline event
    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    // Online event
    this.events.subscribe('network:online', () => {
      this.getUser();
    });
  }

  public getUser() {
    this.loginService.user().subscribe((r: any) => {
      console.log(r);
      this.user = r;
      this.storage.set('user', r).then((loginRes) => {});
      this.loading_user = false;
      this.refresher.complete();
    }, (err) => {
      console.log(err);
      this.loading_user = false;
    });
  }

  public goInterview(uuid) {
    this.navController.navigateForward('zengiver/interviews/' + uuid);
  }

  public go(route: string) {
    this.navController.navigateForward(route);
  }

  async logout() {
    const alert = await this.alertController.create({
      header: 'Logout?',
      message: '',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Logging out...').then((res) => {
              this.loginService.logout().subscribe((r: any) => {
                  console.log(r);
                  this.pusherService.unsubscribe(); // unsubscribe user from getting notifications
                  this.globals.loading.dismiss();
                  this.storage.remove('access_token').then((stRes) => {
                      this.storage.remove('user');
                      this.navController.navigateRoot('zengiver/login');
                    },
                    (err) => {
                      console.log(err);
                      let errMsg = err.error.msg;
                      if (errMsg === undefined) {
                        errMsg = 'Failed to logout';
                      }
                      this.globals.presentAlert(errMsg);
                    });
                },
                (err) => {
                  console.log(err);
                  let errMsg = err.error.msg;
                  this.globals.loading.dismiss();
                  if (errMsg === undefined) {
                    errMsg = 'Failed to logout';
                  }
                  this.globals.presentAlert(errMsg);
                }, () => {
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              console.log(err);
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }
}
