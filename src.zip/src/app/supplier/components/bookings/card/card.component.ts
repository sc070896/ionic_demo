import {Component, OnInit, Input} from '@angular/core';
import {DetailsPage} from '../../../bookings/details/details.page';
import {BookingsService} from '../../../../services/supplier/bookings/bookings.service';
import {LoadingController, ModalController, NavController, Platform, ToastController} from '@ionic/angular';
import {Globals} from '../../../../globals';
import {PusherService} from '../../../../services/supplier/auth/pusher.service';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {
  @Input() b: any;
  @Input() user: any;
  public channelBinded = false;

  constructor(public bookingsService: BookingsService, public modalController: ModalController,
              private navController: NavController, public globals: Globals,
              public loadingCtrl: LoadingController,
              public toastCtrl: ToastController,
              public pusherService: PusherService) {
  }

  async ngOnInit() {
    await this.handleSupplierNotifications();
  }

  async goDetails(booking: any) {
    const modal = await this.modalController.create({
      component: DetailsPage,
      componentProps: <any>{b: booking, user: this.user}
    });

    modal.onDidDismiss().then((res: any) => {
      this.b = (res.data.b); 
    });

    return await modal.present();
  }

  async goChat(booking: any) {
    this.navController.navigateForward('zengiver/bookings/chat/' + booking.uuid_booking);
  }

  public initials(name: string) {
    return this.globals.initials(name);
  }

  public formatHours(h: number) {
    return this.globals.formatHours(h);
  }

  async handleSupplierNotifications() {
    let channel = this.pusherService.init();
    if (channel === undefined) {
      channel = this.pusherService.init();
    }
    setInterval(() => {
      if (channel === undefined) {
        channel = this.pusherService.init();
      } else {
        if (!this.channelBinded) {
          channel.bind('Illuminate\\Notifications\\Events\\BroadcastNotificationCreated', (event) => {
            if (event.booking_uuid === this.b.uuid_booking) {
              if (
                event.type === 'App\\Notifications\\Supplier\\BookingExpired' ||
                event.type === 'App\\Notifications\\Supplier\\CustomerCancelledBooking' ||
                event.type === 'App\\Notifications\\Supplier\\NoShow' ||
                event.type === 'App\\Notifications\\Supplier\\CustomerCancelledUrgentBooking'
              ) {
                this.b.status = event.status;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\CustomerUpdatedServiceDetails'
              ) {
                this.b.service_details = event.service_details;
              }

              if (event.type === 'App\\Notifications\\Supplier\\Bookings\\CustomerUpdatedServiceLocation') {
                this.b.customer_location = event.customer_location;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\SupplierNewChatMessage'
              ) {
                this.b.conversation.supplier_unread_messages = event.messages_count;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\CustomerRescheduled' ||
                event.type === 'App\\Notifications\\Supplier\\CustomerRescheduledInstant' ||
                event.type === 'App\\Notifications\\Supplier\\CustomerExtendedBooking' ||
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerAcceptedReschedule'
              ) {
                this.b.time = event.request_time;
                this.b.date = event.date;
                this.b.duration = event.duration;
                this.b.reschedule_request = null;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\CustomerConfirmedBooking'
              ) {
                this.b.time = event.request_time;
                this.b.date = event.date;
                this.b.status = event.status;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\FlexibleBookings\\CustomerAcceptedFlexible' ||
                event.type === 'App\\Notifications\\Supplier\\FlexibleBookings\\CustomerDeclinedFlexible'
              ) {
                this.b = event.booking;
                this.b.price = (this.b.price / (1+ this.b.membership_plans[0].charge_percentage/100)).toFixed(2);
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerCreatedReschedule'
              ) {
                this.b.reschedule_request = event.reschedule_request;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerDeclinedReschedule' ||
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerCancelledReschedule'
              ) {
                this.b.reschedule_request = null;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerCreatedRecurringReschedule'
              ) {
                this.b.reschedule_recurring_request = event.reschedule_recurring_request;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerDeclinedRecurringReschedule' ||
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerCancelledRecurringReschedule' ||
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerAcceptedRecurringReschedule'
              ) {
                this.b.reschedule_recurring_request = null;
              }
            }
            console.log(event);
          });
          this.channelBinded = true;
        }
      }
    }, 5000);
  }
  public getBookingWithSupplierPrice(booking){
    if(parseInt(booking.price) > 0 && booking.supplier){
      booking.price = (booking.price / ( 1 + (booking.supplier.member_ship_plans[0].charge_percentage/100))).toFixed(2);
    } else {
      booking.price = (booking.price / ( 1 + (booking.membership_plans.charge_percentage/100))).toFixed(2);
    }
    return booking;
  }
}
