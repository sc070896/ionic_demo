import { Component, OnInit } from '@angular/core';
import {ModalController, NavController} from '@ionic/angular';
import {Globals} from '../../../globals';

@Component({
  selector: 'app-earning-details',
  templateUrl: './earning-details.page.html',
  styleUrls: ['./earning-details.page.scss'],
})
export class EarningDetailsPage implements OnInit {
  public b: any;
  public charges: any;

  constructor(public navController: NavController, private modalController: ModalController, public globals: Globals) { }

  ngOnInit() {
    this.charges = this.b.earnings;
  }

  formatCost(num: any) {
    return Math.abs(num).toFixed(2);
  }

  public back() {
    this.modalController.dismiss({});
  }
}
