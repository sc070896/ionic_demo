import {Component, OnInit, ViewChild} from '@angular/core';
import {AlertController, ModalController, IonTextarea} from '@ionic/angular';
import {Globals} from '../../../globals';
import {ProfileService} from '../../../services/supplier/account/profile.service';

@Component({
  selector: 'app-edit-services',
  templateUrl: './edit-services.page.html',
  styleUrls: ['./edit-services.page.scss'],
})

// This is a component that adds/updates individual services
export class EditServicesPage implements OnInit {
  @ViewChild('#textarea') txtArea: IonTextarea;
  public data: any; // The data of the category includes the subcategories and service elements
  public experiences: any; // List out the experiences
  public selected: any; // Object we're building to send over to the api to process
  public service_details: any; // The data of the service we're editing
  public current_services: any; // Current services of the supplier
  public selected_service: any; // Service we are editing
  public selected_category: any; // contains the experience under that category
  public loading = true;
  public isUpdate = true;
  public rateOver250 = false;
  public first_platform_cut = 0.25; // TODO GET THROUGH DB
  public subsequent_platform_cut = 0.20; // TODO GET THROUGH DB

  constructor(private modalController: ModalController, public globals: Globals,
              public profileService: ProfileService) {

  }

  ngOnInit() {
    if (this.service_details !== undefined && this.service_details !== null) {
      this.selected_service = this.service_details.data;
      if(parseInt(this.selected_service.price) > 0){
        this.selected_service.price = (this.selected_service.price / ( 1 + (this.selected_service.membershipPlans[0].charge_percentage/100))).toFixed(2);
      }
      this.selected_category = this.service_details.cs;
      this.selected = {
        id: this.data.id,
        exp: this.selected_category.exp,
        description: this.selected_service.description,
        services: this.data.services,
        elements: this.data.service_elements
      };

      // update service description
      this.txtArea = this.selected.description;

      // update experience
      this.upExp(this.selected_category.exp);

      // select the current services and update their rates (syncing services)
      this.current_services.forEach((service) => {
        this.data.services.forEach((ds) => {
          if(parseInt(ds.default_price) > 0){
            ds.default_price = (ds.default_price / ( 1 + (service.membershipPlans[0].charge_percentage/100))).toFixed(2);
          }
        });
        if(parseInt(service.price) > 0){
          service.price = (service.price / ( 1 + (service.membershipPlans[0].charge_percentage/100))).toFixed(2);
        }
        const found = this.data.services.findIndex(s => s.id === service.subcategory_id);
        if (found > -1) {
          this.data.services[found]['selected'] = true;
          this.data.services[found]['default_price'] = service.price;
        }
      });
      this.selected.services[0].selected = true;
      // sync service elements
      this.selectedServiceElement();
      this.isUpdate = true;
    } else {
      this.selected = {
        id: this.data.id,
        exp: 0,
        description: '',
        services: this.data.services,
        elements: this.data.service_elements
      };
      this.selected.services[0].selected = true;
      this.isUpdate = false;
    }
    this.loading = false;
  }

  selectedServiceElement() {
    this.selected.elements.forEach((item) => {
      const found = this.selected_service.service_elements.findIndex(s => s.service_elements_id === item.id);
      if (found > -1) {
        item['selected'] = true;
      } else {
        item['selected'] = false;
      }
    });
  }

  upExp(id) {
    this.selected.exp = id;
  }

  upDesc(event: any) { // without type info
    this.selected.description = event.target.value;
  }

  upServiceToggle(key, event: any) {
    // Get the current value (toggle - on/off) of the selected service
    const currentVal = this.selected.services[key].selected;
    if (currentVal === undefined || currentVal === false) {
      this.selected.services[key].selected = true;
    } else {
      this.selected.services[key].selected = false;
    }
  }

  upRate(key, event: any) {
    const rate = event.target.value;
    this.selected.services[key].default_price = rate;
    if (rate > 250) {
      this.globals.presentAlert('Hourly rate cannot exceed past $250/hr');
      return;
    }
    if (rate < 20) {
      this.globals.presentAlert('Although you are free to offer a lower hourly rate if you wish, ' +
        'we recommend that you set your hourly rate at $20 per hour or more');
    }
  }

  dismissAdd() {
    // validation before submitting
    if (this.selected.exp === 0) { // if an experience was selected
      this.globals.presentAlert('Select your level of experience for providing ' + this.data.title);
      return;
    }

    // Find if an hourly rate is over $250
    const ratesResult = this.selected.services.findIndex(s => parseFloat(s.default_price) > 250);
    if (ratesResult > -1) {
      this.globals.presentAlert('Your hourly rates cannot exceed over $250');
      return;
    }

    const selected = [this.selected]; // place into array for processing
    // update service
    this.globals.presentLoading('Loading...').then((loadingRes) => {
      if (this.isUpdate) { // update the service
        this.profileService.updateServices(this.selected_service.id, selected)
          .subscribe((res: any) => {
            this.modalController.dismiss({ // Send back user data to store into storage to update the list of services
              data: res.supplier,
              action: 'update'
            });
            this.globals.presentToast(res.msg);
            this.globals.loading.dismiss();
          }, (err) => {
            const msg = err.error.msg;
            this.globals.presentToast(msg);
            this.globals.loading.dismiss();
          });
      } else { // add the new service
        this.profileService.storeServices(selected)
          .subscribe((res: any) => {
            this.modalController.dismiss({ // Send back user data to store into storage to update the list of services
              data: res.supplier,
              action: 'create'
            });
            this.globals.presentToast(res.msg);
            this.globals.loading.dismiss();
          }, (err) => {
            const msg = err.error.msg;
            this.globals.presentToast(msg);
            this.globals.loading.dismiss();
          });
      }
    });
  }

  calculateFirstRate(num: number) {
    return (num * (1 - this.first_platform_cut)).toFixed(2);
  }

  calculateSecondRate(num: number) {
    return (num * (1 - this.subsequent_platform_cut)).toFixed(2);
  }

  back() {
    // validation before submitting
    this.modalController.dismiss({
      action: ''
    });
  }
}
