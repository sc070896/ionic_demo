import {Component, OnInit, NgModule} from '@angular/core';
import {ModalController, NavController} from '@ionic/angular';
import {Globals} from '../../../globals';

@Component({
  selector: 'service-card',
  templateUrl: './service-card.component.html',
  styleUrls: ['./service-card.component.scss']
})

// Component part of registration - similar to edit-services (make sure they're the similar in functionality)
// This is for sending altogether with the form
export class ServiceCardComponent implements OnInit {
  public data: any;
  public experiences: any;
  public selected: any;
  public first_platform_cut = 0.25; // TODO GET THROUGH DB
  public subsequent_platform_cut = 0.20; // TODO GET THROUGH DB
  constructor(private modalController: ModalController, public globals: Globals) {

  }

  ngOnInit() {
    this.selected = {
      id: this.data.id,
      exp: 0,
      description: '',
      services: this.data.services,
      elements: this.data.service_elements
    };

    // First service is the general - so it automatically selected
    this.selected.services[0].selected = true;
  }

  upExp(id) {
    this.selected.exp = id;
    console.log(this.selected.exp);
  }

  upDesc(event: any) { // without type info
    this.selected.description = event.target.value;
    console.log(this.selected.description);
  }

  upServiceToggle(key, event: any) {
    // Get the current value (toggle - on/off) of the selected service
    const currentVal = this.selected.services[key].selected;
    console.log(currentVal);
    if (currentVal === undefined || currentVal === false) {
      this.selected.services[key].selected = true;
    } else {
      this.selected.services[key].selected = false;
    }
    console.log(this.selected.services[key].selected);
  }

  upRate(key, event: any) {
    const rate = event.target.value;
    this.selected.services[key].default_price = rate;
    if (rate > 250) {
      this.globals.presentAlert('Hourly rate cannot exceed past $250/hr');
      return;
    }
    if (rate < 20) {
      this.globals.presentAlert('Although you are free to offer a lower hourly rate if you wish, ' +
        'we recommend that you set your hourly rate at $20 per hour or more');
    }
  }

  upServiceElement(key, event: any) {
    console.log(event.target.value);
    if (event.target.value === 'true') {
      this.selected.elements[key].selected = true;
    } else {
      this.selected.elements[key].selected = false;
    }
  }

  dismissDelete() {
    // validation before submitting
    console.log(this.selected);
    this.modalController.dismiss({
      data: this.selected,
      action: 'delete'
    });
  }

  dismissAdd() {
    // validation before submitting
    if (this.selected.exp === 0) {
      this.globals.presentAlert('Select your level of experience for providing ' + this.data.title);
      return;
    }

    // Find if an hourly rate is over $250
    const ratesResult = this.selected.services.findIndex(s => parseFloat(s.default_price) > 250);
    if (ratesResult > -1) {
      this.globals.presentAlert('Your hourly rates cannot exceed over $250');
      return;
    }

    this.modalController.dismiss({
      data: this.selected,
      action: 'create'
    });
  }

  back() {
    // validation before submitting
    console.log(this.selected);
    this.modalController.dismiss({
      action: ''
    });
  }

  calculateFirstRate(num: number) {
    return (num * (1 - this.first_platform_cut)).toFixed(2);
  }

  calculateSecondRate(num: number) {
    return (num * (1 - this.subsequent_platform_cut)).toFixed(2);
  }
}
