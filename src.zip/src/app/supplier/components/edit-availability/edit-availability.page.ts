import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalController, IonSelectOption} from '@ionic/angular';
import {Globals} from '../../../globals';
import {ProfileService} from '../../../services/supplier/account/profile.service';

@Component({
  selector: 'app-edit-availability',
  templateUrl: './edit-availability.page.html',
  styleUrls: ['./edit-availability.page.scss'],
})
export class EditAvailabilityPage implements OnInit {
  @ViewChild('startSelect') startSelect: IonSelectOption;
  @ViewChild('endSelect') endSelect: IonSelectOption;

  title: any;
  data: any;
  day = 'Monday';
  start = '09:00';
  end = '17:00';
  days: any;
  times: any;

  constructor(private modalController: ModalController, public globals: Globals,
              public profileService: ProfileService) {
  }

  ngOnInit() {
    this.days = this.globals.days;
    console.log(this.globals.days);
    this.times = this.globals.times;
    if (!(Object.keys(this.data.details).length === 0 && this.data.details.constructor === Object)) {
      this.day = this.data.details.day;
      this.start = this.removeEnds(this.data.details.start);
      this.end = this.removeEnds(this.data.details.end);
    }
  }

  dismissAdd() {
    // validate
    const result = this.globals.compareTime(this.start, this.end);
    if (!result) {
      this.globals.presentAlert('End time must be after your start time');
      return;
    }

    // update service
    this.globals.presentLoading('Loading...').then((loadingRes) => {
      if (this.data.isUpdate) { // update the service
        this.profileService.updateAvailability(this.data.id, this.data.suppliers_id, this.day, this.start, this.end)
          .subscribe((res: any) => {
            this.modalController.dismiss({ // Send back user data to store into storage to update the list of services
              action: 'update'
            });
            this.globals.presentToast(res.success);
            this.globals.loading.dismiss();
          }, (err) => {
            const msg = err.error.error;
            this.globals.presentAlert(msg);
            this.globals.loading.dismiss();
          });
      } else { // add the new service
        this.profileService.storeAvailability(this.data.suppliers_id, this.day, this.start, this.end)
          .subscribe((res: any) => {
            this.modalController.dismiss({ // Send back user data to store into storage to update the list of services
              action: 'create'
            });
            this.globals.presentToast(res.success);
            this.globals.loading.dismiss();
          }, (err) => {
            const msg = err.error.error;
            this.globals.presentAlert(msg);
            this.globals.loading.dismiss();
          });
      }
    });
  }

  compareTime() {
    const result = this.globals.compareTime(this.start, this.end);
    if (!result) {
      this.globals.presentAlert('End time must be after your start time');
    }
  }

  public removeEnds(time) {
    return time.substring(0, 5);
  }

  back() {
    // validation before submitting
    this.modalController.dismiss({
      action: ''
    });
  }
}
