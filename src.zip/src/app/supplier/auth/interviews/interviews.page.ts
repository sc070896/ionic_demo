import {Component, OnInit, ViewChild} from '@angular/core';
import {Router, ActivatedRoute, ParamMap} from '@angular/router';
import {Globals} from '../../../globals';
import {RegistrationService} from '../../../services/general/registration.service';
import {FlatpickrOptions} from 'ng2-flatpickr';
import {AlertController, NavController, IonRefresher, Events} from '@ionic/angular';
import {Storage} from '@ionic/storage';

@Component({
  selector: 'app-interviews',
  templateUrl: './interviews.page.html',
  styleUrls: ['./interviews.page.scss'],
})
export class InterviewsPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  public today: any;
  public max_date: any;
  public month_long_names: any;
  public month_short_names: any;
  public selected_date: any;
  public s_date: any;
  public user: any;
  public current_page = 1;
  public interviews = [];
  public uuid: string;
  public loading = false;
  public loading_user = true;
  public status: any;
  public description: any;
  public scheduled_call: any;
  public logged_in = false;
  public calendar_options: FlatpickrOptions = {
    defaultDate: 'today',
    inline: true,
    onChange: (selectedDates, dateStr, instance) => {
      console.log(selectedDates);
      console.log(dateStr);
      console.log(instance);
      this.selected_date = dateStr;
      this.getInterviews();
    },
    altInput: true,
    altFormat: 'F j, Y',
    dateFormat: 'm/d/Y',
    minDate: 'today',
  };

  constructor(private route: ActivatedRoute, private router: Router, public globals: Globals, private navController: NavController,
              public registrationService: RegistrationService, private alertController: AlertController, public storage: Storage,
              public events: Events) {
    this.month_long_names = this.globals.month_long_names;
    this.month_short_names = this.globals.month_short_names;
  }

  // http://localhost:8100/zengiver/interviews/2a1e11cc-30b0-48ff-bb37-49e89113a6f8
  ngOnInit() {
    this.storage.get('login_type').then((res) => {
      this.storage.get('access_token').then((loggedRes) => {
        if (loggedRes !== null) { // if logged in to either show the login prompts/buttons or not
          if (res === 'supplier') {
            this.logged_in = true;
          } else {
            this.logged_in = false;
          }
        } else {
          this.logged_in = false;
        }
      });
    });
    this.route.params.subscribe((params) => {
      this.uuid = params['uuid'];
      this.getUser(params['uuid']);
    });
    this.getToday();

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.getUser(this.uuid);
    });
  }

  public back() {
    this.navController.back();
  }

  public getUser(uuid) {
    this.registrationService.getUserByUuid(uuid).subscribe((r: any) => {
      console.log(r);
      this.user = r.data;
      this.getInterviewStatus();
    }, (err) => {
      console.log(err);
      this.loading_user = false;
    });
  }

  private getInterviewStatus() {
    this.registrationService.getInterviewStatus(this.user.id).subscribe((r: any) => {
      this.status = r.status;
      console.log(this.status);
      if (r.status === '1') {
        this.scheduled_call = r.call;
        this.description = r.description;
      }
      this.refresher.complete();
      this.loading_user = false;
    }, (err) => {
      this.refresher.complete();
      this.loading_user = false;
    });
  }

  private getToday() {
    const d = new Date();
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2) {
      month = '0' + month;
    }
    if (day.length < 2) {
      day = '0' + day;
    }

    this.max_date = year + 10;
    this.today = [year, month, day].join('-');
    this.selected_date = [year, month, day].join('-');
  }

  getInterviews() {
    this.loading = true;
    console.log('loading interviews');
    this.registrationService.getInterviews(this.selected_date, this.current_page).subscribe((r: any) => {
      this.interviews = r.data;
      this.loading = false;
    }, (err) => {
      console.log(err);
      this.loading = false;
    });
  }

  formatDate(d) {
    const options = {year: 'numeric', month: 'long', day: 'numeric'};
    const date = new Date(d + ' UTC');
    return date.toLocaleDateString('en-US', options); // September 9 2009
  }

  formatTime(d) {
    const options = {weekday: 'long', hour: 'numeric', minute: 'numeric', hour12: true, timeZoneName: 'short'};
    const date = new Date(d + ' UTC');
    return date.toLocaleDateString('en-US', options); // "Wed Jun 29 2011 09:52:48 GMT-0700 (PDT)"
  }

  async cancelInterview(id) {
    const alert = await this.alertController.create({
      header: 'Confirm',
      message: 'Do you want to cancel this interview?',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Cancelling...').then((result) => {
              this.registrationService.cancelInterview(id, this.user.id).subscribe((r: any) => {
                this.globals.presentToast(r.success);
                this.loading_user = true;
                this.globals.loading.dismiss();
                this.getInterviewStatus();
              }, (err) => {
                this.globals.presentToast('Something went wrong. Please try again');
                this.globals.loading.dismiss();
              });
            }, (err) => {
              this.globals.presentToast('Something went wrong. Please try again');
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });

    await alert.present();
  }

  async selectInterview(id) {
    const alert = await this.alertController.create({
      header: 'Confirm',
      message: 'Do you want to select this interview slot?',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Registering...').then((result) => {
              this.registrationService.registerInterview(id, this.user.id).subscribe((r: any) => {
                this.globals.presentToast(r.success);
                this.loading_user = true;
                this.globals.loading.dismiss();
                this.getInterviewStatus();
              }, (err) => {
                this.globals.presentToast('Something went wrong. Please try again');
                this.globals.loading.dismiss();
              });
            }, (err) => {
              this.globals.presentToast('Something went wrong. Please try again');
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });

    await alert.present();
  }

  public login() {
    this.navController.navigateRoot('zengiver/login');
  }
}
