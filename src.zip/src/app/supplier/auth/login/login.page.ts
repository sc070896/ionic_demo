import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {AlertController, LoadingController, NavController} from '@ionic/angular';
import {LoginService} from '../../../services/supplier/auth/login.service';
import {Globals} from '../../../globals';
import {Storage} from '@ionic/storage';
import {OneSignal} from '@ionic-native/onesignal/ngx';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  credentialsForm: FormGroup;

  constructor(private navController: NavController, private formBuilder: FormBuilder, private oneSignal: OneSignal,
              public loginService: LoginService, public globals: Globals, public storage: Storage) {
    this.credentialsForm = this.formBuilder.group({
      email: ['', Validators.compose([
        Validators.email,
        Validators.required
      ])],
      password: ['', Validators.compose([
        Validators.min(6),
        Validators.required
      ])]
    });
  }

  public goToRegister() {
    this.navController.navigateForward('zengiver/how-it-works').then((res) => {
      console.log(res);
    });
  }

  public goToCustomerSignIn() {
    this.navController.navigateForward('customer/login');
  }

  public login() {
    const email = this.credentialsForm.controls['email'].value;
    const password = this.credentialsForm.controls['password'].value;

    Object.keys(this.credentialsForm.controls).forEach(field => {
      const control = this.credentialsForm.get(field);
      control.markAsTouched({onlySelf: true});
    });

    this.globals.presentLoading('Logging in...').then((res) => {
      this.loginService.login(email, password).subscribe((r: any) => {
          this.storage.set('login_type', 'supplier').then((loginRes) => {
            this.storage.set('access_token', r.access_token).then((stRes) => {
                this.storage.set('user', r.user);

                // Set this one signal device tag - suppliers_uuid to this suppliers uuid so
                // we can send push notifications associated with this user
                this.oneSignal.sendTag('suppliers_uuid', r.user.uuid);

                this.navController.navigateRoot('zengiver/dashboard/tabs/(home:home)');
              },
              (err) => {
                this.navController.navigateRoot('zengiver/login');
              });
          });
          this.globals.loading.dismiss();
        },
        (err) => {
          const errMsg = err.error.msg;
          this.globals.loading.dismiss();
          this.globals.presentTopToast(errMsg);
        }, () => {
          this.globals.loading.dismiss();
        });
    }, (err) => {
      console.log(err);
      this.globals.loading.dismiss();
    });
  }

  ngOnInit() {
  }
}
