import {Component, NgZone, OnInit, ViewChild} from '@angular/core';
import {ModalController, NavController, IonRefresher, Events} from '@ionic/angular';
import {MapsAPILoader} from '@agm/core';
import {Globals} from '../../../globals';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {CategoriesService} from '../../../services/general/categories.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {RegisterService} from '../../../services/supplier/auth/register.service';
import {ActivatedRoute, Router} from '@angular/router';
import {AgreementsComponent} from '../../../general/components/agreements/agreements.component';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;

  accountForm: FormGroup;
  uuid: any;
  public terms_of_use: any;
  public privacy_policy: any;

  constructor(public navController: NavController, private mapsAPILoader: MapsAPILoader, private ngZone: NgZone, public globals: Globals,
              private formBuilder: FormBuilder, public categoriesService: CategoriesService, public modalController: ModalController,
              public registrationService: RegistrationService, public registerService: RegisterService, private route: ActivatedRoute,
              private router: Router, public events: Events) {
    this.accountForm = this.formBuilder.group({
      first_name: ['', Validators.compose([
        Validators.required
      ])],
      last_name: ['', Validators.compose([
        Validators.required
      ])],
      email: ['', Validators.compose([
        Validators.email,
        Validators.required
      ])],
      password: [
        '', Validators.compose([
          Validators.min(8),
          Validators.required
        ])],
      terms_of_use: [
        false, Validators.compose([
          Validators.required
        ])],
      privacy_policy: [
        false, Validators.compose([
          Validators.required
        ])]
    });
  }

  submitAccount() {
    const first_name = this.accountForm.controls['first_name'].value;
    const last_name = this.accountForm.controls['last_name'].value;
    const email = this.accountForm.controls['email'].value;
    const confirm_email = this.accountForm.controls['email'].value;
    const password = this.accountForm.controls['password'].value;
    const confirm_password = this.accountForm.controls['password'].value;
    const terms_of_use = this.accountForm.controls['terms_of_use'].value;
    const privacy_policy = this.accountForm.controls['privacy_policy'].value;

    Object.keys(this.accountForm.controls).forEach(field => {
      const control = this.accountForm.get(field);
      control.markAsTouched({onlySelf: true});
    });

    if (this.accountForm.valid) {
      if (!terms_of_use || !privacy_policy) {
        this.globals.presentToast(`Accept zenGOT's Terms of Use and/or Privacy Policy to proceed`);
        return;
      }

      this.globals.presentLoading('Submitting...').then((result) => {
        this.registerService.account(first_name, last_name, email, confirm_email, password, confirm_password)
          .subscribe((res: any) => {
            this.uuid = res.data.uuidSupplier;
            this.globals.loading.dismiss();
            this.navController.navigateRoot('zengiver/register/' + this.uuid);

          }, (err) => {
            this.globals.presentToast(err.error.msg);
            this.globals.loading.dismiss();
          });
      }, (err) => {
        this.globals.presentToast('Something went wrong. Please try again');
        this.globals.loading.dismiss();
      });
    } else {
      this.globals.presentToast(`Fill in all the required fields of the form to proceed`);
    }
  }

  public back() {
    this.navController.back();
  }

  login() {
    this.navController.navigateRoot('zengiver/login');
  }

  // Agree / disagree to terms of use
  async presentTermsOfUseModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{data: this.terms_of_use}
    });

    modal.onDidDismiss().then((res) => {
      this.accountForm.controls['terms_of_use'].setValue(res.data.data);
    });

    return await modal.present();
  }

  // Agree to privacy policy
  async presentPrivacyPolicyModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{data: this.privacy_policy}
    });

    modal.onDidDismiss().then((res) => {
      this.accountForm.controls['privacy_policy'].setValue(res.data.data);
    });

    return await modal.present();
  }

  getTermsOfUse() {
    this.registrationService.getLegal('terms-of-use-agreement').subscribe((r: any) => {
      this.terms_of_use = r.data;
      this.refresher.complete();
    }, (err) => {
      console.error(err);
    });
  }

  getPrivacyPolicy() {
    this.registrationService.getLegal('privacy-policy').subscribe((r: any) => {
      this.privacy_policy = r.data;
      this.refresher.complete();
    }, (err) => {
      console.error(err);
    });
  }

  ngOnInit() {
    this.init();

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.init();
    });
  }

  public init() {
    this.getTermsOfUse();
    this.getPrivacyPolicy();
  }

}
