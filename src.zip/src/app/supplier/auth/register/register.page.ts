/// <reference types="@types/googlemaps" />
import {Component, ElementRef, NgZone, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';
import {IonContent, ModalController, NavController, IonRefresher, Events, AlertController} from '@ionic/angular';
import {MapsAPILoader} from '@agm/core';
import {CategoriesService} from '../../../services/general/categories.service';
import {ServiceCardComponent} from '../../components/service-card/service-card.component';
import {Globals} from '../../../globals';
import {RegistrationService} from '../../../services/general/registration.service';
import {RegisterService} from '../../../services/supplier/auth/register.service';
import {AgreementsComponent} from '../../../general/components/agreements/agreements.component';
import {Router, ActivatedRoute, ParamMap} from '@angular/router';
import {FlatpickrOptions} from 'ng2-flatpickr';
import {PhotoPage} from '../../../general/photo/photo.page';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss']
})
export class RegisterPage implements OnInit {
  @ViewChild('content') content: IonContent;
  @ViewChild('refresher') refresher: IonRefresher;

  personalForm: FormGroup;
  public avatarImage = '../../../../assets/placeholders/avatar_placeholder.svg';
  public licenseFile = '../../../../assets/placeholders/file_placeholder.svg';
  public insuranceFile = '../../../../assets/placeholders/file_placeholder.svg';
  public uuid: any = '';
  public loading = true;
  public today: any;
  public max_date: any;
  public license_expiry: any;
  public insurance_expiry: any;
  public license_uploaded = false;
  public insurance_uploaded = false;
  public avatar_uploaded = false;
  public latitude: number;
  public longitude: number;
  public searchControl: FormControl;
  public zoom: number;
  public steps: number;
  public has_vehicle: boolean;
  public has_insurance: boolean;
  public eligible: boolean;
  public working_age: boolean;
  public criminal_record: boolean;
  public certn_check = false;
  public service_agree = false;
  public categories = [];
  public experiences = [];
  public selected_services = [];
  public times = [];
  public states = [];
  public selected_cities = [];
  public cocs = [];
  public d_cocs = [];
  public references_options = [];
  public references = [];
  public languages_options = [];
  public languages = [];
  public accepted_coc = false;
  public selected_state: number;
  public certn_terms_of_service: any;
  public certn_privacy_policy: any;
  public service_provider_agreement: any;
  public days = [
    {
      day: 'Monday',
      start: '08:00',
      end: '20:00',
      selected: false
    },
    {
      day: 'Tuesday',
      start: '08:00',
      end: '20:00',
      selected: false
    },
    {
      day: 'Wednesday',
      start: '08:00',
      end: '20:00',
      selected: false
    },
    {
      day: 'Thursday',
      start: '08:00',
      end: '20:00',
      selected: false
    },
    {
      day: 'Friday',
      start: '08:00',
      end: '20:00',
      selected: false
    },
    {
      day: 'Saturday',
      start: '08:00',
      end: '20:00',
      selected: false
    },
    {
      day: 'Sunday',
      start: '08:00',
      end: '20:00',
      selected: false
    }
  ];
  public license_calendar_options: FlatpickrOptions = {
    defaultDate: 'today',
    inline: false,
    onChange: (selectedDates, dateStr, instance) => {
      this.license_expiry = dateStr;
    },
    onReady: (selectedDates, dateStr, instance) => {
      this.license_expiry = dateStr;
    },
    altInput: true,
    altFormat: 'F j, Y',
    dateFormat: 'Y-m-d',
    minDate: 'today',
    disableMobile: true,
    clickOpens: true
  };

  public insurance_calendar_options: FlatpickrOptions = {
    defaultDate: 'today',
    inline: false,
    onChange: (selectedDates, dateStr, instance) => {
      this.insurance_expiry = dateStr;
    },
    onReady: (selectedDates, dateStr, instance) => {
      this.insurance_expiry = dateStr;
    },
    altInput: true,
    altFormat: 'F j, Y',
    dateFormat: 'Y-m-d',
    minDate: 'today',
    disableMobile: true,
    clickOpens: true
  };
  @ViewChild('search', {read: ElementRef}) searchElementRef: ElementRef;

  // zengiver/register/77e3306a-64fc-472c-819a-4bc20c4eb7b6
  constructor(public navController: NavController, private mapsAPILoader: MapsAPILoader, private ngZone: NgZone, public globals: Globals,
              private formBuilder: FormBuilder, public categoriesService: CategoriesService, public modalController: ModalController,
              public registrationService: RegistrationService, public registerService: RegisterService, private route: ActivatedRoute,
              private router: Router, public events: Events, public alertController: AlertController) {
    this.personalForm = this.formBuilder.group({
      address: ['', Validators.compose([
        Validators.required
      ])],
      apt_number: [''],
      country: ['', Validators.compose([
        Validators.required
      ])],
      state: ['', Validators.compose([
        Validators.required
      ])],
      city: ['', Validators.compose([
        Validators.required
      ])],
      postal_code: [''],
      phone_number: ['', Validators.compose([
        Validators.required,
        Validators.pattern('^[0-9]*$'),
      ])],
      description: ['', Validators.compose([
        Validators.required
      ])],
    });
    this.zoom = 4;
    this.latitude = 39.8282;
    this.longitude = -98.5799;
    this.steps = 1;
    this.times = this.globals.times;
    this.times.sort(function (a, b) {
      return a.id - b.id;
    });
    console.log(this.times);
    this.searchControl = new FormControl();
    this.setCurrentPosition();
  }

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.uuid = params['uuid'];
      this.init();
    });

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.init();
    });
  }

  public init() {
    // Grab application status of user
    this.applicationStatus();

    // set google maps defaults
    this.zoom = 4;
    this.latitude = 39.8282;
    this.longitude = -98.5795;

    // create search FormControl
    this.searchControl = new FormControl();

    // set current position
    this.setCurrentPosition();

    this.getCategories();
    this.getExperiences();
    this.getStates();
    this.getCocs();
    this.getDCocs();
    this.getLanguages();
    this.getReferences();
    this.getCertnPrivacyPolicy();
    this.getCertnTermsOfService();
    this.getServiceProviderAgreement();
    this.getToday();
    this.loadMap();
  }

  // Get where the zenGiver is left off
  // TODO fill the previous pages with user info for consistency and diffuse confusion during this process
  public applicationStatus() {
    this.registerService.applicationStatus(this.uuid).subscribe((r: any) => {
      this.steps = r.status + 1;
      this.loading = false;
      this.refresher.complete();
    }, (err) => {
      console.error(err);
    });
  }

  private loadMap() {
    // load Places Autocomplete
    this.mapsAPILoader.load().then(() => {
      console.log(google); // returns undefined, expected object here
      const autocomplete = new google.maps.places.Autocomplete(this.searchElementRef.nativeElement, {
        types: ['address']
      });
      autocomplete.addListener('place_changed', () => {
        this.ngZone.run(() => {
          // get the place result
          const place = autocomplete.getPlace();

          // verify result
          if (place.geometry === undefined || place.geometry === null) {
            return;
          }

          place.address_components.forEach((item) => {
            if (item.types.includes('country')) {
              this.personalForm.controls['country'].setValue(item.short_name);
            }
            if (item.types.includes('administrative_area_level_1')) {
              this.personalForm.controls['state'].setValue(item.short_name);
            }
            if (item.types.includes('locality')) {
              this.personalForm.controls['city'].setValue(item.short_name);
            }
            if (item.types.includes('postal_code')) {
              this.personalForm.controls['postal_code'].setValue(item.short_name);
            }
          });
          // set latitude, longitude and zoom
          this.latitude = place.geometry.location.lat();
          this.longitude = place.geometry.location.lng();
          this.zoom = 12;
        });
      });
    });
  }

  private getToday() {
    const d = new Date();
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2) {
      month = '0' + month;
    }
    if (day.length < 2) {
      day = '0' + day;
    }

    this.max_date = year + 10;
    this.today = [year, month, day].join('-');
  }

  private setCurrentPosition() {
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition((position) => {
        this.latitude = position.coords.latitude;
        this.longitude = position.coords.longitude;
        this.zoom = 12;
      });
    }
  }

  getCategories() {
    this.categoriesService.getCategories().subscribe((r: any) => {
      this.categories = r.categories;
    }, (err) => {
      console.error(err);
    });
  }

  getExperiences() {
    this.categoriesService.getExperiences().subscribe((r: any) => {
      this.experiences = r.experiences;
    }, (err) => {
      console.error(err);
    });
  }

  getStates() {
    this.registrationService.getStates().subscribe((r: any) => {
      this.states = r;
    }, (err) => {
      console.error(err);
    });
  }

  getCocs() {
    this.registrationService.getCocs(1).subscribe((r: any) => {
      this.cocs = r;
    }, (err) => {
      console.error(err);
    });
  }

  getDCocs() {
    this.registrationService.getCocs(2).subscribe((r: any) => {
      this.d_cocs = r;
    }, (err) => {
      console.error(err);
    });
  }

  getReferences() {
    this.registrationService.getReferences().subscribe((r: any) => {
      console.log(r);
      r.forEach((ref: any) => {
        ref.references.forEach((r) => {
          this.references_options.push(r);
        });
      });
    }, (err) => {
      console.error(err);
    });
  }

  getLanguages() {
    this.registrationService.getLanguages().subscribe((r: any) => {
      console.log(r);

      this.languages_options = r;
    }, (err) => {
      console.error(err);
    });
  }

  getCertnPrivacyPolicy() {
    this.registrationService.getLegal('certn-privacy-policy').subscribe((r: any) => {
      this.certn_privacy_policy = r.data;
    }, (err) => {
      console.error(err);
    });
  }

  getCertnTermsOfService() {
    this.registrationService.getLegal('certn-terms-of-service').subscribe((r: any) => {
      this.certn_terms_of_service = r.data;
    }, (err) => {
      console.error(err);
    });
  }

  getServiceProviderAgreement() {
    this.registrationService.getLegal('zengiver-service-provider-agreement').subscribe((r: any) => {
      this.service_provider_agreement = r.data;
    }, (err) => {
      console.error(err);
    });
  }

  toggleCity(id) {
    const i = this.selected_cities.findIndex(city => city === id);

    if (i > -1) { // remove if found
      this.selected_cities.splice(i, 1);
    } else { // add if not
      this.selected_cities.push(id);
    }

    console.log(this.selected_cities);
  }

  readImage(event: any, btn, file) {
    const fileBtn = document.getElementById(btn);
    if (event.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (e) => {
        switch (file) {
          case 2:
            this.licenseFile = (<any>e.target).result;
            this.license_uploaded = true;
            break;
          case 3:
            this.insuranceFile = (<any>e.target).result;
            this.insurance_uploaded = true;
            break;
        }
        fileBtn.classList.add('active');
      };
      reader.readAsDataURL(event.target.files[0]);
    } else {
      fileBtn.classList.remove('active');
    }
  }

  async presentCertnPrivacyPolicyModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{data: this.certn_privacy_policy}
    });

    modal.onDidDismiss().then((res) => {
      this.certn_check = res.data.data;
    });

    return await modal.present();
  }

  async presentCertnTermsOfServicesModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{data: this.certn_terms_of_service}
    });

    modal.onDidDismiss().then((res) => {
      this.certn_check = res.data.data;
    });

    return await modal.present();
  }

  async presentServiceProviderAgreementModal() {
    const modal = await this.modalController.create({
      component: AgreementsComponent,
      componentProps: <any>{data: this.service_provider_agreement}
    });

    modal.onDidDismiss().then((res) => {
      this.service_agree = res.data.data;
    });

    return await modal.present();
  }

  // Show Services card component - selecting service details
  async presentModal(c) {
    console.log(c);
    const modal = await this.modalController.create({
      component: ServiceCardComponent,
      componentProps: <any>{data: c, experiences: this.experiences}
    });

    modal.onDidDismiss().then((res) => {
      const data = res.data.data;
      const action = res.data.action;

      console.log(action);
      if (action === 'create') {
        // if there is already one in the selected with same subcategory id - remove it and add new one
        const i = this.selected_services.findIndex(c => c.id === data.id);

        if (i > -1) {
          this.selected_services.splice(i, 1);
        }

        this.selected_services.push(data);
        // toggle check box
        const check = document.getElementById('service_' + data.id);
        check.classList.add('checkbox-checked');

      } else if (action === 'delete') {
        const i = this.selected_services.findIndex(c => c.id === data.id);

        if (i > -1) {
          this.selected_services.splice(i, 1);
          const check = document.getElementById('service_' + data.id);
          check.classList.remove('checkbox-checked');
        }
      }
      console.log(this.selected_services);
    });

    return await modal.present();
  }

  acceptCoc() {
    let checkedCoc = true;
    let checkedDcoc = true;

    for (const item of this.cocs) {
      if (item.checked === undefined || item.checked === false) {
        checkedCoc = false;
        break;
      }
    }

    if (!checkedCoc) {
      this.globals.presentToast(`Please check all conditions under zenGOT's Code of Conduct`);
      this.accepted_coc = false;
      return;
    }

    for (const item of this.d_cocs) {
      if (item.checked === undefined || item.checked === false) {
        checkedDcoc = false;
        break;
      }
    }

    if (!checkedDcoc) {
      this.globals.presentToast(`Please check all conditions under zenGOT's Deactivation Policy`);
      this.accepted_coc = false;
      return;
    }

    this.accepted_coc = true;
  }

  login() {
    this.navController.navigateRoot('zengiver/login');
  }

  public next() {
    switch (this.steps) {
      case 1:
        this.submitPersonal();
        break;
      case 2:
        this.submitServices();
        break;
      case 3:
        this.submitAvailability();
        break;
      case 4:
        this.submitAreas();
        break;
      case 5:
        this.submitInsurance();
        break;
      case 6:
        this.submitCoc();
        break;
      case 7:
        this.submitAdditional();
        break;
    }
  }

  public back() {
    this.steps--;
  }

  public forwards() {
    this.steps++;
    this.content.scrollToTop();
  }

  async navigateBack() {
    const alert = await this.alertController.create({
      header: 'You have not completed your application. Leave application process?',
      message: '',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.navController.back();
          }
        }
      ]
    });
    await alert.present();
  }

  submitPersonal() {
    const address = this.personalForm.controls['address'].value;
    const apt_number = this.personalForm.controls['apt_number'].value;
    const country = this.personalForm.controls['country'].value;
    const state = this.personalForm.controls['state'].value;
    const city = this.personalForm.controls['city'].value;
    const postal_code = this.personalForm.controls['postal_code'].value;
    const phone_number = this.personalForm.controls['phone_number'].value;
    const description = this.personalForm.controls['description'].value;

    Object.keys(this.personalForm.controls).forEach(field => {
      const control = this.personalForm.get(field);
      control.markAsTouched({onlySelf: true});
    });

    if (this.personalForm.valid) {
      if (!this.avatar_uploaded) {
        this.globals.presentToast(`Upload a photo of yourself`);
        return;
      }
      this.globals.presentLoading('Submitting...').then((result) => {
        this.registerService.personal(this.uuid, this.avatarImage, address, apt_number, country, state, city, postal_code,
          this.latitude, this.longitude, phone_number, description)
          .subscribe((res: any) => {
            this.forwards();
            this.globals.loading.dismiss();
          }, (err) => {
            this.globals.presentToast(err.error.msg);
            this.globals.loading.dismiss();
          });
      }, (err) => {
        this.globals.presentToast('Something went wrong. Please try again');
        this.globals.loading.dismiss();
      });
    } else {
      this.globals.presentToast(`Fill in all the required fields of the form to proceed`);
    }

  }

  submitServices() {
    if (this.selected_services.length < 1) {
      this.globals.presentToast(`Select at least one service to provide`);
      return;
    }
    this.globals.presentLoading('Submitting...').then((result) => {
      this.registerService.services(this.uuid, this.selected_services)
        .subscribe((res: any) => {
          this.forwards();
          this.globals.loading.dismiss();
        }, (err) => {
          this.globals.presentToast(err.error.msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  submitAvailability() {
    // validate if one of the day's end time is not greater than the start time
    let validationResult = true;
    this.days.forEach((d) => {
      const result = this.compareTime(d.start, d.end);
      if (!result) {
        validationResult = false;
      }
    });

    if (!validationResult) {
      return;
    }
    this.globals.presentLoading('Submitting...').then((result) => {
      this.registerService.availability(this.uuid, this.days)
        .subscribe((res: any) => {
          this.forwards();
          this.globals.loading.dismiss();
        }, (err) => {
          this.globals.presentToast(err.error.msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  submitAreas() {
    if (this.selected_state === undefined) {
      this.globals.presentToast(`Select a province/state`);
      return;
    }
    if (this.selected_cities.length < 1) {
      this.globals.presentToast(`Select at least one city/area to provide your services in`);
      return;
    }
    this.globals.presentLoading('Submitting...').then((result) => {
      this.registerService.areas(this.uuid, this.selected_state, this.selected_cities)
        .subscribe((res: any) => {
          this.forwards();
          this.globals.loading.dismiss();
        }, (err) => {
          this.globals.presentToast(err.error.msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  submitInsurance() {
    if (this.has_insurance) { // if yes for insurance must upload files
      if (!this.license_uploaded) {
        this.globals.presentToast(`Upload a photo of your license`);
        return;
      }
      if (!this.insurance_uploaded) {
        this.globals.presentToast(`Upload a photo of your insurance`);
        return;
      }
    }

    this.globals.presentLoading('Submitting...').then((result) => {
      this.registerService.insurance(this.uuid, this.has_vehicle, this.has_insurance, this.licenseFile,
        this.insuranceFile, this.license_expiry, this.insurance_expiry)
        .subscribe((res: any) => {
          this.forwards();
          this.globals.loading.dismiss();
        }, (err) => {
          this.globals.presentToast(err.error.msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  submitCoc() {
    this.acceptCoc();
    if (this.accepted_coc) {
      this.forwards();
    }
  }

  // Final step
  submitAdditional() {
    if (!this.certn_check) {
      this.globals.presentToast(`Please agree to allow us to conduct a background check on you through CERTN`);
      return;
    }
    if (!this.service_agree) {
      this.globals.presentToast(`Please confirm that you have reviewed and agree to the zenGiver Service Provider Agreement`);
      return;
    }
    if (!this.eligible) {
      this.globals.presentToast(`You must be eligible to work in your country`);
      return;
    }
    if (!this.working_age) {
      this.globals.presentToast(`You must be 18 years or older`);
      return;
    }
    this.globals.presentLoading('Submitting...').then((result) => {
      this.registerService.additional(this.uuid, this.references, this.languages, this.eligible, this.working_age, this.criminal_record)
        .subscribe((res: any) => {
          this.globals.loading.dismiss();
          this.navController.navigateRoot('zengiver/interviews/' + this.uuid);
        }, (err) => {
          this.globals.presentToast(err.error.msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.presentToast('Something went wrong. Please try again');
      this.globals.loading.dismiss();
    });
  }

  async openPhotoModal() {
    const modal = await this.modalController.create({
      component: PhotoPage,
      componentProps: <any>{
        width: 300,
        height: 300
      }
    });

    modal.onDidDismiss().then((res) => {
      if (res.data.image !== undefined) {
        this.avatarImage = res.data.image;
        this.avatar_uploaded = true;
      }
    });

    return await modal.present();
  }

  compareTime(start, end) {
    const result = this.globals.compareTime(start, end);
    if (!result) {
      this.globals.presentAlert('End time must be after your start time');
      return false;
    }
    return true;
  }
}
