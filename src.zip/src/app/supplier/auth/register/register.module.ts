import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { RegisterPage } from './register.page';
import {AgmCoreModule} from '@agm/core';
import {ImageCropperModule} from 'ngx-image-cropper';
import {Ng2FlatpickrModule} from 'ng2-flatpickr';

const routes: Routes = [
  {
    path: '',
    component: RegisterPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyBIzrwVkka_LJMF89tgjzJUe6VMDxpQ0gg',
      libraries: ['places']
    }),
    ImageCropperModule,
    Ng2FlatpickrModule
  ],
  declarations: [RegisterPage]

})
export class RegisterPageModule {}
