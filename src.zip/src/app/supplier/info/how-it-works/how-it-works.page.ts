import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {NavController, Platform, IonSlides} from '@ionic/angular';

@Component({
  selector: 'app-how-it-works',
  templateUrl: './how-it-works.page.html',
  styleUrls: ['./how-it-works.page.scss'],
})
export class HowItWorksPage implements OnInit {
  @ViewChild('myslides') slides: IonSlides;
  public height = '540';
  public skipMsg = 'Skip';

  constructor(public platform: Platform, private navController: NavController) {
    this.platform.ready().then(() => {
      const deviceHeight = platform.height();
      console.log('Width: ' + platform.width());
      console.log('Height: ' + deviceHeight);
      this.height = deviceHeight + 'px';
      this.slides.stopAutoplay();
    });
  }

  async slideChanged() {
    this.slides.isEnd().then((res) => {
      if (res) {
        this.skipMsg = 'Alright, I got it!';
      } else {
        this.skipMsg = 'Skip';
      }
    });
  }

  public skip() {
    this.navController.navigateForward('zengiver/signup');
  }

  public login() {
    this.navController.navigateForward('zengiver/login');
  }

  public slideForward() {
    this.slides.slideNext();
  }

  ngOnInit() {
  }
}
