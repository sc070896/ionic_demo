import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalController, NavController, AlertController, IonRefresher, Events} from '@ionic/angular';
import {Globals} from '../../../globals';
import {AgmMap} from '@agm/core';
import {BookingsService} from '../../../services/supplier/bookings/bookings.service';
import {PusherService} from '../../../services/supplier/auth/pusher.service';
import {ExpensesPage} from '../expenses/expenses.page';
import {BookingService} from '../../../services/general/booking.service';
import {ReschedulePage} from '../reschedule/reschedule.page';
import {RescheduleService} from '../../../services/supplier/bookings/reschedule.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.page.html',
  styleUrls: ['./details.page.scss'],
})
export class DetailsPage implements OnInit {
  @ViewChild('refresher') refresher: IonRefresher;
  @ViewChild('agmMap') agmMap: AgmMap;
  public b: any;
  public user: any;
  loading: any;
  // set google maps defaults
  public latitude: number;
  public longitude: number;
  public zoom: number;

  public channelBinded = false;

  constructor(public navController: NavController, private modalController: ModalController, public globals: Globals,
              public bookingsService: BookingsService,
              public pusherService: PusherService, private alertController: AlertController, public events: Events,
              public bookingService: BookingService, public rescheduleService: RescheduleService) {
  }

  async ngOnInit() {
    this.init();

    this.events.subscribe('network:offline', () => {
      this.refresher.complete();
    });

    this.events.subscribe('network:online', () => {
      this.getBooking();
    });
  }

  async init() {
    setTimeout(() => {
      this.latitude = this.b.customer_latitude;
      this.longitude = this.b.customer_longitude;
      this.zoom = 13;
      this.agmMap.triggerResize();
    }, 500);
    await this.handleSupplierNotifications();
  }

  public back() {
    this.modalController.dismiss({
      b: this.b
    });
  }

  public initials(name: string) {
    return this.globals.initials(name);
  }

  public formatHours(h: number) {
    return this.globals.formatHours(h);
  }

  async goChat(booking: any) {
    this.modalController.dismiss({
      b: this.b
    });
    this.navController.navigateForward('zengiver/bookings/chat/' + booking.uuid_booking);
  }

  public goToProfile(username) {
    this.navController.navigateForward('zengiver/profile/' + username);
  }

  async accept() {
    const alert = await this.alertController.create({
      header: 'Accept Service Request?',
      message: '',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Accept',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.bookingsService.accept(this.b.uuid_booking, this.user.uuid)
                .subscribe((res: any) => {
                  console.log(res);
                  this.b = res.booking;
                  this.b = this.getBookingWithSupplierPrice(this.b);
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  console.log(err);
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async decline() {
    const alert = await this.alertController.create({
      header: 'Decline Service Request?',
      message: '',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Decline',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.bookingsService.decline(this.b.uuid_booking, this.user.uuid)
                .subscribe((res: any) => {
                  console.log(res);
                  this.b = res.booking;
                  this.b = this.getBookingWithSupplierPrice(this.b);
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async start() {
    const alert = await this.alertController.create({
      header: 'Start Service?',
      message: '',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Start',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.bookingsService.start(this.b.uuid_booking, this.user.uuid)
                .subscribe((res: any) => {
                  console.log(res);
                  this.b = res.booking;
                  this.b = this.getBookingWithSupplierPrice(this.b);
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async end() {
    const alert = await this.alertController.create({
      header: 'Complete Service?',
      message: '',
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Complete',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.bookingsService.end(this.b.uuid_booking, this.user.uuid)
                .subscribe((res: any) => {
                  console.log(res);
                  this.b = res.booking;
                  this.b = this.getBookingWithSupplierPrice(this.b);
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async checkCancel() {
    let cancel_message = '';
    this.globals.presentLoading('Loading...').then((resLoading) => {
      this.bookingsService.checkCancel(this.b.uuid_booking, this.user.uuid)
        .subscribe((res: any) => {
          console.log(res);
          cancel_message = res.message;
          this.globals.loading.dismiss();
          this.cancel(cancel_message);
        }, (err) => {
          const msg = err.error.error;
          this.globals.presentAlert(msg);
          this.globals.loading.dismiss();
        });
    }, (err) => {
      this.globals.loading.dismiss();
    });
  }

  async cancel(message) {
    const alert = await this.alertController.create({
      header: 'Cancel Service?',
      message: message,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Cancel',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.bookingsService.cancel(this.b.uuid_booking, this.user.uuid)
                .subscribe((res: any) => {
                  console.log(res);
                  this.b = res.booking;
                  this.b = this.getBookingWithSupplierPrice(this.b);
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async removeExpenses(id) {
    const alert = await this.alertController.create({
      header: 'Remove this expense?',
      message: '',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.bookingsService.removeExpenses(id)
                .subscribe((res: any) => {
                  console.log(res);
                  this.b = res.booking;
                  this.b = this.getBookingWithSupplierPrice(this.b);
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  public getBooking() {
    this.bookingService.getBookingByUuid(this.b.uuid_booking).subscribe((result: any) => {
      this.b = result;
      this.b = this.getBookingWithSupplierPrice(this.b);
      this.init();
      this.refresher.complete();
    }, (err) => {
      console.log(err);
    });
  }

  async handleSupplierNotifications() {
    let channel = this.pusherService.init();
    if (channel === undefined) {
      channel = this.pusherService.init();
    }
    setInterval(() => {
      if (channel === undefined) {
        channel = this.pusherService.init();
      } else {
        if (!this.channelBinded) {
          channel.bind('Illuminate\\Notifications\\Events\\BroadcastNotificationCreated', (event) => {
            if (event.booking_uuid === this.b.uuid_booking) {
              if (
                event.type === 'App\\Notifications\\Supplier\\BookingExpired' ||
                event.type === 'App\\Notifications\\Supplier\\CustomerCancelledBooking' ||
                event.type === 'App\\Notifications\\Supplier\\NoShow' ||
                event.type === 'App\\Notifications\\Supplier\\CustomerCancelledUrgentBooking'
              ) {
                this.b.status = event.status;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\CustomerUpdatedServiceDetails'
              ) {
                this.b.service_details = event.service_details;
              }

              if (event.type === 'App\\Notifications\\Supplier\\Bookings\\CustomerUpdatedServiceLocation') {
                this.b.customer_location = event.customer_location;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\SupplierNewChatMessage'
              ) {
                this.b.conversation.supplier_unread_messages = event.messages_count;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\CustomerRescheduled' ||
                event.type === 'App\\Notifications\\Supplier\\CustomerRescheduledInstant' ||
                event.type === 'App\\Notifications\\Supplier\\CustomerExtendedBooking' ||
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerAcceptedReschedule'
              ) {
                this.b.time = event.request_time;
                this.b.date = event.date;
                this.b.duration = event.duration;
                this.b.reschedule_request = null;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\CustomerConfirmedBooking'
              ) {
                this.b.time = event.request_time;
                this.b.date = event.date;
                this.b.status = event.status;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\FlexibleBookings\\CustomerAcceptedFlexible' ||
                event.type === 'App\\Notifications\\Supplier\\FlexibleBookings\\CustomerDeclinedFlexible'
              ) {
                this.b = event.booking;
                this.b = this.getBookingWithSupplierPrice(this.b);
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerCreatedReschedule'
              ) {
                this.b.reschedule_request = event.reschedule_request;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerDeclinedReschedule' ||
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerCancelledReschedule'
              ) {
                this.b.reschedule_request = null;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerCreatedRecurringReschedule'
              ) {
                this.b.reschedule_recurring_request = event.reschedule_recurring_request;
              }

              if (
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerDeclinedRecurringReschedule' ||
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerCancelledRecurringReschedule' ||
                event.type === 'App\\Notifications\\Supplier\\Reschedules\\CustomerAcceptedRecurringReschedule'
              ) {
                this.b.reschedule_recurring_request = null;
              }
            }
            console.log(event);
          });
          this.channelBinded = true;
        }
      }
    }, 5000);
  }

  async addExpenses() {
    const modal = await this.modalController.create({
      component: ExpensesPage,
      componentProps: <any>{booking: this.b}
    });

    modal.onDidDismiss().then((res) => {
      if (Object.keys(res.data).length) {
        this.b = res.data.b;
      }
    });

    return await modal.present();
  }

  public checkForFlexibleRequest() {
    return this.b.flexible === 1 && this.b.is_asap === 1;
  }

  // Flexible Requests
  async openFlexibleReschedule() {
    const modal = await this.modalController.create({
      component: ReschedulePage,
      componentProps: <any>{
        booking: this.b,
        type: 1,
        user: this.user,
      }
    });

    modal.onDidDismiss().then((res) => {
      if (Object.keys(res.data).length) {
        this.b = res.data.booking;
      }
    });

    return await modal.present();
  }

  async cancelFlexibleRequest() {
    const alert = await this.alertController.create({
      header: 'Cancel your current schedule request?',
      message: 'You can send another request after cancelling',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.cancelFlexibleReschedule(this.b.id)
                .subscribe((res: any) => {
                  this.b.flexible_request = null;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  // Two way Reschedules
  public checkForTwoWayRequestSent() {
    return this.b.reschedule_request && Object.keys(this.b.reschedule_request).length !== 0
      && this.b.reschedule_request.status !== 'accepted';
  }

  async openReschedule() {
    const modal = await this.modalController.create({
      component: ReschedulePage,
      componentProps: <any>{
        booking: this.b,
        type: 2,
        user: this.user,
      }
    });

    modal.onDidDismiss().then((res: any) => {
      this.b = res.data.booking;
    });

    return await modal.present();
  }

  async cancelTwoWayRequest() {
    const alert = await this.alertController.create({
      header: 'Cancel your current reschedule request?',
      message: 'You can send another request after cancelling',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.cancelTwoWayReschedule(this.b.id, this.user.uuid)
                .subscribe((res: any) => {
                  this.b.reschedule_request = null;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async acceptTwoWayRequest() {
    const alert = await this.alertController.create({
      header: 'Accept reschedule request?',
      message: this.b.reschedule_request.formatted_service_date + ' - ' + this.b.reschedule_request.formatted_service_time,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.acceptTwoWayReschedule(this.b.id, this.user.uuid)
                .subscribe((res: any) => {
                  this.b.reschedule_request = null;
                  this.b = res.booking;
                  this.b = this.getBookingWithSupplierPrice(this.b);
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async declineTwoWayRequest() {
    const alert = await this.alertController.create({
      header: 'Decline service being rescheduled?',
      message: this.b.reschedule_request.formatted_service_date + ' - ' + this.b.reschedule_request.formatted_service_time,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.declineTwoWayReschedule(this.b.id, this.user.uuid)
                .subscribe((res: any) => {
                  this.b.reschedule_request = null;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  // Two way recurring Reschedules
  public checkForTwoWayRecurringRequestSent() {
    return this.b.reschedule_recurring_request && Object.keys(this.b.reschedule_recurring_request).length !== 0
      && this.b.reschedule_recurring_request.status !== 'accepted';
  }

  async cancelTwoWayRecurringRequest() {
    const alert = await this.alertController.create({
      header: 'Cancel your current reschedule request?',
      message: 'You can send another request after cancelling',
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.cancelTwoWayRecurringReschedule(this.b.id, this.user.uuid)
                .subscribe((res: any) => {
                  this.b.reschedule_recurring_request = null;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async acceptTwoWayRecurringRequest() {
    const alert = await this.alertController.create({
      header: 'Accept your next service to be rescheduled?',
      message: this.b.reschedule_recurring_request.formatted_service_date + ' - '
        + this.b.reschedule_recurring_request.formatted_service_time,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.acceptTwoWayRecurringReschedule(this.b.id, this.user.uuid)
                .subscribe((res: any) => {
                  this.b.reschedule_request = null;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  async declineTwoWayRecurringRequest() {
    const alert = await this.alertController.create({
      header: 'Decline your next service being rescheduled?',
      message: this.b.reschedule_recurring_request.formatted_service_date + ' - '
        + this.b.reschedule_recurring_request.formatted_service_time,
      buttons: [
        {
          text: 'No',
          role: 'cancel',
          cssClass: 'secondary'
        }, {
          text: 'Yes',
          handler: () => {
            this.globals.presentLoading('Loading...').then((resLoading) => {
              this.rescheduleService.declineTwoWayRecurringReschedule(this.b.id, this.user.uuid)
                .subscribe((res: any) => {
                  this.b.reschedule_request = null;
                  this.globals.presentTopToast(res.success);
                  this.globals.loading.dismiss();
                }, (err) => {
                  const msg = err.error.error;
                  this.globals.presentAlert(msg);
                  this.globals.loading.dismiss();
                });
            }, (err) => {
              this.globals.loading.dismiss();
            });
          }
        }
      ]
    });
    await alert.present();
  }

  public getBookingWithSupplierPrice(booking){
    if(parseInt(booking.price) > 0 && booking.supplier){
      booking.price = (booking.price / ( 1 + (booking.supplier.member_ship_plans[0].charge_percentage/100))).toFixed(2);
    } else {
      booking.price = (booking.price / ( 1 + (booking.membership_plans.charge_percentage/100))).toFixed(2);
    }
    return booking;
  }
}
