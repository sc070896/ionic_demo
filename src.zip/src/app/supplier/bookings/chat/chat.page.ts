import {Component, OnInit, ViewChild} from '@angular/core';
import {IonContent, ModalController, NavController, IonRefresher} from '@ionic/angular';
import {Globals} from '../../../globals';
import {FormBuilder} from '@angular/forms';
import {CategoriesService} from '../../../services/general/categories.service';
import {RegistrationService} from '../../../services/general/registration.service';
import {AccountService} from '../../../services/supplier/account/account.service';
import {Storage} from '@ionic/storage';
import * as Chat from 'twilio-chat';
import {ChatService} from '../../../services/general/chat.service';
import {ActivatedRoute, Router} from '@angular/router';
import {BookingService} from '../../../services/general/booking.service';
import {DetailsPage} from '../details/details.page';
import * as moment from 'moment';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.page.html',
  styleUrls: ['./chat.page.scss'],
})

/**
 * Refer to http://media.twiliocdn.com/sdk/js/chat/releases/3.0.2/docs/Client.html
 */
export class ChatPage implements OnInit {
  @ViewChild('content') content: IonContent;
  @ViewChild('refresher') refresher: IonRefresher;

  message_placeholder = 'Type your message here';
  token: any;
  uuid: any; // booking uuid
  booking: any; // booking
  chat_creds: any; // title | name | to | recipientUsername | username | channelName | channelFriendlyName | senderImage | recipientImage
  client: any;
  channel: any;
  messages = [];
  MESSAGES_HISTORY_LIMIT = 50;
  input_message = '';
  is_typing = '';
  loading = true;

  constructor(private route: ActivatedRoute, private router: Router, public navController: NavController, public globals: Globals,
              private formBuilder: FormBuilder, public categoriesService: CategoriesService, public modalController: ModalController,
              public registrationService: RegistrationService, public bookingService: BookingService, public chatService: ChatService,
              public accountService: AccountService, private storage: Storage) {
  }

  ngOnInit() {
    this.route.params.subscribe((params) => {
      this.uuid = params['uuid'];
      this.init();
    });
  }

  public refresh() {
    this.messages = [];
    this.init();
  }

  public init() {
    this.getBooking();
    this.getCreds();
  }

  public getToken() {
    this.chatService.getToken(this.chat_creds.username).subscribe((res: any) => {
      console.log(res);
      this.token = res.token;
      this.createChatClient();
    }, (err) => {
      console.error(err);
    });
  }

  // 1 Create the chat client - refer to the link above for reference
  async createChatClient() {
    Chat.Client.create(this.token).then(client => {
      console.log('got client');
      this.client = client;
      // Use client
      try {
        client.getChannelByUniqueName(this.chat_creds.channelName)
          .then((channel) => {
            console.log(channel);
            this.channel = channel;
            this.joinChannel();
          }).catch((err) => {
          // if none found create the channel
          this.createChannel();
          console.log(err);
        });
      } catch (err) {
        console.log(err);
      }
    });
  }

  // 2 (optional step)
  public createChannel() {
    this.client.createChannel({
      friendlyName: this.chat_creds.channelFriendlyName,
      uniqueName: this.chat_creds.channelName,
      isPrivate: false,
    }).then((channel) => {
      console.log(channel);
      this.channel = channel;
      this.joinChannel();
    }).catch((err) => {
      // if unable to create channel
      console.log(err);
    });
  }

  // 3
  public joinChannel() {
    this.channel.join()
      .then((joinedChannel) => {
        console.log('Joined channel ' + joinedChannel.friendlyName);
        this.loadMessages();
        this.addListeners();
      }).catch((err) => {
      this.loadMessages();
      this.addListeners();
      console.log(err);
    });
  }

  // 4
  async loadMessages() {
    console.log('Loading messages of channel ' + this.channel.friendlyName);
    const messages = await this.channel.getMessages(this.MESSAGES_HISTORY_LIMIT);
    console.log(messages);
    for (const message of messages.items) {
      await this.addMessage(message);
    }
    this.loading = false;
    this.refresher.complete();
    setTimeout(() => {
      this.content.scrollToBottom();
    }, 2500);
  }

  // 5
  public addListeners() {
    this.channel.on('messageAdded', (message) => {
      this.addMessage(message);
    });
    this.channel.on('typingStarted', (member) => {
      this.typingStarted(member);
    });
    this.channel.on('typingEnded', (member) => {
      this.typingEnded();
    });
  }

  public sendMessage() {
    if (this.input_message === '') {
      return;
    }
    this.channel.sendMessage(this.input_message);
    this.increaseUnreadMessages(this.input_message, 'customer'); // increase unread messages of customer because supplier msged
    this.resetUnreadMessages('supplier'); // reset unread messages of supplier after sending a message
    this.input_message = '';
    setTimeout(() => {
      this.content.scrollToBottom();
    }, 1000);
  }

  async addMessage(message) {
    return new Promise(async (resolve, reject) => {
      let data = {};
      let type = 'sender';
      if (message.author !== this.chat_creds.username) {
        type = 'recipient';
      }
      if (message.type === 'media') {
        // get media temporary URL for displaying/fetching
        const url = await message.media.getContentUrl();
        if (message.media.filename !== null) {
          data = {
            recipient_image: this.chat_creds.recipientImage,
            recipient_name: this.chat_creds.to,
            sender_image: this.chat_creds.senderImage,
            sender_name: this.chat_creds.name,
            message: url,
            timestamp: message.timestamp,
            type: type,
            message_type: 'media'
          };
          this.messages.push(data);
        }
      } else {
        data = {
          recipient_image: this.chat_creds.recipientImage,
          recipient_name: this.chat_creds.to,
          sender_image: this.chat_creds.senderImage,
          sender_name: this.chat_creds.name,
          message: message.body,
          timestamp: message.timestamp,
          type: type,
          message_type: 'text'
        };
        this.messages.push(data);
      }
      setTimeout(() => {
        this.content.scrollToBottom();
      }, 500);
      return resolve();
    });
  }

  public typingStarted(member) {
    console.log(member);
    const usernameArr = member.identity.split('.');
    const user = usernameArr[0] + ' ' + usernameArr[1].substring(0, 1) + '.';
    this.is_typing = user + ' is typing...';
  }

  public typingEnded() {
    this.is_typing = '';
  }

  async goDetails(booking: any) {
    const modal = await this.modalController.create({
      component: DetailsPage,
      componentProps: <any>{b: booking}
    });

    modal.onDidDismiss().then((res) => {

    });

    return await modal.present();
  }

  public resetUnreadMessages(user_type) {
    this.chatService.resetUnreadMessages(this.booking.id, user_type).subscribe((res: any) => {
      console.log(res);
    }, (err) => {
      console.error(err);
    });
  }

  public increaseUnreadMessages(message, user_type) {
    this.chatService.increaseUnreadMessages(this.booking.id, message, user_type).subscribe((res: any) => {
      console.log(res);
    }, (err) => {
      console.error(err);
    });
  }

  public getCreds() {
    this.chatService.messageCustomer(this.uuid).subscribe((res: any) => {
      console.log(res);
      this.chat_creds = res.data;
      this.getToken();
    }, (err) => {
      console.error(err);
    });
  }

  public getBooking() {
    this.bookingService.getBookingByUuid(this.uuid).subscribe((res) => {
      console.log(res);
      this.booking = res;
      this.resetUnreadMessages('supplier');
    }, (err) => {
      console.error(err);
    });
  }

  async sendImage(event) {
    const resizedImage: any = await this.globals.resizeImage(500, event.target.files[0]);
    if (typeof resizedImage === 'string') {
      this.globals.presentTopToast('Image failed to upload');
      return;
    }
    const formData = new FormData();
    formData.append('file', resizedImage);
    this.channel.sendMessage(formData);
  }

  public back() {
    this.navController.back();
  }

  public getTimeFromNow(date) {
    return moment(date).fromNow();
  }

  public initials(string) {
    return this.globals.initials(string);
  }
}
