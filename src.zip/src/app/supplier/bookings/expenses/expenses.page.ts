import {Component, NgZone, OnInit} from '@angular/core';
import {AlertController, ModalController, NavController} from '@ionic/angular';
import {Globals} from '../../../globals';
import {BookingsService} from '../../../services/supplier/bookings/bookings.service';
import {PusherService} from '../../../services/supplier/auth/pusher.service';

@Component({
  selector: 'app-expenses',
  templateUrl: './expenses.page.html',
  styleUrls: ['./expenses.page.scss'],
})
export class ExpensesPage implements OnInit {
  public booking: any;
  public cost: any = 20;
  public description: any = '';
  public avatar_uploaded = false;
  public hide_avatar_cropper = true;
  imageChangedEvent: any = '';
  croppedImage: any = '../../../../assets/placeholders/images_plaecholder.svg';

  constructor(public navController: NavController, private modalController: ModalController, public globals: Globals,
              public bookingsService: BookingsService, public pusherService: PusherService, private alertController: AlertController) {
  }

  ngOnInit() {
  }

  public back() {
    this.modalController.dismiss({});
  }

  public update() {
    if (!this.avatar_uploaded) {
      this.globals.presentAlert('Attach an image to your expenses');
      return;
    }
    const data = {
      cost: this.cost,
      description: this.description,
      file: [this.croppedImage],
      is_base64: true
    };
    this.globals.presentLoading('Submitting...').then((resLoading) => {
      this.bookingsService.addExpenses(this.booking.id, data)
        .subscribe((res: any) => {
          this.booking = res.booking;
          this.globals.presentAlert(res.success);
          this.globals.loading.dismiss();
          this.modalController.dismiss({
            b: this.booking
          });
        }, (err) => {
          console.log(err);
          const msg = err.error.error;
          this.globals.presentAlert(msg);
          this.globals.loading.dismiss();
        });
    });
  }

  fileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
  }

  imageCropped(image: string) {
    this.croppedImage = image;
  }

  imageLoaded() {
    // show cropper
    this.hide_avatar_cropper = false;
    this.avatar_uploaded = true;
  }

  loadImageFailed() {
    // show message
    this.globals.presentTopToast('Failed to load image. Please choose a new one or try again.');
  }
}
