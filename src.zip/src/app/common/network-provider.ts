import {Injectable} from '@angular/core';
import {Network} from '@ionic-native/network/ngx';
import {Events, ToastController} from '@ionic/angular';
import {Globals} from '../globals';

export enum ConnectionStatusEnum {
  Online,
  Offline
}

@Injectable()
export class NetworkProvider {

  previousStatus;
  infinite_toast: any = null;

  constructor(public toastController: ToastController,
              public network: Network,
              public globals: Globals,
              public eventCtrl: Events) {
    this.previousStatus = ConnectionStatusEnum.Online;
  }

  public initializeNetworkEvents(): void {
    this.network.onDisconnect().subscribe(() => {
      if (this.previousStatus === ConnectionStatusEnum.Online) {
        this.eventCtrl.publish('network:offline');
      }
      if (this.globals.loading !== null) {
        this.globals.loading.dismiss();
      }
      this.globals.disconnected = true;
      this.presentInfiniteTopToast('Disconnected. Reconnect to the internet.');
      this.previousStatus = ConnectionStatusEnum.Offline;
    });
    this.network.onConnect().subscribe(() => {
      if (this.previousStatus === ConnectionStatusEnum.Offline) {
        this.eventCtrl.publish('network:online');
      }
      if (this.infinite_toast !== null) {
        this.infinite_toast.dismiss();
      }
      this.globals.disconnected = false;
      this.previousStatus = ConnectionStatusEnum.Online;
    });
  }

  async presentInfiniteTopToast(msg) {
    this.infinite_toast = await this.toastController.create({
      message: msg,
      showCloseButton: true,
      position: 'top',
      closeButtonText: 'x'
    });
    this.infinite_toast.present();
  }
}
