import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Platform } from '@ionic/angular';

@Component({
  selector: 'app-choose',
  templateUrl: './choose.page.html',
  styleUrls: ['./choose.page.scss'],
})
export class ChoosePage implements OnInit {
  public height = '280';
  public skipMsg = 'Skip';
  constructor(platform: Platform, private navController: NavController) {
    platform.ready().then((readySource) => {
      const deviceHeight = platform.height() * 0.4;
      console.log('Width: ' + platform.width());
      console.log('Height: ' + deviceHeight);
      this.height = deviceHeight + 'px';
    });
  }
  public customerLogin() {
    this.navController.navigateForward('customer/login');
  }
  public supplierLogin() {
    this.navController.navigateForward('zengiver/login');
  }
  ngOnInit() {
  }

}
