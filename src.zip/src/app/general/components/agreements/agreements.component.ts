import {Component, EventEmitter, Input, Output, OnInit} from '@angular/core';
import {ModalController} from '@ionic/angular';

@Component({
  selector: 'app-agreements',
  templateUrl: './agreements.component.html',
  styleUrls: ['./agreements.component.scss']
})
export class AgreementsComponent implements OnInit {
  public data: any;
  public hideButtons = false;

  constructor(private modalController: ModalController) {
  }

  agree() {
    this.modalController.dismiss({
      data: 1
    });
  }

  disagree() {
    this.modalController.dismiss({
      data: 0
    });
  }

  ngOnInit() {
  }

}
