export const environment = {
  production: true,
  API_URL: `https://api.zengot.com/v1/`,
  //API_URL: `https://staging-api.zengot.com/v1/`,
  S3_ASSETS_URL: `https://s3.ca-central-1.amazonaws.com/zengot-assets/`,
  S3_URL: `https://zengotca.s3.ca-central-1.amazonaws.com/`,
  PUSHER_KEY: `fab1042286c682f647c6`,
  PUSHER_CLUSTER: `us2`,
};
