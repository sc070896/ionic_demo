// The file contents for the current environment will overwrite these during build.
// The build system defaults to the dev environment which uses `environment.ts`, but if you do
// `ng build --env=prod` then `environment.prod.ts` will be used instead.
// The list of which env maps to which file can be found in `.angular-cli.json`.
export const environment = {
  production: false,
  API_URL: `http://api.zengot/v1/`,
  S3_ASSETS_URL: `https://s3.ca-central-1.amazonaws.com/zengot-assets/`,
  S3_URL: `https://zengotca.s3.ca-central-1.amazonaws.com/`,
  PUSHER_KEY: `fab1042286c682f647c6`,
  PUSHER_CLUSTER: `us2`,
};

/*
export const environment = {
  production: false,
  API_URL: `https://api.zengot/v1/`,
  S3_ASSETS_URL: `https://s3.ca-central-1.amazonaws.com/zengot-assets/`,
  S3_URL: `https://zengotca-dev.s3.ca-central-1.amazonaws.com/`,
  PUSHER_KEY: `a3c423f7983d4694f249`,
  PUSHER_CLUSTER: `us2`,
};
 */

/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
